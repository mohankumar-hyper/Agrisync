from database import get_db
from app import app
from werkzeug.security import generate_password_hash

ctx = app.app_context()
ctx.push()
db = get_db()

# Reset ALL users to known password for recovery
users_to_reset = ['VIKAS M P', 'ullas', 'ullas cr']
new_password = 'agrisync123'

for uname in users_to_reset:
    result = db.users.update_one(
        {'username': uname},
        {'$set': {'password_hash': generate_password_hash(new_password)}}
    )
    if result.modified_count:
        print(f"✓ Password reset for: {uname}")
    else:
        print(f"✗ User not found: {uname}")

print(f"\nAll passwords reset to: {new_password}")
print("Login with your username + this password now.")
