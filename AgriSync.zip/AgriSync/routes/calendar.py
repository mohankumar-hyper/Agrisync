from flask import Blueprint, request, jsonify, session
from database import get_db
import datetime

calendar_bp = Blueprint('calendar', __name__)

# Base crop harvest/growth periods in days
CROP_DURATIONS = {
    'rice': {"growth": 120, "first_fert": 25, "sec_fert": 55, "harvest": 120},
    'maize': {"growth": 100, "first_fert": 20, "sec_fert": 45, "harvest": 100},
    'chickpea': {"growth": 90, "first_fert": 15, "sec_fert": 40, "harvest": 90},
    'cotton': {"growth": 150, "first_fert": 30, "sec_fert": 75, "harvest": 150},
    'jute': {"growth": 110, "first_fert": 25, "sec_fert": 50, "harvest": 110},
    'coffee': {"growth": 365, "first_fert": 60, "sec_fert": 180, "harvest": 365}, # Perennial crop, annualized schedule
    'banana': {"growth": 300, "first_fert": 45, "sec_fert": 120, "harvest": 300},
    'coconut': {"growth": 365, "first_fert": 90, "sec_fert": 180, "harvest": 365}, # Perennial, annualized schedule
    'papaya': {"growth": 270, "first_fert": 30, "sec_fert": 90, "harvest": 270},
    'orange': {"growth": 365, "first_fert": 60, "sec_fert": 180, "harvest": 365}
}

@calendar_bp.route('/schedule', methods=['POST'])
def generate_schedule():
    data = request.get_json() or {}
    crop_type = data.get('crop_type', '').lower()
    sowing_date_str = data.get('sowing_date') # YYYY-MM-DD
    
    if not crop_type or not sowing_date_str:
        return jsonify({"success": False, "message": "Crop type and sowing date are required"}), 400
        
    try:
        sowing_date = datetime.datetime.strptime(sowing_date_str, "%Y-%m-%d")
    except ValueError:
        return jsonify({"success": False, "message": "Invalid sowing date format. Must be YYYY-MM-DD"}), 400
        
    db = get_db()
    if db is None:
        return jsonify({"success": False, "message": "Database connection failed"}), 500
        
    user_id = session.get('user_id', 'anonymous')
    duration_info = CROP_DURATIONS.get(crop_type, {"growth": 100, "first_fert": 20, "sec_fert": 50, "harvest": 100})
    
    # Calculate schedules
    sowing = sowing_date
    first_irr = sowing + datetime.timedelta(days=3)
    first_fert = sowing + datetime.timedelta(days=duration_info["first_fert"])
    sec_irr = sowing + datetime.timedelta(days=duration_info["sec_fert"] - 10)
    sec_fert = sowing + datetime.timedelta(days=duration_info["sec_fert"])
    harvesting = sowing + datetime.timedelta(days=duration_info["harvest"])
    
    calendar_events = [
        {"title": "Sowing Phase", "date": sowing.strftime("%Y-%m-%d"), "description": f"Sowing seeds for {crop_type.capitalize()} on prepared farmland."},
        {"title": "Initial Irrigation", "date": first_irr.strftime("%Y-%m-%d"), "description": "Conduct shallow watering to stimulate germination."},
        {"title": "First Nitrogen/NPK Application", "date": first_fert.strftime("%Y-%m-%d"), "description": "Apply first fertilizer dosage to boost vegetative leaf outgrowth."},
        {"title": "Secondary Mid-term Irrigation", "date": sec_irr.strftime("%Y-%m-%d"), "description": "Secondary comprehensive watering at critical tillering/flowering phase."},
        {"title": "Secondary Foliar/Topdress Fertilizer", "date": sec_fert.strftime("%Y-%m-%d"), "description": "Apply potassium and phosphorus to support panicle initiation."},
        {"title": "Harvesting Window", "date": harvesting.strftime("%Y-%m-%d"), "description": "Crops matured. Reap, thresh and store harvest safely."}
    ]
    
    calendar_doc = {
        "user_id": user_id,
        "crop_type": crop_type,
        "sowing_date": sowing_date_str,
        "events": calendar_events,
        "created_at": datetime.datetime.utcnow().isoformat()
    }
    
    try:
        # Save to crops/calendar log
        db.calendars.insert_one(calendar_doc)
        return jsonify({
            "success": True,
            "crop": crop_type.capitalize(),
            "sowing_date": sowing_date_str,
            "events": calendar_events
        }), 200
    except Exception as e:
        return jsonify({"success": False, "message": f"Failed to save calendar: {str(e)}"}), 500

@calendar_bp.route('', methods=['GET'])
def get_calendars():
    db = get_db()
    if db is None:
        return jsonify({"success": False, "message": "Database connection failed"}), 500
        
    user_id = session.get('user_id', 'anonymous')
    
    try:
        calendars = list(db.calendars.find({"user_id": user_id}).sort("created_at", -1))
        for c in calendars:
            c['_id'] = str(c['_id'])
        return jsonify({"success": True, "calendars": calendars})
    except Exception as e:
        return jsonify({"success": False, "message": f"Failed to get calendars: {str(e)}"}), 500
