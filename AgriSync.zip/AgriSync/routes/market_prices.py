from flask import Blueprint, jsonify
from database import get_db

market_prices_bp = Blueprint('market_prices', __name__)

@market_prices_bp.route('', methods=['GET'])
def get_market_prices():
    db = get_db()
    if db is None:
        return jsonify({"success": False, "message": "Database connection failed"}), 500

    try:
        prices = list(db.market_prices.find({}))
        for p in prices:
            p['_id'] = str(p['_id'])
        return jsonify({"success": True, "prices": prices})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500
