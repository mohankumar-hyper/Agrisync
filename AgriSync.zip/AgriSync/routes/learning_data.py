# -*- coding: utf-8 -*-
"""
AgriSync — Agriculture Learning Centre Database
Contains structured data for Crops, Videos, Stepped Guides, Quizzes, Images, and Downloads.
"""

# Crop details for the 13 required crops
CROP_AGRONOMY_TEMPLATES = {
    "rice": {
        "name": "Rice (Paddy / ಭತ್ತ / धान)",
        "overview": "Rice is the primary staple food crop, grown under waterlogged conditions in warm, humid regions.",
        "season": "Kharif (June to October) & Rabi (November to February)",
        "soil": "Clayey loam or alluvial soils with high water retention capacity (ideal pH 5.5 - 7.0)",
        "seed": "HYV seeds (IR-64, Basmati, Jyoti). Seed treatment with Thiram (3g/kg seed).",
        "prep": "Plough 2-3 times, puddle standing water to 5-10 cm to create an impermeable clay layer.",
        "sowing": "Transplanting 21-25 day old seedlings from nurseries with 15x15cm spacing.",
        "irrigation": "Maintain a submerged water level of 2-5 cm during the active vegetative growth phase.",
        "fertilizer": "NPK ratio of 120:60:40 kg/hectare. Top-dress nitrogen in three split doses.",
        "weed": "Apply Butachlor (1.5 kg/ha) or execute manual weeding 20 and 40 days after transplanting.",
        "pest": "Stem Borer, Leaf Folder, Blast disease. Spray Neem Oil or apply Carbofuran granules.",
        "harvest": "Harvest when 80% of grains in panicles turn golden yellow. Grain moisture should be 20-22%.",
        "storage": "Sun dry grains to 12-14% moisture before storing in clean gunny bags in ventilated granaries.",
        "yield": "Expected average yield: 4.5 - 6.0 Tons per hectare.",
        "schemes": "PM-KISAN, Restructured Weather Based Crop Insurance Scheme (RWBCIS).",
        "profit": "Estimated Cost: ₹45,000/ha. Gross Produce: ₹95,000/ha. Net profit: ₹50,000/ha.",
        "growing_regions": "West Bengal, Uttar Pradesh, Andhra Pradesh, Telangana, Punjab, Odisha, Bihar, Chhattisgarh, Tamil Nadu, Assam."
    },
    "wheat": {
        "name": "Wheat (ಗೋಧಿ / गेहूं)",
        "overview": "Wheat is the premier Rabi cereal crop, serving as a dietary backbone in northern and central regions.",
        "season": "Rabi (October to March)",
        "soil": "Well-drained fertile clayey loam or silty loam soils (pH 6.5 - 7.5)",
        "seed": "HD-2967, Lok-1, Shriram 252. Treat with Vitavax or Carbendazim.",
        "prep": "Deep ploughing followed by 2 light harrowings and planking to create a fine moist seedbed.",
        "sowing": "Line sowing using seed drills at 22.5cm spacing and a depth of 5cm.",
        "irrigation": "4-6 timely irrigations at critical Crown Root Initiation (CRI), tillering, and flowering stages.",
        "fertilizer": "NPK ratio of 120:60:40 kg/hectare. Apply complete P & K at sowing, nitrogen split into three parts.",
        "weed": "Apply Pendimethalin (1.0 kg/ha) pre-emergence or manual weeding after the first irrigation.",
        "pest": "Brown Rust, Aphids, Loose Smut. Spray Propiconazole 0.1% or Imidacloprid.",
        "harvest": "Harvest when spikes dry completely, straw turns golden yellow, and grains feel brittle.",
        "storage": "Store in airtight silos or steel bins with moisture level below 12% to prevent weevil attacks.",
        "yield": "Expected average yield: 3.5 - 5.0 Tons per hectare.",
        "schemes": "Rashtriya Krishi Vikas Yojana (RKVY), National Food Security Mission (NFSM).",
        "profit": "Estimated Cost: ₹35,000/ha. Gross Produce: ₹85,000/ha. Net profit: ₹50,000/ha.",
        "growing_regions": "Punjab, Haryana, Uttar Pradesh, Madhya Pradesh, Rajasthan, Bihar, Gujarat, Maharashtra."
    },
    "maize": {
        "name": "Maize (ಮಕ್ಕೆಜೋಳ / मक्का)",
        "overview": "Maize, known as the queen of cereals, is widely grown for food, grain, poultry feed, and industrial starch.",
        "season": "Kharif (June to Sept) & Rabi (Oct to Jan)",
        "soil": "Sandy loam to clay loam soils, deep, fertile, rich in organic matter (pH 5.8 - 7.5)",
        "seed": "Ganga-11, Deccan Hybrid, PMH-3. Treat with Carbendazim.",
        "prep": "Ploughing followed by harrowing, leveling, and creating ridges and furrows.",
        "sowing": "Ridge sowing at 60x20cm spacing with a seed rate of 20 kg/ha.",
        "irrigation": "Maintain soil moisture at flowering and grain-filling. Avoid waterlogging.",
        "fertilizer": "NPK ratio of 120:60:50 kg/ha. Apply Zinc Sulfate (25 kg/ha) if deficiency occurs.",
        "weed": "Apply Atrazine (1.0 kg/ha) as a pre-emergence spray.",
        "pest": "Fall Armyworm, Stem Borer. Spray Spinetoram or Bacillus thuringiensis (Bt).",
        "harvest": "Harvest when cob outer sheaths dry up and a black layer forms at the grain base.",
        "storage": "Shell cobs, dry grain to 12% moisture, and pack in polythene-lined jute bags.",
        "yield": "Expected average yield: 5.0 - 7.0 Tons per hectare.",
        "schemes": "NFSM-Coarse Cereals, PM-Fasal Bima Yojana.",
        "profit": "Estimated Cost: ₹40,000/ha. Gross Produce: ₹90,000/ha. Net profit: ₹50,000/ha.",
        "growing_regions": "Karnataka, Andhra Pradesh, Telangana, Maharashtra, Rajasthan, Bihar, Madhya Pradesh, Tamil Nadu."
    },
    "cotton": {
        "name": "Cotton (ಹತ್ತಿ / कपास)",
        "overview": "Cotton is the leading commercial fibre crop, requiring dry climate during maturation.",
        "season": "Kharif (May to October)",
        "soil": "Deep black clayey soils (Regur) with good water holding capacity (pH 6.0 - 8.0)",
        "seed": "Bt Cotton (hybrid). Seed treatment with Imidacloprid (5g/kg seed).",
        "prep": "Deep tillage up to 30 cm followed by 2-3 harrowings and application of farmyard manure.",
        "sowing": "Dibbling method, spacing 90x60cm or 120x60cm depending on soil fertility.",
        "irrigation": "Maintain light irrigations during flowering and boll development. Sensitive to flooding.",
        "fertilizer": "NPK ratio of 100:50:50 kg/ha. Top-dress nitrogen in split doses during squaring phase.",
        "weed": "Hand weeding at 20, 45, and 60 days. Pre-emergence spray of Pendimethalin.",
        "pest": "Bollworms (Pink, Spotted), Whitefly, Aphids. Use pheromone traps; spray Spinosad.",
        "harvest": "Harvest (picking) in morning hours when bolls are fully burst and dry.",
        "storage": "Store in dry godowns away from moisture and fire hazards. Pack in standardized cotton bales.",
        "yield": "Expected average yield: 1.5 - 2.5 Tons per hectare.",
        "schemes": "Technology Mission on Cotton (TMC), Cotton Development Programme under NFSM.",
        "profit": "Estimated Cost: ₹50,000/ha. Gross Produce: ₹1,10,000/ha. Net profit: ₹60,000/ha.",
        "growing_regions": "Gujarat, Maharashtra, Telangana, Andhra Pradesh, Madhya Pradesh, Karnataka, Rajasthan, Haryana."
    },
    "sugarcane": {
        "name": "Sugarcane (ಕಬ್ಬು / गन्ना)",
        "overview": "Sugarcane is a long-duration perennial cash crop crucial for the sugar and bio-ethanol industries.",
        "season": "Perennial (planted in Jan-March, takes 10-12 months)",
        "soil": "Deep, rich clay loams or alluvial soils with excellent drainage (pH 6.5 - 7.5)",
        "seed": "Use healthy sets with 2-3 active buds. Dip sets in Carbendazim solution before planting.",
        "prep": "Deep ploughing, subsoiling, and field layouts using furrows (depth of 20 cm) spaced at 90 cm.",
        "sowing": "Setts placed horizontally in furrows. Press gently and cover with 5 cm soil.",
        "irrigation": "High water requirement. Irrigate every 10-15 days, preferably using drip irrigation.",
        "fertilizer": "NPK ratio of 250:80:80 kg/ha. Apply organic compost during land prep.",
        "weed": "Apply Atrazine pre-emergence, followed by earthing up at 90-120 days post-planting.",
        "pest": "Early Shoot Borer, Red Rot disease. Treat sets; spray Trichogramma parasitoids.",
        "harvest": "Harvest using cane cutters when lower leaves dry and Brix hydrometer reads 18-20%.",
        "storage": "Crush harvested canes within 24 hours to prevent sucrose inversion and juice degradation.",
        "yield": "Expected average yield: 70 - 90 Tons per hectare.",
        "schemes": " Cane Development Scheme, Central Scheme for Sugar Development Fund Loans.",
        "profit": "Estimated Cost: ₹90,000/ha. Gross Produce: ₹2,40,000/ha. Net profit: ₹1,50,000/ha.",
        "growing_regions": "Uttar Pradesh, Maharashtra, Karnataka, Tamil Nadu, Andhra Pradesh, Bihar, Punjab, Haryana, Gujarat."
    },
    "tomato": {
        "name": "Tomato (ಟೊಮೆಟೊ / टमाटर)",
        "overview": "Tomatoes are a popular commercial vegetable cultivated widely for processing and fresh markets.",
        "season": "Rabi (Oct-Nov transplanting) & Spring (Feb-March transplanting)",
        "soil": "Sandy loam to clay loam, rich in organic humus, well-aerated (pH 6.0 - 7.0)",
        "seed": "Pusa Ruby, Arka Vikas, hybrid varieties. Treat with Captan (2g/kg seed).",
        "prep": "Plough to fine tilth. Add 20 tons of compost, raise beds of 120cm width.",
        "sowing": "Raise seedlings in nursery beds; transplant at 4-5 leaf stage under spacing of 60x45cm.",
        "irrigation": "Irrigate at intervals of 7-8 days in winter and 4-5 days in summer. Drip irrigation recommended.",
        "fertilizer": "NPK ratio of 100:60:60 kg/ha. Apply calcium nitrate to prevent blossom end rot.",
        "weed": "Manual weeding at 20 and 45 days. Mulch with silver-black plastic sheets.",
        "pest": "Fruit Borer, Early/Late Blight. Spray Neem Kernel Extract; apply Mancozeb.",
        "harvest": "Harvest at 'breaker stage' for distant markets, fully ripe red for direct local sales.",
        "storage": "Store at 12-15°C and 85-90% humidity. Avoid direct sunlight during ripening.",
        "yield": "Expected average yield: 25 - 40 Tons per hectare.",
        "schemes": "Mission for Integrated Development of Horticulture (MIDH).",
        "profit": "Estimated Cost: ₹60,000/ha. Gross Produce: ₹1,80,000/ha. Net profit: ₹1,20,000/ha.",
        "growing_regions": "Andhra Pradesh, Karnataka, Telangana, Odisha, Maharashtra, West Bengal, Gujarat, Madhya Pradesh."
    },
    "onion": {
        "name": "Onion (ಈರುಳ್ಳಿ / प्याज)",
        "overview": "Onion is an indispensable crop grown both for local culinary uses and high-volume exports.",
        "season": "Late Kharif (Aug-Sept) & Rabi (Oct-Nov transplanting)",
        "soil": "Deep friable sandy loam soils, rich in organic matter, free from stones (pH 6.0 - 7.5)",
        "seed": "Agrifound Dark Red, N-53, Bhima Super. Seed rate: 8-10 kg/ha for seedlings.",
        "prep": "Plough 4-5 times, level fields, prepare flat beds or broad-bed furrows.",
        "sowing": "Transplant 6-8 week old nurseries, spaced at 15x10cm. Do not plant too deep.",
        "irrigation": "Frequent light irrigations at 10-day intervals. Stop irrigation 15 days before harvesting.",
        "fertilizer": "NPK ratio of 100:50:50 kg/ha, with 50 kg Sulfur per hectare for bulb pungency.",
        "weed": "Apply Oxyfluorfen (0.25 kg/ha) or manually weed twice.",
        "pest": "Thrips, Purple Blotch. Spray Fipronil or Carbendazim + Mancozeb.",
        "harvest": "Harvest when 50-70% bulb necks collapse (neck fall stage). Cut leaves leaving 2cm stem.",
        "storage": "Shade cure for 3-5 days. Store in well-ventilated bamboo racks (chawls) at low humidity.",
        "yield": "Expected average yield: 15 - 25 Tons per hectare.",
        "schemes": "MIDH, Price Stabilization Fund (PSF) buffer storage incentive program.",
        "profit": "Estimated Cost: ₹55,000/ha. Gross Produce: ₹1,35,000/ha. Net profit: ₹80,000/ha.",
        "growing_regions": "Maharashtra, Karnataka, Madhya Pradesh, Gujarat, Rajasthan, Bihar, Andhra Pradesh, Telangana."
    },
    "potato": {
        "name": "Potato (ಆಲೂಗಡ್ಡೆ / आलू)",
        "overview": "Potato is one of the most widely consumed tuber vegetables, demanding high soil aeration.",
        "season": "Winter Rabi (October to February)",
        "soil": "Loose, friable sandy loam, rich in organic matter (pH 5.2 - 6.4 for scab reduction)",
        "seed": "Kufri Jyoti, Kufri Bahar, Kufri Pukhraj. Treat seed tubers with Mancozeb (0.25%).",
        "prep": "Deep tiling, incorporate green manure, build ridges and furrows spaced at 60cm.",
        "sowing": "Plant sprouted seed tubers on ridges at 20cm plant-to-plant distance.",
        "irrigation": "Keep soil moist but not soggy. Stop watering 10 days before harvest.",
        "fertilizer": "NPK ratio of 150:80:120 kg/ha. Hilling or earthing up should be done at 30 days.",
        "weed": "Pre-emergence herbicide Metribuzin (0.75 kg/ha) or mechanical earthing.",
        "pest": "Late Blight, Potato Tuber Moth. Spray Metalaxyl or Mancozeb; keep tubers covered.",
        "harvest": "Dehalming (cutting vines) 10 days before harvesting to harden scope skins.",
        "storage": "Cure at 15°C for 10 days, store in cold storage facilities at 2-4°C.",
        "yield": "Expected average yield: 20 - 30 Tons per hectare.",
        "schemes": "NHB Cold Chain Infrastructure Subsidies, MIDH.",
        "profit": "Estimated Cost: ₹75,000/ha. Gross Produce: ₹1,85,000/ha. Net profit: ₹1,10,000/ha.",
        "growing_regions": "Uttar Pradesh, West Bengal, Bihar, Punjab, Madhya Pradesh, Gujarat, Haryana, Himachal Pradesh."
    },
    "chilli": {
        "name": "Chilli (ಮೆಣಸಿನಕಾಯಿ / मिर्च)",
        "overview": "Chilli is cultivable as a cash spice and vegetable, requiring hot conditions during ripening.",
        "season": "Kharif (June sowing) & Rabi (September transplantation)",
        "soil": "Well-drained sandy loam or black soils with good drainage (pH 6.5 - 7.5)",
        "seed": "Pusa Jwala, Arka Harita, G-4. Treat with Trichoderma (4g/kg seed).",
        "prep": "Plough 3-4 times. Incorporate well-rotted farmyard manure during final layout.",
        "sowing": "Transplant seedlings at 60x45cm spacing in flat beds or ridged layouts.",
        "irrigation": "Avoid stagnant water; irrigate only when soil top-crust dries. Drip setups are ideal.",
        "fertilizer": "NPK ratio of 80:40:40 kg/ha. Apply potash in split doses to improve colour and yield.",
        "weed": "Hand weeding at 20 and 45 days. Mulching suppresses weeds and retains soil moisture.",
        "pest": "Thrips, Mites, Die-back disease. Spray Fipronil or wettable Sulfur.",
        "harvest": "Pluck green chillies for vegetable sales, let turn bright red for spice drying.",
        "storage": "Sun-dry red chillies on clean mats to 10% moisture. Store in dry gunny bags.",
        "yield": "Expected average yield: 1.5 - 2.5 Tons (dry chillies) per hectare.",
        "schemes": "National Agriculture Development Scheme (RKVY), Spices Board incentives.",
        "profit": "Estimated Cost: ₹45,000/ha. Gross Produce: ₹1,25,000/ha. Net profit: ₹80,000/ha.",
        "growing_regions": "Andhra Pradesh, Telangana, Karnataka, Tamil Nadu, Maharashtra, Rajasthan, Odisha, West Bengal."
    },
    "groundnut": {
        "name": "Groundnut (ನೆಲಗಡಲೆ / मूंगफली)",
        "overview": "Groundnut is a premium oilseed crop that incorporates nitrogen into soil systems.",
        "season": "Kharif (June to Sept) & Rabi (Oct to Jan)",
        "soil": "Well-drained light sandy loam or red sandy soils, loose for pod penetration (pH 6.0 - 7.0)",
        "seed": "TAG-24, JL-24, Kadiri-6, G-201. Shell pods manually before sowing; treat seeds.",
        "prep": "Plough twice, harrowing, and leveling to get a stone-free seedbed.",
        "sowing": "Sow seeds at 30x10cm spacing at a depth of 5cm using seed drills.",
        "irrigation": "Rainfed in Kharif. Key phases: flowering, pegging, and pod development.",
        "fertilizer": "NPK ratio of 25:50:25 kg/ha. Apply Gypsum (500 kg/ha) at pegging stage to enrich calcium.",
        "weed": "Apply Fluchloralin pre-emergence. Do not weed after pegging begins.",
        "pest": "White Grub, Leaf Miner, Tikka leaf spot. Apply Carbofuran; spray Carbendazim.",
        "harvest": "Harvest when leaves turn yellow and inner shell of pods exhibits black color.",
        "storage": "Dry pods to 8% moisture level to prevent yellow mould (Aflatoxin).",
        "yield": "Expected average yield: 2.0 - 3.0 Tons per hectare.",
        "schemes": "NMOOP (National Mission on Oilseeds and Oil Palm).",
        "profit": "Estimated Cost: ₹35,000/ha. Gross Produce: ₹85,000/ha. Net profit: ₹50,000/ha.",
        "growing_regions": "Gujarat, Andhra Pradesh, Rajasthan, Tamil Nadu, Karnataka, Madhya Pradesh, Maharashtra, Uttar Pradesh."
    },
    "millets": {
        "name": "Millets (ರಾಗಿ/ಸಜ್ಜೆ / बाजरा/रागी)",
        "overview": "Millets (Ragi, Bajra, Jowar) are climate-resilient, dryland crops rich in micro-nutrients.",
        "season": "Kharif (June to October) - highly drought resistant",
        "soil": "Inferior shallow soils, sandy or red gravelly loams, well-drained (pH 5.5 - 7.5)",
        "seed": "GPU-28 (Ragi), ICTP-8203 (Bajra). Treat with Azospirillum bio-fertilizer.",
        "prep": "Plough 2 times, build shallow seed beds, apply compost.",
        "sowing": "Line sowing or broadcasting, spacing 45x15cm (Bajra) or 30x10cm (Ragi). Depth 2-3 cm.",
        "irrigation": "Primarily rainfed. Requires critical irrigation only if dry spell exceeds 20 days.",
        "fertilizer": "NPK ratio of 60:30:30 kg/ha. Highly responsive to organic compost and bio-inoculants.",
        "weed": "Manual hand weeding at 20 days. Spray Isoproturon.",
        "pest": "Shoot Fly, Stem Borer. Intercrop with legumes to minimize pest pressure.",
        "harvest": "Cut earheads when grains are hard and dry straw turns brownish-yellow.",
        "storage": "Store grains at moisture levels below 10-12% in airtight containers.",
        "yield": "Expected average yield: 2.0 - 3.5 Tons per hectare.",
        "schemes": "Initiative for Nutritional Security through Intensive Millet Promotion (INSIMP).",
        "profit": "Estimated Cost: ₹20,000/ha. Gross Produce: ₹55,000/ha. Net profit: ₹35,000/ha.",
        "growing_regions": "Rajasthan, Maharashtra, Karnataka, Andhra Pradesh, Gujarat, Madhya Pradesh, Tamil Nadu, Telangana."
    },
    "banana": {
        "name": "Banana (ಬಾಳೆಹಣ್ಣು / केला)",
        "overview": "Banana is a high-demand tropical fruit crop cultivated with tissue culture plants.",
        "season": "Year-round planting (damp seasons starting in June-Dec are best)",
        "soil": "Rich clay loam, deep, well-drained, rich in organic matter (pH 6.5 - 7.5)",
        "seed": "Use tissue culture plantlets or sword suckers (weight 500-700g). Treat sucker with Carbofuran.",
        "prep": "Dig pits of size 45x45x45cm. Fill with 10 kg farmyard manure and topsoil.",
        "sowing": "Plant plantlet in the center of pit. Spacing 1.8x1.8m. Earth up to prevent lodging.",
        "irrigation": "Very high water requirement. Drip irrigate daily (15-20 litres/plant/day).",
        "fertilizer": "Apply NPK ratio of 200:50:300 g/plant. Micronutrients (Boron, Zinc) prevent tip chlorosis.",
        "weed": "Hand weeding. Grow cowpea as green manure in spaces between plants.",
        "pest": "Pseudostem Weevil, Panama Wilt. Inoculate with Trichoderma; inject Monocrotophos into pseudostem.",
        "harvest": "Harvest bunches 11-13 months after planting when angles of fruits turn rounded.",
        "storage": "Hang bunches in shade at 13-15°C. Avoid keeping below 10°C to prevent chilling injury.",
        "yield": "Expected average yield: 40 - 50 Tons per hectare.",
        "schemes": "MIDH, NHB Drip Irrigation and Cold Chain schemes.",
        "profit": "Estimated Cost: ₹1,20,000/ha. Gross Produce: ₹3,20,000/ha. Net profit: ₹2,00,000/ha.",
        "growing_regions": "Tamil Nadu, Kerala, Andhra Pradesh, Maharashtra, Gujarat, Karnataka, West Bengal, Assam, Bihar."
    },
    "mango": {
        "name": "Mango (ಮಾವು / आम)",
        "overview": "Mango, the king of fruits, is a perennial orchard crop thriving in dry, warm summers.",
        "season": "Perennial (plant saplings in July-August monsoon)",
        "soil": "Deep, fertile alluvial or laterite soils with no hard pan up to 2m depth (pH 5.5 - 7.5)",
        "seed": "Use stone-grafted saplings of Alphonso, Kesar, Banganapalli. Treat roots with fungicide.",
        "prep": "Dig large pits of 1x1x1m spaced at 8-10m. Fill with topsoil, organic manure, and bone meal.",
        "sowing": "Plant graft union 15cm above soil level. Stake orchard trees for stability.",
        "irrigation": "Irrigate young plants regularly. Mature trees require water during fruit development.",
        "fertilizer": "Apply 100g N, 50g P, and 100g K per plant per year of age, up to 10 years.",
        "weed": "Inter-ploughing and cover cropping. Keep tree basin clean.",
        "pest": "Mango Hopper, Powdery Mildew. Spray Imidacloprid or wettable Sulfur during flowering.",
        "harvest": "Harvest manually using pole harvesters with nets when fruits show slight color break.",
        "storage": "Desap harvested mangoes. Hot water treatment (52°C) prevents post-harvest rot.",
        "yield": "Expected average yield: 8.0 - 15.0 Tons per hectare (mature orchard).",
        "schemes": "National Horticulture Mission (NHM), APEDA Export Cluster incentives.",
        "profit": "Estimated Cost: ₹80,000/ha (annual maintenance). Gross Produce: ₹2,20,000/ha. Net profit: ₹1,40,000/ha.",
        "growing_regions": "Andhra Pradesh, Telangana, Karnataka, Maharashtra, Gujarat, Tamil Nadu, Bihar, Odisha, West Bengal."
    },
    "mustard": {
        "name": "Mustard (ಸಾಸಿವೆ / सरसों)",
        "overview": "Mustard is a major winter (Rabi) oilseed crop grown extensively in Northern and Western India, valued for its oil and oilcake.",
        "season": "Rabi (October to March)",
        "soil": "Well-drained sandy loam or clay loam soils (ideal pH 6.0 - 7.5)",
        "seed": "HYV/Hybrid seeds (Pusa Mustard, DMH-11, RH-749). Seed treatment with Metalaxyl.",
        "prep": "Plough 2-3 times to create a fine tilth. Ensure sufficient soil moisture before sowing.",
        "sowing": "Line sowing at 30x10 cm spacing at a depth of 3-4 cm using seed drills.",
        "irrigation": "Low water requirement. 2 critical irrigations: one at flowering (30-40 days) and one at siliqua development.",
        "fertilizer": "NPK ratio of 80:40:40 kg/ha. Apply Sulfur (20-30 kg/ha) is critical for oil percentage.",
        "weed": "Apply Pendimethalin (1.0 kg/ha) pre-emergence followed by intercultural operations at 20-25 days.",
        "pest": "Mustard Aphids, Alternaria Blight. Spray Dimethoate or Mancozeb.",
        "harvest": "Harvest when leaves and pods (siliquae) turn golden yellow and seeds rattle inside.",
        "storage": "Thresh and dry seeds to below 8% moisture before storing in clean dry gunny bags.",
        "yield": "Expected average yield: 1.5 - 2.2 Tons per hectare.",
        "schemes": "National Mission on Oilseeds and Oil Palm (NMOOP), PM-KISAN.",
        "profit": "Estimated Cost: ₹25,000/ha. Gross Produce: ₹65,000/ha. Net profit: ₹40,000/ha.",
        "growing_regions": "Rajasthan, Haryana, Madhya Pradesh, Uttar Pradesh, West Bengal, Gujarat, Punjab, Assam."
    },
    "chickpea": {
        "name": "Chickpea (Gram / ಕಡಲೆ / चना)",
        "overview": "Chickpea is the premier rabi pulse crop of India, serving as a primary protein source and improving soil fertility via nitrogen fixation.",
        "season": "Rabi (October to April)",
        "soil": "Well-drained light to medium-textured soils, clay loam, or mixed soils (pH 6.0 - 9.0)",
        "seed": "Pusa 372, JG-11, JAKI 9218. Treat seeds with Rhizobium culture and Trichoderma.",
        "prep": "Prepare seedbed with one deep ploughing followed by harrowing, keeping soil cloddy to allow aeration.",
        "sowing": "Sow in lines at 30x10cm spacing, depth of 8-10cm to prevent wilt disease.",
        "irrigation": "Requires low water. Usually 2 irrigations: at branching (30 days) and pod development stage.",
        "fertilizer": "NPK ratio of 20:50:20 kg/ha. Needs starter nitrogen; fixes its own nitrogen.",
        "weed": "Hand weeding at 30 days or pre-emergence application of Pendimethalin.",
        "pest": "Pod Borer, Fusarium Wilt. Spray NPV (Nuclear Polyhedrosis Virus) or Neem oil.",
        "harvest": "Harvest when plants turn reddish-brown and leaves start shedding.",
        "storage": "Dry seeds to below 9-10% moisture. Store in dry airtight structures with neem leaves.",
        "yield": "Expected average yield: 1.2 - 2.0 Tons per hectare.",
        "schemes": "NFSM-Pulses, PMFBY.",
        "profit": "Estimated Cost: ₹22,000/ha. Gross Produce: ₹62,000/ha. Net profit: ₹40,000/ha.",
        "growing_regions": "Madhya Pradesh, Maharashtra, Rajasthan, Karnataka, Andhra Pradesh, Uttar Pradesh, Gujarat."
    },
    "turmeric": {
        "name": "Turmeric (ಅರಿಶಿನ / हल्दी)",
        "overview": "Turmeric is a high-value spice and medicinal herb grown for its underground rhizomes, requiring hot, humid climates.",
        "season": "Kharif (planted during May-July, takes 7-9 months)",
        "soil": "Well-drained sandy loam, gravelly loam, or clayey loam soils, rich in organic matter (pH 5.0 - 7.5)",
        "seed": "Use healthy mother or finger rhizomes (weight 30-40g). Treat seeds with Mancozeb.",
        "prep": "Deep ploughing, incorporate 25 tons of FYM, build raised beds of 1.2m width.",
        "sowing": "Plant rhizomes in shallow pits at 30x30cm spacing, cover with soil and mulch.",
        "irrigation": "Requires moderate to high irrigation. Drip irrigation every 7-10 days depending on soil type.",
        "fertilizer": "NPK ratio of 60:50:120 kg/ha. Apply organic neem cake during land prep.",
        "weed": "Manual weeding 3-4 times. Earthing up must be done at 60 and 90 days post-planting.",
        "pest": "Rhizome Rot, Leaf Spot, Shoot Borers. Apply Trichoderma to soil; spray Carbendazim.",
        "harvest": "Harvest when leaves yellow and dry completely. Dig out rhizomes carefully.",
        "storage": "Boil, dry, and polish rhizomes. Store in ventilated dark rooms or pits.",
        "yield": "Expected average yield: 20 - 25 Tons (raw fresh rhizome) per hectare.",
        "schemes": "Spices Board subsidies, NHM.",
        "profit": "Estimated Cost: ₹80,000/ha. Gross Produce: ₹2,30,000/ha. Net profit: ₹1,40,000/ha.",
        "growing_regions": "Telangana, Andhra Pradesh, Tamil Nadu, Karnataka, Kerala, Odisha, West Bengal, Maharashtra, Assam."
    }
}

# Alias keys for chatbot/assistant lookup
CROP_AGRONOMY_TEMPLATES["paddy"] = CROP_AGRONOMY_TEMPLATES["rice"]
CROP_AGRONOMY_TEMPLATES["sugar cane"] = CROP_AGRONOMY_TEMPLATES["sugarcane"]

def get_crop_agronomy(crop_key):
    """Retrieve detailed agronomic profile for any of the 18 crops."""
    crop_key = crop_key.lower().strip()
    if crop_key in CROP_AGRONOMY_TEMPLATES:
        return CROP_AGRONOMY_TEMPLATES[crop_key]
    
    # Simple search if key is matching partly, e.g. "paddy" -> rice
    if "paddy" in crop_key or "bhath" in crop_key:
        return CROP_AGRONOMY_TEMPLATES["rice"]
    if "ragi" in crop_key or "bajra" in crop_key:
        return CROP_AGRONOMY_TEMPLATES["millets"]
        
    # Default fallback
    title = crop_key.capitalize()
    return {
        "name": title,
        "overview": f"{title} is a vital agricultural crop grown under regions with modern management practices.",
        "season": "Sowing season based on region (Kharif/Rabi/Zaid).",
        "soil": "Sandy loam or loamy soils with optimal drainage (pH 6.0 - 7.0)",
        "seed": "High quality hybrid certified seeds. Treat seeds with bio-pesticides before sowing.",
        "prep": "Deep ploughing, leveling, and incorporating well-rotted farmyard manure.",
        "sowing": "Line sowing or ridge spacing optimized for crop type.",
        "irrigation": "Irrigate at critical growth stages, ensuring no waterlogging.",
        "fertilizer": "Balanced NPK application according to soil test health indicators.",
        "weed": "Manual weeding at 20-30 days interval or pre-emergence selective herbicides.",
        "pest": "Apply dynamic integrated pest management (IPM) guidelines.",
        "harvest": "Harvest at full physiological maturity, sun drying appropriately.",
        "storage": "Store in clean, moisture-proof containers in dry aerated yards.",
        "yield": "Yield averages 2.5 to 5.0 Tons/Hectare based on irrigation quality.",
        "schemes": "PM-Fasal Bima Yojana (PMFBY), regional seed subsidies.",
        "profit": "Estimated Cost: ₹40,000/ha. Gross: ₹90,000/ha. Net: ₹50,000/ha.",
        "growing_regions": "All major agricultural states of India (Karnataka, Maharashtra, Punjab, Haryana, Uttar Pradesh, Andhra Pradesh etc.)."
    }

# Video Database mapped to all the requested categories
VIDEOS = [
    {
        "id": "v1",
        "title": "Drip Irrigation Controller & Pipeline Installation Guide",
        "duration": "12:45",
        "language": "English",
        "views": "15,420",
        "category": "Drip Irrigation",
        "youtube_id": "8M_g7T1m_xY",
        "thumbnail": "https://img.youtube.com/vi/8M_g7T1m_xY/0.jpg"
    },
    {
        "id": "v2",
        "title": "Organic Farming & Natural Insect Repellent Sprays (सजीव खेती)",
        "duration": "14:10",
        "language": "Hindi",
        "views": "32,940",
        "category": "Organic Farming",
        "youtube_id": "2OphuU4sBvI",
        "thumbnail": "https://img.youtube.com/vi/2OphuU4sBvI/0.jpg"
    },
    {
        "id": "v3",
        "title": "Vermicompost Production Steps (ಮರೆಗೊಬ್ಬರ ತಯಾರಿ ವಿಧಾನ)",
        "duration": "18:20",
        "language": "Kannada",
        "views": "45,210",
        "category": "Vermicomposting",
        "youtube_id": "z8R1lObmR0s",
        "thumbnail": "https://img.youtube.com/vi/z8R1lObmR0s/0.jpg"
    },
    {
        "id": "v4",
        "title": "Smart Farming: Precision Fertilizer Dosing & Fertigation Systems",
        "duration": "10:30",
        "language": "English",
        "views": "8,700",
        "category": "Fertigation",
        "youtube_id": "l9c4O93N8Kk",
        "thumbnail": "https://img.youtube.com/vi/l9c4O93N8Kk/0.jpg"
    },
    {
        "id": "v5",
        "title": "Dairy Farming Business Plan & Barn Layout (डेयरी फार्मिंग सीखें)",
        "duration": "22:15",
        "language": "Hindi",
        "views": "122,890",
        "category": "Dairy Farming",
        "youtube_id": "yO_L2F4m8xY",
        "thumbnail": "https://img.youtube.com/vi/yO_L2F4m8xY/0.jpg"
    },
    {
        "id": "v6",
        "title": "Hydroponic Lettuce Cultivation For Beginners",
        "duration": "15:50",
        "language": "English",
        "views": "54,300",
        "category": "Hydroponics",
        "youtube_id": "k1gGqM24u6E",
        "thumbnail": "https://img.youtube.com/vi/k1gGqM24u6E/0.jpg"
    },
    {
        "id": "v7",
        "title": "Mushroom Farming Step-by-Step Spawn Inoculation & Growing",
        "duration": "13:00",
        "language": "Hindi",
        "views": "92,110",
        "category": "Mushroom Farming",
        "youtube_id": "xG8F4C6i9d8",
        "thumbnail": "https://img.youtube.com/vi/xG8F4C6i9d8/0.jpg"
    },
    {
        "id": "v8",
        "title": "Poultry Layer Management and Egg Production Hacks (ಕೋಳಿ ಸಾಕಾಣಿಕೆ)",
        "duration": "16:40",
        "language": "Kannada",
        "views": "12,900",
        "category": "Poultry Farming",
        "youtube_id": "v9c7Iobm8sY",
        "thumbnail": "https://img.youtube.com/vi/v9c7Iobm8sY/0.jpg"
    },
    {
        "id": "v9",
        "title": "Soil Health Management - Test Collecting and pH Balance",
        "duration": "11:20",
        "language": "English",
        "views": "28,700",
        "category": "Soil Health",
        "youtube_id": "sY97Q0wW6K4",
        "thumbnail": "https://img.youtube.com/vi/sY97Q0wW6K4/0.jpg"
    },
    {
        "id": "v10",
        "title": "Compost Making in 18 Days (Berkley Method)",
        "duration": "09:40",
        "language": "English",
        "views": "19,250",
        "category": "Compost Making",
        "youtube_id": "1mStEeG8qfI",
        "thumbnail": "https://img.youtube.com/vi/1mStEeG8qfI/0.jpg"
    },
    {
        "id": "v11",
        "title": "Greenhouse Farming Structure Assembly & Climate Control",
        "duration": "20:15",
        "language": "Hindi",
        "views": "41,300",
        "category": "Greenhouse Farming",
        "youtube_id": "jDqPz7zS3M0",
        "thumbnail": "https://img.youtube.com/vi/jDqPz7zS3M0/0.jpg"
    },
    {
        "id": "v12",
        "title": "Goat Farming Business Planning Guide (बकरी पालन कैसे शुरू करें)",
        "duration": "17:35",
        "language": "Hindi",
        "views": "72,800",
        "category": "Goat Farming",
        "youtube_id": "5qZ1L68OexI",
        "thumbnail": "https://img.youtube.com/vi/5qZ1L68OexI/0.jpg"
    },
    {
        "id": "v13",
        "title": "Beekeeping & Modern Honey Harvesting Methods (ಜೇನು ಸಾಕಾಣಿಕೆ)",
        "duration": "14:50",
        "language": "Kannada",
        "views": "24,600",
        "category": "Beekeeping",
        "youtube_id": "p5w9kQ0ZgMs",
        "thumbnail": "https://img.youtube.com/vi/p5w9kQ0ZgMs/0.jpg"
    },
    {
        "id": "v14",
        "title": "Precision Agriculture & GPS Drone Spraying Demos",
        "duration": "08:15",
        "language": "English",
        "views": "33,100",
        "category": "Precision Agriculture",
        "youtube_id": "7wz4kQ2C034",
        "thumbnail": "https://img.youtube.com/vi/7wz4kQ2C034/0.jpg"
    },
    {
        "id": "v15",
        "title": "Smart Farming: IoT Sensors and AI in Crop Management",
        "duration": "13:50",
        "language": "English",
        "views": "52,400",
        "category": "Smart Farming using AI",
        "youtube_id": "0D2B4A11q8s",
        "thumbnail": "https://img.youtube.com/vi/0D2B4A11q8s/0.jpg"
    },
    {
        "id": "v16",
        "title": "Government Agriculture Programs & Farm Subsidies Scheme Apply Guide",
        "duration": "19:10",
        "language": "Hindi",
        "views": "115,000",
        "category": "Government Agriculture Programs",
        "youtube_id": "9xYy_W89m9o",
        "thumbnail": "https://img.youtube.com/vi/9xYy_W89m9o/0.jpg"
    },
    {
        "id": "v17",
        "title": "Subhash Palekar Natural Farming Methodologies (ಶೂನ್ಯ ಬಂಡವಾಳ ಕೃಷಿ)",
        "duration": "24:30",
        "language": "Kannada",
        "views": "86,000",
        "category": "Natural Farming",
        "youtube_id": "g-B9K0Lq3fE",
        "thumbnail": "https://img.youtube.com/vi/g-B9K0Lq3fE/0.jpg"
    }
]

# Step-by-Step Farming Guides
GUIDES = [
    {
        "id": "g1",
        "title": "Setting up a Drip Irrigation System",
        "time": "4-6 Hours",
        "tools": "Drip tapes, Sub-main pipes, Connector valves, Hole punch tool, End caps, Screen Filter",
        "steps": [
            {"num": 1, "desc": "Map out lateral drip layout according to row spacing of major crop."},
            {"num": 2, "desc": "Lay the sub-main PVC pipes and install the main screen/disc filter systems."},
            {"num": 3, "desc": "Punch 12mm holes into the sub-main pipes and insert lateral take-off values."},
            {"num": 4, "desc": "Unroll and stretch drip tape tubes alongside crop crop rows."},
            {"num": 5, "desc": "Flush the system with high pressure water. Place end closures at laterals."}
        ],
        "tips": "Wash filter elements weekly to prevent sand, algae, or silt blockage inside emitter outputs.",
        "mistakes": "Avoid pulling drip tapes too tight. Soil movement and thermal contraction in cold snaps can snap joints."
    },
    {
        "id": "g2",
        "title": "Vermicompost Production setup",
        "time": "2-3 Hours initial setup",
        "tools": "Earthworms (Eisenia Fetida), Composting bed, Dry crop residues/organic wastes, Cow dung, Water sprinkler",
        "steps": [
            {"num": 1, "desc": "Lay a polythene vermi-bed (size 10x4x2 ft) on level ground under high shade."},
            {"num": 2, "desc": "Create a bottom 6-inch bedding layer utilizing chopped dry straw and dry leaves."},
            {"num": 3, "desc": "Mix water into partially digested cow dung compost to cool down, lay 12-inch layer."},
            {"num": 4, "desc": "Release 2-3 kg of vermiworms uniformly over the bed surface."},
            {"num": 5, "desc": "Cover with damp gunny bags. Sprinkle water regularly to preserve 60-70% humidity."}
        ],
        "tips": "A shading roof is mandatory to block direct solar heat, keeping bed temperature below 30 degrees C.",
        "mistakes": "Adding hot, fresh cow dung directly. Ammonia gas and thermal fermentation output kills earthworms instantly."
    }
]

# Lesson Quizzes
QUIZZES = {
    "organic": [
        {
            "id": 1,
            "q": "Which bio-agent is widely used for biological management of fungal crop leaf pathogens?",
            "opt": ["Trichoderma viride", "Pseudomonas solanacearum", "E. coli", "Xanthomonas"],
            "ans": 0,
            "exp": "Trichoderma species are strong antagonistic fungi that destroy pathogen cell walls."
        },
        {
            "id": 2,
            "q": "Panchagavya contains which main cow product?",
            "opt": ["Urea chemical", "Cow Urine & Dung", "Epsom Salt", "Gypsum"],
            "ans": 1,
            "exp": "Panchagavya is formulated using five cow-derived products: cow dung, urine, milk, curd, and ghee."
        },
        {
            "id": 3,
            "q": "What is the recommended period for composting using earthworms?",
            "opt": ["5 Days", "60-90 Days", "1 Year", "2 Weeks"],
            "ans": 1,
            "exp": "Vermicomposting takes about 2 to 3 months (60-90 days) for complete transformation."
        }
    ],
    "irrigation": [
        {
            "id": 1,
            "q": "Which irrigation system delivers up to 90% water application efficiency?",
            "opt": ["Flood Irrigation", "Drip Irrigation", "Furrow Irrigation", "Canal flooding"],
            "ans": 1,
            "exp": "Drip irrigation feeds water directly to crop root zones, reducing evaporation."
        },
        {
            "id": 2,
            "q": "What component is essential in drip lines to prevent sand clogging?",
            "opt": ["Pressure Regulator", "Disc or Mesh Filter", "Air Release valve", "Check Pipe"],
            "ans": 1,
            "exp": "Filters keep particles away, maintaining consistent emitter flow rates."
        }
    ]
}

# Image comparison library
IMAGES = [
    {
        "id": "img1",
        "title": "Rice Blast vs Healthy Paddy",
        "desc": "Paddy fields are severely impacted by Blast (Magnaporthe oryzae). Comparison highlights diamond-shaped lesions.",
        "healthy_img": "/static/uploads/seed_default.jpg",
        "diseased_img": "/static/uploads/seed_default.jpg",
        "indicators": ["Spindle-shaped spots on leaves", "Gray-green centers", "Brown borders"]
    },
    {
        "id": "img2",
        "title": "Nitrogen Status Leaves",
        "desc": "Displays nitrogen deficiency (yellow V-shape patterns) compared with rich dark green healthy leaf.",
        "healthy_img": "/static/uploads/seed_default.jpg",
        "diseased_img": "/static/uploads/seed_default.jpg",
        "indicators": ["Chlorosis starting from old leaves", "Stunted growth stems", "Light grass green coloring"]
    }
]

# Downloads Centre
DOWNLOADS = [
    {"title": "Integrated Organic Pest Management Manual", "type": "PDF Guide", "size": "2.4 MB", "link": "/api/learning/download/pesticide-guide.pdf"},
    {"title": "Kharif Soil Enrichment Calendar 2026", "type": "Printable Calendar", "size": "1.8 MB", "link": "/api/learning/download/planting-calendar.pdf"},
    {"title": "Government Subsidies and Solar Schemes India", "type": "Govt Brochure", "size": "3.1 MB", "link": "/api/learning/download/solar-subsidies.pdf"}
]


# ── GENETICALLY MODIFIED (GM) PLANTS DATABASE ────────────────────────────────
GM_PLANTS = [
    {
        "id": "gm1",
        "name": "Bt Cotton (ಬಿಟಿ ಹತ್ತಿ / बीटी कपास)",
        "common_name": "Bt Cotton",
        "icon": "fa-broom",
        "tag_color": "green",
        "status_badge": "Commercially Approved",
        "what_is_gm": "Bt Cotton is genetically engineered to express a toxin derived from the bacterium Bacillus thuringiensis (Bt). This protein is lethal to bollworm larvae but safe for humans, animals and beneficial insects.",
        "genetic_modification": "Scientists inserted the cry1Ac and cry2Ab genes from Bacillus thuringiensis into the cotton genome using Agrobacterium-mediated transformation. These genes produce insecticidal Cry proteins (δ-endotoxins) that specifically destroy the gut lining of target Lepidopteran pest larvae (bollworms), killing them within 24-48 hours of ingestion.",
        "modification_method": "Agrobacterium tumefaciens-mediated gene transfer",
        "genes_inserted": "cry1Ac, cry2Ab (from Bacillus thuringiensis var. kurstaki)",
        "traits_added": "Bollworm resistance (Pink, Spotted, American Bollworm protection)",
        "growing_regions": "Maharashtra, Gujarat, Telangana, Andhra Pradesh, Karnataka, Madhya Pradesh, Punjab, Haryana, Rajasthan. India is the world's largest Bt Cotton producer, with 95%+ area under Bt cultivation.",
        "climate": "Tropical & sub-tropical dry climate, temperatures 21-35°C, 500-900mm annual rainfall.",
        "soil": "Deep black cotton soils (Regur/Vertisols), well-drained sandy loam, pH 6.0-8.0.",
        "benefits": [
            "Reduces pesticide sprays by 40-60%, saving significant input costs.",
            "Protects crop yield losses caused by bollworms (up to 30-40% loss prevented).",
            "Reduces farmer occupational pesticide exposure and health risks.",
            "Higher yield consistency per hectare compared to non-Bt hybrids."
        ],
        "concerns": [
            "Risk of secondary pest outbreaks (sucking pests like whitefly, mealybug).",
            "Development of Bt resistance in bollworm populations over time.",
            "Higher seed cost than conventional varieties.",
            "Impact on non-target organisms if proteins enter soil ecosystem."
        ],
        "regulatory_status": "Approved by GEAC (Genetic Engineering Appraisal Committee) under India's Ministry of Environment. The first GM crop commercially approved for cultivation in India (2002). Currently regulated under the Environment Protection Act, 1986.",
        "approval_year": "2002",
        "developer": "Monsanto / Mahyco (Maharashtra Hybrid Seeds Company)"
    },
    {
        "id": "gm2",
        "name": "GM Maize / Bt Corn (ಜಿಎಂ ಮಕ್ಕೆಜೋಳ / जीएम मक्का)",
        "common_name": "GM Maize",
        "icon": "fa-seedling",
        "tag_color": "yellow",
        "status_badge": "Import Approved (Pending Cultivation Approval)",
        "what_is_gm": "Genetically Modified Maize varieties have been engineered to express insect resistance (Bt) or herbicide tolerance (HT) traits. Some stacked varieties carry both traits simultaneously for broader protection.",
        "genetic_modification": "Multiple transformation events exist. MON810 event introduces cry1Ab gene (Bt toxin for stem borer control). NK603 event introduces EPSPS gene from Agrobacterium sp. strain CP4 conferring Roundup Ready herbicide tolerance. Stacked varieties like MON89034 x NK603 combine both traits using traditional breeding after separate independent transformation.",
        "modification_method": "Particle gun (biolistic) bombardment & Agrobacterium-mediated transformation",
        "genes_inserted": "cry1Ab (Bt, MON810), EPSPS (herbicide tolerance, NK603), cry2Ab, cry1F",
        "traits_added": "Stem borer resistance, Herbicide tolerance (Glyphosate), improved drought tolerance",
        "growing_regions": "Globally: USA, Brazil, Argentina, South Africa, Philippines, Canada. India: Pending cultivation approval. Approved for import and processing in animal feed. Potential growing states pending approval: Karnataka, Andhra Pradesh, Maharashtra, Bihar, Telangana.",
        "climate": "Warm temperate to tropical, requires 500-800mm rainfall, 18-32°C optimal.",
        "soil": "Sandy loam to clay loam, deep fertile soils, pH 5.8-7.5, well-drained.",
        "benefits": [
            "Fall Armyworm and Stem Borer resistance prevents 30-40% yield losses.",
            "Herbicide tolerance reduces manual weeding labor cost significantly.",
            "Drought-tolerant varieties improve production in dry-land zones.",
            "Reduced aflatoxin contamination in storage due to less insect damage."
        ],
        "concerns": [
            "Cross-pollination risks with non-GM maize through open field cultivation.",
            "Development of glyphosate-resistant superweeds from HT maize.",
            "Socioeconomic impacts on small seed-saving farmers.",
            "Pending comprehensive long-term safety trials for cultivation approval in India."
        ],
        "regulatory_status": "GEAC approved GM Maize for import (food and feed uses) but commercial cultivation in India remains pending full regulatory clearance as of 2024. Currently 10+ events under ICAR field trials.",
        "approval_year": "Import: 2022 (pending cultivation approval)",
        "developer": "Bayer CropScience (MON810), Corteva Agriscience, ICAR-CIMMYT research programs"
    },
    {
        "id": "gm3",
        "name": "Golden Rice (ಗೋಲ್ಡನ್ ರೈಸ್ / गोल्डन राइस)",
        "common_name": "Golden Rice (GR2E)",
        "icon": "fa-wheat-awn",
        "tag_color": "orange",
        "status_badge": "Approved in Bangladesh - Under Review in India",
        "what_is_gm": "Golden Rice is a biofortified variety of rice genetically engineered to produce beta-carotene (provitamin A) in the edible grain endosperm. It addresses Vitamin A Deficiency (VAD), a severe public health crisis affecting 250+ million children globally who rely on rice as a primary staple.",
        "genetic_modification": "Scientists inserted two genes into the rice genome: phytoene synthase (psy) from daffodil (Narcissus pseudonarcissus) and carotene desaturase (crtI) from the bacterium Erwinia uredovora. These enzymes enable the rice endosperm to synthesize beta-carotene through the carotenoid biosynthesis pathway. The beta-carotene imparts the distinctive golden-yellow color.",
        "modification_method": "Agrobacterium tumefaciens-mediated transformation (GR2E event)",
        "genes_inserted": "psy1 (Zea mays phytoene synthase), CrtI (Pantoea ananatis carotene desaturase)",
        "traits_added": "Beta-carotene (provitamin A) biosynthesis in grain endosperm",
        "growing_regions": "Bangladesh (approved for cultivation since 2021, BRRI dhan100 variety). Philippines (food safety approval 2021). Potential future Indian states: West Bengal, Odisha, Bihar, Uttar Pradesh, Andhra Pradesh and Telangana where VAD is most prevalent.",
        "climate": "Tropical and subtropical rice growing regions, humid, 25-35°C, 1000-1500mm rainfall.",
        "soil": "Alluvial silty-clay loam or clay with high water-retention, pH 5.5-7.0.",
        "benefits": [
            "Could prevent 1.15 million deaths annually from Vitamin A deficiency globally.",
            "A single serving of 200g cooked Golden Rice provides 50-60% of a child's daily beta-carotene needs.",
            "Same cultivation technique as conventional rice, no additional farmer training required.",
            "Developed as a humanitarian non-commercial product by IRRI & Syngenta Foundation."
        ],
        "concerns": [
            "Cross-pollination with conventional rice varieties in open field environments.",
            "Bioavailability of beta-carotene may vary based on fat intake in diet.",
            "Opposition from anti-GMO groups despite comprehensive safety studies.",
            "India's GEAC has not yet formally approved cultivation as of 2024."
        ],
        "regulatory_status": "Approved in Bangladesh (2021) as BRRI dhan100. Approved for food consumption in USA, Canada, Australia, New Zealand (2018-2019). Food Safety and Standards Authority of India (FSSAI) and GEAC are reviewing pending applications as of 2024.",
        "approval_year": "Bangladesh 2021; Philippines 2021; India: Under GEAC review",
        "developer": "International Rice Research Institute (IRRI), Syngenta Foundation, HarvestPlus CGIAR"
    },
    {
        "id": "gm4",
        "name": "GM Soybean - Roundup Ready (ಜಿಎಂ ಸೋಯಾಬೀನ / जीएम सोयाबीन)",
        "common_name": "Herbicide-Tolerant Soybean",
        "icon": "fa-circle-dot",
        "tag_color": "blue",
        "status_badge": "World's Most Cultivated GM Crop",
        "what_is_gm": "Roundup Ready Soybean (RRS) is herbicide-tolerant soybean engineered to withstand Glyphosate (Roundup) herbicide applications. It allows farmers to spray Glyphosate to kill weeds while leaving the soybean plants unharmed, dramatically reducing weed management labor.",
        "genetic_modification": "The EPSPS (5-enolpyruvylshikimate-3-phosphate synthase) gene from Agrobacterium tumefaciens strain CP4 was introduced into soybean. This CP4-EPSPS enzyme is not inhibited by glyphosate unlike the natural plant EPSPS, allowing the soybean's shikimate pathway to continue functioning normally even when glyphosate is applied to the field.",
        "modification_method": "Particle gun (biolistic) transformation at Monsanto's R&D facility",
        "genes_inserted": "CP4-EPSPS gene (from Agrobacterium tumefaciens CP4 strain)",
        "traits_added": "Glyphosate herbicide tolerance",
        "growing_regions": "USA accounts for 33% of global GM soy production. Brazil, Argentina, Bolivia, Paraguay, Uruguay, China, Canada. India: No commercial cultivation approved, but imported as crushed meal for animal feed. If approved in India, potential growing areas include Madhya Pradesh, Maharashtra, Rajasthan, Karnataka.",
        "climate": "Temperate to sub-tropical, 25-30°C, 500-700mm rainfall during growing season.",
        "soil": "Loamy, well-drained, fertile soils with organic matter, pH 6.0-7.5.",
        "benefits": [
            "Glyphosate herbicide is more environmentally favorable than older toxic herbicides it replaced.",
            "Reduces no-till farming labor and fuel costs by 30-40%.",
            "Enables early weed suppression without crop safety issues.",
            "Highest adoption rate of any GM crop globally (90%+ in USA, Brazil, Argentina)."
        ],
        "concerns": [
            "Over-reliance has led to 30+ glyphosate-resistant weed species globally.",
            "IARC (WHO) classified glyphosate as 'Probably Carcinogenic to Humans' (Group 2A) — disputed by EPA.",
            "Monopolization of seed industry by biotech corporations.",
            "Not approved for Indian cultivation due to regulatory restrictions on HT crops in legumes."
        ],
        "regulatory_status": "Commercially approved in USA (1994 — world's first commercial GM crop), Brazil, Argentina and 95+ countries. Imported for processing in India. GEAC has not approved domestic cultivation. Reviewed under the Seeds Act 1966 and Environment Protection Act 1986 in India.",
        "approval_year": "USA: 1994 (first commercialized GM crop). India: Import only, cultivation pending.",
        "developer": "Monsanto (now Bayer CropScience)"
    },
    {
        "id": "gm5",
        "name": "Bt Brinjal (ಬಿಟಿ ಬದನೆ / बीटी बैंगन)",
        "common_name": "Bt Eggplant / Bt Brinjal",
        "icon": "fa-pepper-hot",
        "tag_color": "purple",
        "status_badge": "Approved Bangladesh | Moratorium India",
        "what_is_gm": "Bt Brinjal (Eggplant) was engineered to resist the Fruit and Shoot Borer (Leucinodes orbonalis), the most destructive pest of brinjal globally, causing up to 80% pre-harvest losses. It was genetically modified by introducing the Bt protein gene cry1Ac into the brinjal genome.",
        "genetic_modification": "The cry1Ac gene from Bacillus thuringiensis serovar kurstaki was transferred into brinjal using Agrobacterium tumefaciens LBA4404 strain. The protein produced by cry1Ac binds to specific receptor sites in the midgut cells of the Fruit and Shoot Borer larvae (Lepidoptera), causing membrane disruption and larval death within 24-48 hours of plant feeding.",
        "modification_method": "Agrobacterium tumefaciens LBA4404-mediated plant transformation",
        "genes_inserted": "cry1Ac (from Bacillus thuringiensis var. kurstaki HD73)",
        "traits_added": "Resistance to Leucinodes orbonalis (Fruit and Shoot Borer)",
        "growing_regions": "Bangladesh: 5 approved varieties (BARI Bt Begun 1-5) grown commercially in Jamalpur, Gazipur, Pabna, Rangpur districts since 2012. India: GEAC approved in 2009 but India's Environment Minister imposed a moratorium — NOT currently grown commercially in India. Potential Indian growing areas: West Bengal, Karnataka, Andhra Pradesh, Odisha, Uttar Pradesh.",
        "climate": "Tropical & sub-tropical, 25-35°C optimal, 600-900mm rainfall, sensitive to frost.",
        "soil": "Sandy loam to loamy soils with good drainage, pH 5.5-7.0, rich in organic matter.",
        "benefits": [
            "Reduces pesticide use by 70-80% — farmers spray 77 fewer times per season in Bangladesh studies.",
            "Significant reduction in farmer pesticide exposure and occupational poisoning cases.",
            "Yield increase of 20-30% due to reduced pest-related fruit losses.",
            "Reduces production cost by ₹12,000-16,000/ha saved on pesticides."
        ],
        "concerns": [
            "India's moratorium was driven by lack of independent safety data — GEAC study criticized for conflicts of interest.",
            "Potential for cross-pollination with wild relative Solanum species (biodiversity concern).",
            "Corporate (Monsanto/Mahyco) control over staple vegetable seed supply.",
            "Bangladesh adoption has shown strong economic and safety benefits but monitoring gap exists."
        ],
        "regulatory_status": "India: GEAC approved in 2009 but moratorium imposed by Environment Minister Jairam Ramesh in February 2010 — remains under moratorium. Bangladesh: Variety BARI Bt Begun-1 approved in 2013 by Bangladesh Agricultural Research Institute (BARI). 5 varieties now commercially released.",
        "approval_year": "India: GEAC approved 2009 but moratorium since 2010. Bangladesh: Cultivated since 2014.",
        "developer": "Mahyco (collaborated with Monsanto) in India; BARI developed local Bangladeshi lines."
    },
    {
        "id": "gm6",
        "name": "Flavr Savr GM Tomato (ಫ್ಲೇವರ್ ಸೇವರ್ ಟೊಮೆಟೊ)",
        "common_name": "Flavr Savr Tomato",
        "icon": "fa-apple-whole",
        "tag_color": "red",
        "status_badge": "World's First GM Food — Discontinued",
        "what_is_gm": "The Flavr Savr tomato was the world's first commercially grown genetically modified food crop approved for human consumption. It was engineered to slow ripening and softening after harvest, extending shelf life for long-distance shipping — a major challenge for the fresh tomato market.",
        "genetic_modification": "Tomato ripening is controlled by cell wall-degrading enzyme polygalacturonase (PG). Scientists introduced an antisense PG gene — a reversed/mirror copy of the natural PG gene. When expressed, this antisense RNA binds to the plant's own PG messenger RNA and blocks its translation, dramatically reducing PG enzyme production. The result is slower cell wall breakdown and delayed softening.",
        "modification_method": "Antisense gene technology — introducing inverted copy of the PG gene via Agrobacterium transformation",
        "genes_inserted": "Antisense polygalacturonase (anti-PG) gene (reverse complement of native PG gene)",
        "traits_added": "Delayed fruit softening / Extended shelf life / Improved firmness during transport",
        "growing_regions": "Originally cultivated in California, USA under Calgene Inc. (1994-1997). No longer commercially grown anywhere. Modern shelf-life tomato improvements now use conventional breeding techniques based on similar ripening gene discoveries. Lessons from Flavr Savr inform present GM tomato research in India, China, and Netherlands.",
        "climate": "Mediterranean to subtropical, 18-29°C optimal, 600-900mm rainfall or supplemental irrigation.",
        "soil": "Sandy loam to clay loam, rich in organic matter, well-aerated, pH 6.0-7.0.",
        "benefits": [
            "Extended shelf life from 7 to 21+ days post-harvest reduces supply chain waste.",
            "Allowed vine-ripe flavor instead of harvesting green for chemical ripening.",
            "Proved that genetically modified foods can be approved and safely consumed.",
            "Pioneered regulatory framework for GM food labeling that all subsequent crops follow."
        ],
        "concerns": [
            "Poor commercial viability — production costs exceeded shelf-life benefits.",
            "Public fear and negative media coverage drove consumer rejection in early 1990s.",
            "Calgene's patents and weak market led to withdrawal from market by 1997.",
            "The pioneer status made it a lightning rod for all subsequent GM food controversies."
        ],
        "regulatory_status": "First GM food approved for sale by US FDA in May 1994. Sold in USA from 1994-1997. Now discontinued — no longer grown or sold commercially. Used primarily as a scientific reference and case study in biotechnology, regulatory science, and agricultural economics curricula worldwide.",
        "approval_year": "USA 1994 (world's first). Commercialized 1994-1997. Withdrawn from market 1997.",
        "developer": "Calgene Inc., Davis, California (later acquired by Monsanto)"
    },
    {
        "id": "gm7",
        "name": "Rainbow Papaya - Disease Resistant (ರೇನ್ಬೋ ಪಪ್ಪಾಯಿ / रेनबो पपीता)",
        "common_name": "Rainbow & SunUp GM Papaya",
        "icon": "fa-lemon",
        "tag_color": "orange",
        "status_badge": "Commercially Grown in Hawaii & Asia",
        "what_is_gm": "Rainbow Papaya was genetically engineered to resist Papaya Ringspot Virus (PRSV), a devastating disease that nearly wiped out Hawaii's entire papaya industry in the 1990s. This is a classic example of GM crop saving an agricultural industry from complete collapse.",
        "genetic_modification": "Scientists from Cornell University inserted the coat protein (CP) gene from PRSV itself into the papaya genome. This technique — called pathogen-derived resistance or coat protein-mediated resistance (CPMR) — causes the plant to produce a small amount of the viral coat protein. This 'immunizes' the papaya via RNA-silencing mechanism (post-transcriptional gene silencing / PTGS), where siRNA derived from the viral transgene suppresses replication of the actual virus when the plant is infected.",
        "modification_method": "Particle gun biolistic bombardment (Cornell University / USDA)",
        "genes_inserted": "PRSV coat protein (CP) gene",
        "traits_added": "Resistance to Papaya Ringspot Virus (PRSV Type W and P strains)",
        "growing_regions": "Hawaii, USA: Puna district on Big Island accounts for 95% of USA papaya. China: PRSV-resistant GM papaya approved for commercial cultivation in Guangdong and Guangxi provinces. Canada approved import. India: Not commercially grown. Research ongoing at IARI, New Delhi. Potential states: Kerala, Karnataka, Andhra Pradesh, Maharashtra, West Bengal.",
        "climate": "Tropical, 22-35°C, high humidity, 1500-2000mm rainfall or heavy irrigation.",
        "soil": "Well-drained loamy or sandy loam soils, pH 6.0-6.5, organic matter rich.",
        "benefits": [
            "Saved Hawaii's papaya industry from near-total collapse from PRSV in the 1990s.",
            "Provides virtually complete virus resistance — 95-100% protection in field conditions.",
            "Hawaii's GM papaya acreage went from nearly zero to 80% of total papaya area within 5 years.",
            "No significant pesticide increase needed — purely disease resistance mechanism."
        ],
        "concerns": [
            "Cross-contamination risk for organic papaya farmers in neighboring fields.",
            "PRSV evolving new strains that may overcome established transgenic resistance.",
            "Japan imports US papaya but initially disputed accepting GM papaya — resolved through testing protocols.",
            "India's research programs progressing but commercial approval timeline remains unclear."
        ],
        "regulatory_status": "USA: FDA/EPA/USDA jointly approved Rainbow Papaya in 1998. Hawaii has 80% GM papaya cultivation. China approved GM papaya national commercial cultivation in 2006. Japan approved Rainbow papaya import. Canada approved import. India: ICAR research ongoing — no GEAC commercial approval granted yet.",
        "approval_year": "USA 1998. China 2006. India: Research phase, no commercial approval.",
        "developer": "Cornell University (Dr. Dennis Gonsalves) in collaboration with USDA and University of Hawaii"
    },
    {
        "id": "gm8",
        "name": "GM Mustard (DMH-11) (ಜಿಎಂ ಸಾಸಿವೆ / जीएम सरसों)",
        "common_name": "Dhara Mustard Hybrid-11 (DMH-11)",
        "icon": "fa-circle",
        "tag_color": "yellow",
        "status_badge": "India GEAC Approved 2022 — Under Environment Ministry Review",
        "what_is_gm": "Dhara Mustard Hybrid-11 (DMH-11) is India's first domestically developed GM food crop to seek commercial approval. It uses a barnase-barstar two-component hybrid seed production system to create high-yielding mustard hybrids, potentially increasing oil yields by 25-30% and potentially addressing India's heavy dependence on edible oil imports.",
        "genetic_modification": "Three genes were introduced into mustard variety Varuna: barnase (encodes a ribonuclease that induces male sterility when expressed in tapetum cells of anthers — preventing self-pollination), barstar (encodes a ribonuclease inhibitor introduced in restorer lines — neutralizes barnase to restore pollen fertility in hybrid seeds), and bar (conferring phosphinothricin herbicide tolerance as a selectable genetic marker). The barnase-barstar system enables commercial hybrid seed production in mustard — previously extremely difficult due to the crop's self-pollinating nature.",
        "modification_method": "Agrobacterium tumefaciens-mediated transformation at Delhi University's Centre for Genetic Manipulation of Crop Plants (CGMCP)",
        "genes_inserted": "barnase (Bacillus amyloliquefaciens), barstar (Bacillus amyloliquefaciens), bar (Streptomyces hygroscopicus)",
        "traits_added": "Hybrid vigor enablement (barnase-barstar system), herbicide tolerance (bar gene marker)",
        "growing_regions": "Proposed growing areas in India's 'Mustard Belt': Rajasthan (largest mustard state, 45% of India's area), Haryana, Madhya Pradesh, Uttar Pradesh, West Bengal, Gujarat, Assam, Punjab. If approved, commercial rollout targeted for 2024-25 mustard season.",
        "climate": "Cool winter (Rabi) crop, 10-25°C during growing, tolerates mild frost, requires 25-40cm rainfall.",
        "soil": "Well-drained alluvial to sandy loam soils, pH 6.0-7.5, low to moderate organic matter tolerance.",
        "benefits": [
            "25-30% higher oil yield vs. best conventional varieties in ICAR multi-location trials.",
            "Could reduce India's edible oil import bill of ₹1.5 lakh crore annually.",
            "Enables commercial hybrid mustard production for the first time in India at scale.",
            "Developed entirely in India by Indian public institution scientists — no foreign IP royalty concerns."
        ],
        "concerns": [
            "Bar gene confers herbicide tolerance — concerns about 'herbicide-ready' crops enabling chemical-intensive farming.",
            "Bee pollination concerns: mustard is a major honeybee forage crop; barnase expression in pollen raises apicultural concerns.",
            "Opposition from Swadeshi/organic farming groups citing 'Monsanto-style' corporate domination risk.",
            "Environment Ministry review still ongoing despite GEAC recommendation — regulatory bottleneck."
        ],
        "regulatory_status": "Developed by Centre for Genetic Manipulation of Crop Plants (CGMCP), Delhi University under Prof. Deepak Pental. GEAC (Genetic Engineering Appraisal Committee) recommended environmental release in October 2022. India's Supreme Court and Environment Ministry are reviewing public interest petitions. Final commercial cultivation approval is pending as of 2024.",
        "approval_year": "GEAC recommendation: 2022. Final government approval: Pending (2024).",
        "developer": "Centre for Genetic Manipulation of Crop Plants (CGMCP), University of Delhi (Prof. Deepak Pental) — funded by Government of India's National Dairy Development Board (NDDB)"
    }
]
