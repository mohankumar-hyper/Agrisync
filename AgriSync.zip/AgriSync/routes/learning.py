from flask import Blueprint, request, jsonify, session
from database import get_db
from config import Config
from routes.learning_data import get_crop_agronomy, CROP_AGRONOMY_TEMPLATES, VIDEOS, GUIDES, QUIZZES, IMAGES, DOWNLOADS, GM_PLANTS
import google.generativeai as genai
import datetime
import random
import requests

learning_bp = Blueprint('learning', __name__)

# Configure Gemini key if provided and not a Groq key
gemini_configured = False
if Config.GEMINI_API_KEY and not Config.GEMINI_API_KEY.startswith('gsk_'):
    try:
        genai.configure(api_key=Config.GEMINI_API_KEY)
        gemini_configured = True
    except Exception as e:
        print(f"Error configuring Gemini client in learning assistant: {e}")


# ── 1. LEARNING DASHBOARD & RECOMMENDATIONS ─────────────────────────────────
@learning_bp.route('/dashboard', methods=['GET'])
def get_dashboard_summary():
    db = get_db()
    user_id = session.get('user_id', 'anonymous')
    
    # 1. Fetch user's registered farming properties for personalization
    farm_info = None
    recent_crop_rec = None
    if db is not None:
        try:
            farm_info = db.farms.find_one({"user_id": user_id})
            recent_crop_rec = db.crops.find_one({"user_id": user_id}, sort=[("created_at", -1)])
        except Exception:
            pass

    # Determine personalized crop of focus
    crop_focus = "Rice"
    if recent_crop_rec:
        crop_focus = recent_crop_rec.get("recommended_crop", "Rice")
    
    # Simple seasonal advice based on current month
    month = datetime.datetime.now().month
    season = "Rabi" if month in [10, 11, 12, 1, 2] else "Kharif"
    
    # dynamic weather forecast hint
    weather_alert = "Check for clear sunny intervals before spraying pest deterrents."
    if month in [6, 7, 8, 9]:
        weather_alert = "Monsoon active. Ensure efficient field drainage channels to prevent waterlogging."
    
    # 2. Recommendations matching target parameters
    recommended_videos = []
    for v in VIDEOS:
        if v["category"].lower() in [crop_focus.lower(), "organic farming", "drip irrigation"]:
            recommended_videos.append(v)
    if not recommended_videos:
        recommended_videos = VIDEOS[:3]  # fallback
        
    # User's recently earned badges
    badges = []
    if db is not None:
        try:
            stats = db.learning_stats.find_one({"user_id": user_id})
            if stats:
                badges = stats.get("badges", [])
        except Exception:
            pass

    # Recommended for you
    return jsonify({
        "success": True,
        "crop_focus": crop_focus,
        "current_season": season,
        "weather_tip": weather_alert,
        "stats": {
            "completed_lessons": len(badges) * 2,
            "badges_count": len(badges)
        },
        "continue_learning": {
            "title": f"Farming Guide for {crop_focus}",
            "progress_percent": 65,
            "next_lesson": "Fertilizer Schedule and Micro-NPK Dosing"
        },
        "recommended_videos": recommended_videos,
        "badges": badges
    })


# ── 2. CROP LEARNING LIBRARY ───────────────────────────────────────────────
@learning_bp.route('/crops', methods=['GET'])
def get_crops_list():
    # If crop name is passed as query parameters, return detailed info
    crop_name = request.args.get('crop', '').strip()
    if crop_name:
        agronomy = get_crop_agronomy(crop_name)
        return jsonify({"success": True, "crop": crop_name, "agronomy": agronomy})
        
    # Return available crop keys
    crops_supported = [
        "Rice", "Wheat", "Maize", "Cotton", "Sugarcane", 
        "Tomato", "Onion", "Potato", "Chilli", "Groundnut", 
        "Millets", "Banana", "Mango", "Mustard", "Chickpea", "Turmeric",
        "Paddy", "Sugar Cane"
    ]
    return jsonify({"success": True, "crops": crops_supported})


# ── 2a. GENETICALLY MODIFIED (GM) PLANTS ─────────────────────────────────────
@learning_bp.route('/gm', methods=['GET'])
def get_gm_plants():
    plant_id = request.args.get('plant', '').strip()
    if plant_id:
        for p in GM_PLANTS:
            if p["id"].lower() == plant_id.lower() or p["common_name"].lower() == plant_id.lower():
                return jsonify({"success": True, "plant": p})
        return jsonify({"success": False, "message": "GM Plant not found"}), 404
        
    return jsonify({"success": True, "plants": GM_PLANTS})


# ── 3. VIDEO LIBRARY & SEARCH / FILTERS ────────────────────────────────────
@learning_bp.route('/videos', methods=['GET'])
def get_videos():
    search = request.args.get('search', '').lower().strip()
    category = request.args.get('category', '').lower().strip()
    language = request.args.get('language', '').lower().strip()
    
    filtered = VIDEOS
    
    # Apply filters
    if search:
        filtered = [v for v in filtered if search in v['title'].lower() or search in v['category'].lower()]
    if category:
        filtered = [v for v in filtered if v['category'].lower() == category]
    if language:
        filtered = [v for v in filtered if v['language'].lower() == language]
        
    return jsonify({"success": True, "videos": filtered})


# ── 4. STEP-BY-STEP GUIDES ─────────────────────────────────────────────────
@learning_bp.route('/guides', methods=['GET'])
def get_guides():
    return jsonify({"success": True, "guides": GUIDES})


# ── 5. INTERACTIVE LESSON QUIZZES ──────────────────────────────────────────
@learning_bp.route('/quiz', methods=['GET'])
def get_quiz():
    category = request.args.get('category', 'organic').lower()
    quiz_list = QUIZZES.get(category, QUIZZES["organic"])
    
    # Strip correct answers before sending to client for security
    clean_questions = []
    for q in quiz_list:
        clean_questions.append({
            "id": q["id"],
            "q": q["q"],
            "opt": q["opt"]
        })
        
    return jsonify({"success": True, "category": category, "questions": clean_questions})


@learning_bp.route('/quiz/submit', methods=['POST'])
def submit_quiz():
    data = request.get_json() or {}
    category = data.get('category', 'organic').lower()
    answers = data.get('answers', {})  # Dict of { question_id: option_index }
    
    quiz_list = QUIZZES.get(category, QUIZZES["organic"])
    correct_count = 0
    total = len(quiz_list)
    results = []
    
    for q in quiz_list:
        q_id_str = str(q["id"])
        user_choice = answers.get(q_id_str)
        is_correct = (user_choice == q["ans"])
        if is_correct:
            correct_count += 1
            
        results.append({
            "id": q["id"],
            "question": q["q"],
            "user_answer": q["opt"][user_choice] if user_choice is not None else None,
            "correct_answer": q["opt"][q["ans"]],
            "correct": is_correct,
            "explanation": q["exp"]
        })
        
    percentage = round((correct_count / total) * 100) if total > 0 else 0
    passed = (percentage >= 70)
    
    badge_awarded = None
    user_id = session.get('user_id', 'anonymous')
    
    # Log badge award if passed
    if passed and user_id != 'anonymous':
        db = get_db()
        if db is not None:
            badges_map = {
                "organic": {"name": "Organic Master", "icon": "fa-seedling"},
                "irrigation": {"name": "Water Expert", "icon": "fa-droplet"}
            }
            badge_info = badges_map.get(category, {"name": "Farming Scholar", "icon": "fa-graduation-cap"})
            badge_doc = {
                "category": category,
                "name": badge_info["name"],
                "icon": badge_info["icon"],
                "date": datetime.datetime.now().strftime("%Y-%m-%d")
            }
            
            try:
                # Add badge to user's badges (unique categories)
                db.learning_stats.update_one(
                    {"user_id": user_id},
                    {"$addToSet": {"badges": badge_doc}},
                    upsert=True
                )
                badge_awarded = badge_info["name"]
            except Exception as e:
                print(f"Error awarding badge: {e}")
                
    return jsonify({
        "success": True,
        "score": correct_count,
        "total": total,
        "percentage": percentage,
        "passed": passed,
        "results": results,
        "badge_awarded": badge_awarded
    })


# ── 6. IMAGE-BASED PATHOLOGY & DEFICIENCY LIBRARY ──────────────────────────
@learning_bp.route('/images', methods=['GET'])
def get_images():
    return jsonify({"success": True, "images": IMAGES})


# ── 7. DOWNLOAD CENTRE DOCUMENT REPOSITORIES ───────────────────────────────
@learning_bp.route('/downloads', methods=['GET'])
def get_downloads():
    return jsonify({"success": True, "downloads": DOWNLOADS})


# ── 7a. SERVE DOWNLOADABLE FILES ────────────────────────────────────────────
@learning_bp.route('/download/<filename>', methods=['GET'])
def serve_download(filename):
    """Serve learning centre PDF documents. Falls back to a generated placeholder."""
    import os
    from flask import send_file, Response
    
    # Security: Only allow safe filenames (no path traversal)
    safe_name = os.path.basename(filename)
    if not safe_name.endswith('.pdf'):
        return jsonify({"success": False, "message": "Only PDF downloads are supported"}), 400
    
    # Try to serve from uploads folder first
    upload_path = os.path.join(Config.UPLOAD_FOLDER, safe_name)
    if os.path.exists(upload_path):
        return send_file(upload_path, as_attachment=True, download_name=safe_name)
    
    # Serve from a static docs folder if it exists
    docs_path = os.path.join('static', 'docs', safe_name)
    if os.path.exists(docs_path):
        return send_file(docs_path, as_attachment=True, download_name=safe_name)
    
    # Generate a minimal but valid PDF placeholder in memory
    # Maps filename to readable title
    title_map = {
        'pesticide-guide.pdf': 'Integrated Organic Pest Management Manual',
        'planting-calendar.pdf': 'Kharif Soil Enrichment Calendar 2026',
        'solar-subsidies.pdf': 'Government Subsidies and Solar Schemes India',
    }
    doc_title = title_map.get(safe_name, safe_name.replace('-', ' ').replace('.pdf', '').title())
    
    # Build minimal valid PDF bytes (plain-text PDF 1.4 format)
    pdf_content = f"""%PDF-1.4
1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj
2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj
3 0 obj<</Type/Page/MediaBox[0 0 595 842]/Parent 2 0 R/Resources<</Font<</F1<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>>>>>/Contents 4 0 R>>endobj
4 0 obj<</Length 200>>
stream
BT
/F1 20 Tf
50 780 Td
({doc_title}) Tj
/F1 12 Tf
0 -40 Td
(AgriSync Agriculture Learning Centre) Tj
0 -20 Td
(This document is available offline. Visit the AgriSync app for full content.) Tj
0 -20 Td
(Generated: {datetime.datetime.now().strftime('%Y-%m-%d')}) Tj
ET
endstream
endobj
xref
0 5
0000000000 65535 f
0000000009 00000 n
0000000058 00000 n
0000000115 00000 n
0000000266 00000 n
trailer<</Size 5/Root 1 0 R>>
startxref
518
%%EOF"""
    
    pdf_bytes = pdf_content.encode('latin-1', errors='replace')
    return Response(
        pdf_bytes,
        mimetype='application/pdf',
        headers={
            'Content-Disposition': f'attachment; filename="{safe_name}"',
            'Content-Length': str(len(pdf_bytes))
        }
    )


# ── 8. AI LEARNING ASSISTANT (CHAT) ────────────────────────────────────────
@learning_bp.route('/chat', methods=['POST'])
def chat():
    data = request.get_json() or {}
    message = data.get('query', '').strip()
    lang = data.get('lang', 'en')
    
    if not message:
        return jsonify({"success": False, "message": "Query cannot be empty"}), 400
        
    # Detect if query specifies a crop grown in India
    query_lower = message.lower()
    target_crop = None
    for crop_key in CROP_AGRONOMY_TEMPLATES.keys():
        if crop_key in query_lower:
            target_crop = crop_key
            break

    # Synonyms / multilingual checks for crops grown in India
    if not target_crop:
        if any(w in query_lower for w in ["paddy", "bhath", "ಬೆಳೆ", "ಭತ್ತ", "धान"]):
            target_crop = "rice"
        elif any(w in query_lower for w in ["wheat", "ಗೋಧಿ", "ಗೆहूं", "गेहूं"]):
            target_crop = "wheat"
        elif any(w in query_lower for w in ["maize", "corn", "ಮಕ್ಕೆಜೋಳ", "मक्का"]):
            target_crop = "maize"
        elif any(w in query_lower for w in ["cotton", "ಹತ್ತಿ", "ಕಪಾಸ್", "ಕಪಾಸು"]):
            target_crop = "cotton"
        elif any(w in query_lower for w in ["sugarcane", "ಕಬ್ಬು", "ಗನ್ನಾ", "गन्ना"]):
            target_crop = "sugarcane"
        elif any(w in query_lower for w in ["tomato", "ಟೊಮೆಟೊ", "ಟಮಾಟರ್", "टमाटर"]):
            target_crop = "tomato"
        elif any(w in query_lower for w in ["onion", "ಈರುಳ್ಳಿ", "ಪ್ಯಾಜ್", "प्याज"]):
            target_crop = "onion"
        elif any(w in query_lower for w in ["potato", "ಆಲೂಗಡ್ಡೆ", "ಆಲೂ", "आलू"]):
            target_crop = "potato"
        elif any(w in query_lower for w in ["chilli", "ಚಿಲ್ಲಿ", "ಮೆಣಸಿನಕಾಯಿ", "ಮಿರ್ಚಿ", "मिर्च"]):
            target_crop = "chilli"
        elif any(w in query_lower for w in ["groundnut", "ಶೇಂಗಾ", "ನೆಲಗಡಲೆ", "मूंगफلی"]):
            target_crop = "groundnut"
        elif any(w in query_lower for w in ["millet", "ragi", "bajra", "ರಾಗಿ", "ಸಜ್ಜೆ", "बाजरा", "रागी"]):
            target_crop = "millets"
        elif any(w in query_lower for w in ["banana", "ಬಾಳೆಹಣ್ಣು", "ಕೇಲಾ", "केला"]):
            target_crop = "banana"
        elif any(w in query_lower for w in ["mango", "ಮಾವು", "ಆಮ್", "आम"]):
            target_crop = "mango"
        elif any(w in query_lower for w in ["mustard", "ಸಾಸಿವೆ", "ಸಾಸಿವಿ", "सरसों", "सरसो"]):
            target_crop = "mustard"
        elif any(w in query_lower for w in ["chickpea", "gram", "ಕಡಲೆ", "ಚನಾ", "चना"]):
            target_crop = "chickpea"
        elif any(w in query_lower for w in ["turmeric", "ಹಳದಿ", "ಅರಿಶಿನ", "ಹಲ್ದಿ", "हल्दी", "हलदी"]):
            target_crop = "turmeric"

    prompt_context = (
        "You are the AgriSync Farm Learning Assistant. The user is a farmer looking to learn modern, sustainable agrarian practices. "
        "Provide scientific, structured advice in language matching the queries in English, Kannada, and Hindi. "
        "Topics covered: crop selection, fertilizing, yield improvement, weather indicators, agricultural machinery, and local subsidies."
    )
    if target_crop:
        crop_data = CROP_AGRONOMY_TEMPLATES[target_crop]
        prompt_context += (
            f"\nThe user is asking about the crop '{crop_data['name']}' grown in India. "
            f"Here is the local agronomic package of practices / dataset for '{crop_data['name']}':\n{str(crop_data)}\n"
            f"Make sure to reference this localized information in your reply."
        )
    
    groq_key = getattr(Config, 'GROQ_API_KEY', '') or ''
    if not groq_key and Config.GEMINI_API_KEY and Config.GEMINI_API_KEY.startswith('gsk_'):
        groq_key = Config.GEMINI_API_KEY

    # Check for Groq API integration
    if groq_key:
        try:
            url = "https://api.groq.com/openai/v1/chat/completions"
            headers = {
                "Authorization": f"Bearer {groq_key}",
                "Content-Type": "application/json"
            }
            payload = {
                "model": "llama3-8b-8192",
                "messages": [
                    {"role": "system", "content": prompt_context},
                    {"role": "user", "content": message}
                ],
                "temperature": 0.7
            }
            response = requests.post(url, json=payload, headers=headers, timeout=10)
            if response.status_code == 200:
                res_data = response.json()
                reply = res_data['choices'][0]['message']['content']
                return jsonify({
                    "success": True,
                    "response": reply,
                    "source": "AI Learning Engine (Groq)"
                })
            else:
                print(f"Learning chatbot Groq API error status {response.status_code}: {response.text}")
        except Exception as e:
            print(f"Learning chatbot Groq target failed: {e}")

    elif gemini_configured:
        try:
            model = genai.GenerativeModel('gemini-pro')
            response = model.generate_content(f"{prompt_context}\n\nUser Question: {message}")
            return jsonify({
                "success": True,
                "response": response.text,
                "source": "AI Learning Engine (Gemini)"
            })
        except Exception as e:
            print(f"Learning chatbot Gemini failure: {e}")
            
    # Fallback Response Engine supporting Multilingual replies!
    query_lower = message.lower()
    
    reply_prefix = ""
    if target_crop:
        crop_data = CROP_AGRONOMY_TEMPLATES[target_crop]
        reply_prefix = (
            f"🌱 **AgriSync India Crop Database — {crop_data['name']}:**\n"
            f"• **Overview:** {crop_data['overview']}\n"
            f"• **Season:** {crop_data['season']}\n"
            f"• **Fertilizer:** {crop_data['fertilizer']}\n"
            f"• **Harvest & Yield:** {crop_data['harvest']} (Expected Yield: {crop_data['yield']})\n\n"
        )

    # ── ENGLISH FALLBACKS ──
    if lang == 'en':
        reply = reply_prefix + (
            "🌾 **AgriSync Learning Advisor:**\n\n"
            "To successfully learn, you can explore the tabs:\n"
            "1. **Crop Agronomy:** Click on any crop (e.g., Rice, Potato, Millets) to read detailed sowing and fertilizing schedules.\n"
            "2. **Interactive Quiz:** Test your skills in Drip Irrigation or Organic Farming to earn certified badges.\n"
            "3. **Educational Videos:** Stream embedded video instructions directly.\n\n"
            "Common Question Answer: **How to improve Soil Health?** \n"
            "- Incorporate leguminous rotation crops (pulses) to biologically fix nitrogen.\n"
            "- Add vermicompost and reduce chemical urea dependency to nurture beneficial soil microbiomes."
        )
    # ── KANNADA FALLBACKS ──
    elif lang == 'kn' or any(k in query_lower for k in ['ಬೆಳೆ', 'ರೋಗ', 'ನೀರಾವರಿ', 'ಗೊಬ್ಬರ']):
        reply = reply_prefix + (
            "🌾 **ಕೃಷಿ ತರಬೇತಿ ಸಹಾಯಕ (AgriSync):**\n\n"
            "ಕೃಷಿ ಶಿಕ್ಷಣ ಮಂಡಳಿಯಲ್ಲಿ ನೀವು ಕಲಿಯಬಹುದಾದ ವಿಷಯಗಳು:\n"
            "1. **ಬೆಳೆ ಮಾಹಿತಿ:** ಭತ್ತ, ಆಲೂಗಡ್ಡೆ, ಶೇಂಗಾ ಬೆಳೆಗಳಿಗೆ ಗೊಬ್ಬರ ಮತ್ತು ಬಿತ್ತನೆ ವೇಳಾಪಟ್ಟಿಗಳನ್ನು ವೀಕ್ಷಿಸಿ.\n"
            "2. **ತರಬೇತಿ ರಸಪ್ರಶ್ನೆ:** ಸಾವಯವ ಕೃಷಿ ಅಥವಾ ನೀರಾವರಿ ಪಾಠಗಳನ್ನು ಓದಿ ಪ್ರಮಾಣಪತ್ರ ಪಡೆದುಕೊಳ್ಳಿ.\n"
            "3. **ವಿಡಿಯೋ ಲೈಬ್ರರಿ:** ಕೃಷಿ ಪದ್ಧತಿಗಳ ಕುರಿತು ಯೂಟ್ಯೂಬ್ ವಿಡಿಯೋಗಳನ್ನು ಉಚಿತವಾಗಿ ನೋಡಿ.\n\n"
            "ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ ಪ್ರಶ್ನೆಯನ್ನು ಕೇಳಿ!"
        )
    # ── HINDI FALLBACKS ──
    else:
        reply = reply_prefix + (
            "🌾 **कृषि शिक्षा सहायक (AgriSync):**\n\n"
            "यहां आप प्रगतिशील खेती के उन्नत तरीके सीख सकते हैं:\n"
            "1. **फसल मार्गदर्शिका:** बाजरा, धान, गन्ना, आलू और टमाटर के उपयुक्त मौसम, खाद और बुवाई की गहन जानकारी उपलब्ध है।\n"
            "2. **प्रश्नोत्तरी (Quiz):** जैविक खेती सीखें और परीक्षा देकर सम्मान पत्र (Badge) प्राप्त करें।\n"
            "3. **कृषि वीडियो:** ड्रिप सिंचाई, वर्मीकंपोस्ट और खाद बनाने के वीडियो यहां देखें।\n\n"
            "आप मौसम की सटीक तैयारी के लिए डैशबोर्ड का भी उपयोग कर सकते हैं।"
        )
        
    return jsonify({
        "success": True,
        "response": reply,
        "source": "AgriSync Local Training Module"
    })
