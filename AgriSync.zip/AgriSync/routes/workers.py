from flask import Blueprint, request, jsonify, session
from bson.objectid import ObjectId
from database import get_db
import datetime

workers_bp = Blueprint('workers', __name__)

@workers_bp.route('', methods=['GET'])
def get_workers():
    db = get_db()
    if db is None:
        return jsonify({"success": False, "message": "Database connection failed"}), 500
        
    try:
        workers = list(db.workers.find({}))
        for w in workers:
            w['_id'] = str(w['_id'])
        return jsonify({"success": True, "workers": workers})
    except Exception as e:
        return jsonify({"success": False, "message": f"Failed to retrieve workers: {str(e)}"}), 500

@workers_bp.route('/book', methods=['POST'])
def book_worker():
    db = get_db()
    if db is None:
        return jsonify({"success": False, "message": "Database connection failed"}), 500
        
    data = request.get_json() or {}
    worker_id = data.get('worker_id')
    booking_date = data.get('booking_date')
    num_days = data.get('num_days', 1)
    
    if not worker_id or not booking_date:
        return jsonify({"success": False, "message": "Worker ID and Date are required"}), 400
        
    user_id = session.get('user_id', 'anonymous')
    username = session.get('username', 'Farmer Vikas')
    
    try:
        # Check if worker exists and is available
        worker = db.workers.find_one({"_id": ObjectId(worker_id)})
        if not worker:
            return jsonify({"success": False, "message": "Worker not found"}), 404
            
        if worker.get('availability') == 'Busy':
            return jsonify({"success": False, "message": "Worker is currently busy or already booked on this date"}), 400
            
        # Calculate cost
        total_wages = worker.get('daily_wage', 450) * int(num_days)
        
        # Create booking log
        booking_doc = {
            "worker_id": worker_id,
            "worker_name": worker['name'],
            "user_id": user_id,
            "booking_date": booking_date,
            "num_days": int(num_days),
            "total_wages": total_wages,
            "status": "Confirmed",
            "created_at": datetime.datetime.utcnow().isoformat()
        }
        
        db.bookings.insert_one(booking_doc)
        
        # Set database worker availability to Busy
        db.workers.update_one(
            {"_id": ObjectId(worker_id)},
            {"$set": {"availability": "Busy"}}
        )
        
        # Insert smart notifications
        db.notifications.insert_one({
            "title": "Worker Booking Confirmed",
            "message": f"Successfully hired {worker['name']} for {num_days} days starting {booking_date}. Total Wage: ₹{total_wages}.",
            "category": "booking",
            "unread": True,
            "created_at": datetime.datetime.utcnow().isoformat()
        })
        
        return jsonify({
            "success": True,
            "message": "Worker booked successfully",
            "booking": {
                "worker_name": worker['name'],
                "booking_date": booking_date,
                "total_wages": total_wages,
                "days": num_days
            }
        })
        
    except Exception as e:
        return jsonify({"success": False, "message": f"Worker booking failed: {str(e)}"}), 500

@workers_bp.route('/bookings', methods=['GET'])
def get_user_bookings():
    db = get_db()
    if db is None:
        return jsonify({"success": False, "message": "Database connection failed"}), 500
        
    user_id = session.get('user_id', 'anonymous')
    
    try:
        bookings = list(db.bookings.find({"user_id": user_id}).sort("created_at", -1))
        for b in bookings:
            b['_id'] = str(b['_id'])
        return jsonify({"success": True, "bookings": bookings})
    except Exception as e:
        return jsonify({"success": False, "message": f"Failed to retrieve bookings: {str(e)}"}), 500
