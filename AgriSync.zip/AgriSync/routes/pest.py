from flask import Blueprint, request, jsonify
from models.ai_models import predict_pest
from database import get_db
import datetime

pest_bp = Blueprint('pest', __name__)

@pest_bp.route('/predict', methods=['POST'])
def predict_pest_risk():
    data = request.get_json() or {}
    
    crop_name = data.get('crop_name')
    
    try:
        temp = float(data.get('temperature'))
        hum = float(data.get('humidity'))
        rain = float(data.get('rainfall'))
    except (TypeError, ValueError):
        return jsonify({"success": False, "message": "Temperature, humidity, and rainfall must be valid numbers"}), 400
        
    if not crop_name:
        return jsonify({"success": False, "message": "Crop name is required"}), 400
        
    try:
        pest_analysis = predict_pest(temp, hum, rain, crop_name)
        
        # Log to db
        db = get_db()
        if db is not None:
            db.pests_logged.insert_one({
                "inputs": {
                    "temperature": temp,
                    "humidity": hum,
                    "rainfall": rain,
                    "crop_name": crop_name
                },
                "pest_name": pest_analysis["pest_name"],
                "risk_percentage": pest_analysis["risk_percentage"],
                "risk_level": pest_analysis["risk"],
                "created_at": datetime.datetime.utcnow().isoformat()
            })
            
            # If risk is High, trigger weather/crop-pest notification
            if pest_analysis["risk"] == "High":
                db.notifications.insert_one({
                    "title": f"High Pest Risk: {pest_analysis['pest_name']}",
                    "message": f"Climatic variables point to extreme risk ({pest_analysis['risk_percentage']}%) of {pest_analysis['pest_name']} in {crop_name}. Apply {pest_analysis['pesticide']}",
                    "category": "pest",
                    "unread": True,
                    "created_at": datetime.datetime.utcnow().isoformat()
                })
                
        return jsonify({
            "success": True,
            "data": pest_analysis
        })
    except Exception as e:
        return jsonify({"success": False, "message": f"Pest risk prediction failed: {str(e)}"}), 505
