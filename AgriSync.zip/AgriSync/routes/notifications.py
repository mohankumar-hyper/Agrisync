from flask import Blueprint, jsonify, request
from database import get_db
from bson.objectid import ObjectId

notifications_bp = Blueprint('notifications', __name__)

@notifications_bp.route('', methods=['GET'])
def get_notifications():
    db = get_db()
    if db is None:
        return jsonify({"success": False, "message": "Database connection failed"}), 500
        
    try:
        notifications = list(db.notifications.find({}).sort("created_at", -1).limit(10))
        for n in notifications:
            n['_id'] = str(n['_id'])
        return jsonify({"success": True, "notifications": notifications})
    except Exception as e:
        return jsonify({"success": False, "message": f"Failed to retrieve notifications: {str(e)}"}), 500

@notifications_bp.route('/read-all', methods=['POST'])
def mark_all_read():
    db = get_db()
    if db is None:
        return jsonify({"success": False, "message": "Database connection failed"}), 500
        
    try:
        db.notifications.update_many({"unread": True}, {"$set": {"unread": False}})
        return jsonify({"success": True, "message": "All notifications marked as read"})
    except Exception as e:
        return jsonify({"success": False, "message": f"Operation failed: {str(e)}"}), 500
