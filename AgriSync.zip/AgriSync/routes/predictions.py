from flask import Blueprint, request, jsonify, session
from models.ai_models import predict_yield_and_profit
from database import get_db
import datetime

predictions_bp = Blueprint('predictions', __name__)

@predictions_bp.route('/yield', methods=['POST'])
def predict_yield():
    data = request.get_json() or {}
    
    crop_name = data.get('crop_name')
    
    try:
        area = float(data.get('area'))
        temp = float(data.get('temperature'))
        rain = float(data.get('rainfall'))
        ph = float(data.get('ph'))
    except (TypeError, ValueError):
        return jsonify({"success": False, "message": "Land area, temperature, rainfall, and ph must be valid numbers"}), 400
        
    if not crop_name:
        return jsonify({"success": False, "message": "Crop name is required"}), 400
        
    try:
        results = predict_yield_and_profit(crop_name, area, temp, rain, ph)
        
        # Log to Database
        db = get_db()
        if db is not None:
            user_id = session.get('user_id', 'anonymous')
            db.yield_predictions.insert_one({
                "user_id": user_id,
                "inputs": {
                    "crop_name": crop_name,
                    "area_hectares": area,
                    "temperature": temp,
                    "rainfall": rain,
                    "ph": ph
                },
                "predicted_yield_tons": results["predicted_yield_tons"],
                "gross_revenue": results["gross_revenue"],
                "cost_of_cultivation": results["cost_of_cultivation"],
                "expected_profit": results["expected_profit"],
                "created_at": datetime.datetime.utcnow().isoformat()
            })
            
        return jsonify({
            "success": True,
            "data": results
        })
    except Exception as e:
        return jsonify({"success": False, "message": f"Yield prediction failed: {str(e)}"}), 500
