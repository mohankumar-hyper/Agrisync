from flask import Blueprint, request, jsonify, session
from werkzeug.utils import secure_filename
from config import Config
from database import get_db
import os
import uuid
import datetime

marketplace_bp = Blueprint('marketplace', __name__)

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'webp'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@marketplace_bp.route('', methods=['GET'])
def get_products():
    db = get_db()
    if db is None:
        return jsonify({"success": False, "message": "Database connection failed"}), 500
        
    try:
        products = list(db.marketplace.find({}).sort("created_at", -1))
        for p in products:
            p['_id'] = str(p['_id'])
        return jsonify({"success": True, "products": products})
    except Exception as e:
        return jsonify({"success": False, "message": f"Failed to retrieve products: {str(e)}"}), 500

@marketplace_bp.route('/upload', methods=['POST'])
def add_product():
    db = get_db()
    if db is None:
        return jsonify({"success": False, "message": "Database connection failed"}), 500
        
    product_name = request.form.get('product_name')
    category = request.form.get('category')
    
    try:
        price = float(request.form.get('price', 0))
        quantity = float(request.form.get('quantity', 0))
    except ValueError:
        return jsonify({"success": False, "message": "Price and Quantity must be numbers"}), 400
        
    unit = request.form.get('unit', 'kg')
    description = request.form.get('description', '')
    
    # Optional image upload
    image_url = None
    if 'image' in request.files:
        file = request.files['image']
        if file and file.filename != '' and allowed_file(file.filename):
            try:
                ext = file.filename.rsplit('.', 1)[1].lower()
                unique_name = f"market_{uuid.uuid4().hex}.{ext}"
                filepath = os.path.join(Config.UPLOAD_FOLDER, unique_name)
                # save filesystem
                file.save(filepath)
                image_url = f"/static/uploads/{unique_name}"
            except Exception as e:
                print(f"Market image save failed: {e}")
                image_url = None
                
    if not image_url:
        # Fallback default image relative to category
        cat_lower = (category or '').lower()
        if 'grain' in cat_lower or 'rice' in cat_lower or 'wheat' in cat_lower:
            image_url = "/static/uploads/seed_basmati.jpg"
        elif 'vegetable' in cat_lower or 'tomato' in cat_lower:
            image_url = "/static/uploads/seed_tomato.jpg"
        elif 'spice' in cat_lower or 'turmeric' in cat_lower:
            image_url = "/static/uploads/seed_turmeric.jpg"
        elif 'fruit' in cat_lower or 'honey' in cat_lower:
            image_url = "/static/uploads/seed_honey.jpg"
        else:
            image_url = "/static/uploads/seed_default.jpg"
        
    if not product_name or not category:
        return jsonify({"success": False, "message": "Product name and category are required"}), 400
        
    user_name = session.get('username', 'Farmer Vikas')
    user_email = session.get('email', '+91 99008 87766')
    
    product_doc = {
        "product_name": product_name,
        "category": category,
        "price": price,
        "quantity": quantity,
        "unit": unit,
        "farmer_name": user_name,
        "farmer_contact": user_email,
        "image_url": image_url,
        "description": description,
        "created_at": datetime.datetime.utcnow().isoformat()
    }
    
    try:
        db.marketplace.insert_one(product_doc)
        
        # Trigger notification
        db.notifications.insert_one({
            "title": "Marketplace Listing Active",
            "message": f"Your listing for '{product_name}' at ₹{price}/{unit} is now live in the local buyer exchange.",
            "category": "market",
            "unread": True,
            "created_at": datetime.datetime.utcnow().isoformat()
        })
        
        return jsonify({"success": True, "message": "Product added successfully!"})
    except Exception as e:
        return jsonify({"success": False, "message": f"Failed to upload product: {str(e)}"}), 500

@marketplace_bp.route('/contact', methods=['POST'])
def contact_farmer():
    db = get_db()
    if db is None:
        return jsonify({"success": False, "message": "Database connection failed"}), 500
        
    data = request.get_json() or {}
    product_name = data.get('product_name')
    farmer_name = data.get('farmer_name')
    buyer_name = data.get('buyer_name', 'Buyer')
    buyer_contact = data.get('buyer_contact') or session.get('email') or ''
    message = data.get('message', '')
    
    if not product_name or not buyer_contact:
        return jsonify({"success": False, "message": "Product name and buyer contact are required"}), 400
        
    inquiry_doc = {
        "product_name": product_name,
        "farmer_name": farmer_name,
        "buyer_name": buyer_name,
        "buyer_contact": buyer_contact,
        "message": message,
        "created_at": datetime.datetime.utcnow().isoformat()
    }
    
    try:
        db.inquiries.insert_one(inquiry_doc)
        
        # Push notification to the seller that a buyer is interested:
        db.notifications.insert_one({
            "title": f"New Inquiry: {product_name}",
            "message": f"Buyer {buyer_name} ({buyer_contact}) is interested in {product_name}. Msg: '{message}'",
            "category": "market",
            "unread": True,
            "created_at": datetime.datetime.utcnow().isoformat()
        })
        
        return jsonify({"success": True, "message": "Farmer notified successfully. They will contact you shortly."})
    except Exception as e:
        return jsonify({"success": False, "message": f"Inquiry failed: {str(e)}"}), 500
