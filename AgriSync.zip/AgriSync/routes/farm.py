from flask import Blueprint, request, jsonify, session
from database import get_db
import datetime

farm_bp = Blueprint('farm', __name__)

@farm_bp.route('', methods=['POST'])
def save_farm_location():
    db = get_db()
    if db is None:
        return jsonify({"success": False, "message": "Database connection failed"}), 500
        
    data = request.get_json() or {}
    lat = data.get('latitude')
    lon = data.get('longitude')
    farm_name = data.get('farm_name', 'AgriSense Farm')
    user_id = session.get('user_id', 'anonymous')
    
    if lat is None or lon is None:
        return jsonify({"success": False, "message": "Latitude and Longitude are required"}), 400
        
    farm_doc = {
        "user_id": user_id,
        "farm_name": farm_name,
        "latitude": float(lat),
        "longitude": float(lon),
        "updated_at": datetime.datetime.utcnow().isoformat()
    }
    
    try:
        # Update if exists for user, else insert
        db.farms.update_one(
            {"user_id": user_id},
            {"$set": farm_doc},
            upsert=True
        )
        return jsonify({"success": True, "message": "Farm location saved successfully", "farm": farm_doc}), 200
    except Exception as e:
        return jsonify({"success": False, "message": f"Failed to save farm location: {str(e)}"}), 500

@farm_bp.route('', methods=['GET'])
def get_farm_location():
    db = get_db()
    if db is None:
        return jsonify({"success": False, "message": "Database connection failed"}), 500
        
    user_id = session.get('user_id', 'anonymous')
    
    try:
        farm = db.farms.find_one({"user_id": user_id})
        if not farm:
            # Return a default center if not set (default coordinates somewhere in India/Karnataka where agriculture is active, e.g. 12.9716, 77.5946)
            return jsonify({
                "success": True,
                "saved": False,
                "farm": {
                    "farm_name": "Default AgriSense Farm",
                    "latitude": 12.9716,
                    "longitude": 77.5946
                }
            })
            
        farm['_id'] = str(farm['_id'])
        return jsonify({"success": True, "saved": True, "farm": farm})
    except Exception as e:
        return jsonify({"success": False, "message": f"Failed to retrieve farm location: {str(e)}"}), 500
