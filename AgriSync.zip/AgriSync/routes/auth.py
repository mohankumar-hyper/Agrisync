from flask import Blueprint, request, jsonify, session
from werkzeug.security import generate_password_hash, check_password_hash
from database import get_db
import datetime

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/register', methods=['POST'])
def register():
    data = request.get_json() or {}
    username = data.get('username')
    mobile = data.get('mobile')
    password = data.get('password')
    
    if not username or not mobile or not password:
        return jsonify({"success": False, "message": "All fields are required"}), 400
        
    db = get_db()
    if db is None:
        return jsonify({"success": False, "message": "Database connection failed"}), 500
        
    # Check if user already exists
    if db.users.find_one({"$or": [{"mobile": mobile}, {"username": username}]}):
        return jsonify({"success": False, "message": "User with this mobile number or username already exists"}), 400
        
    # Create new user
    hashed_pwd = generate_password_hash(password)
    user_doc = {
        "username": username,
        "mobile": mobile,
        "email": mobile,
        "password_hash": hashed_pwd,
        "created_at": datetime.datetime.utcnow().isoformat()
    }
    
    try:
        db.users.insert_one(user_doc)
        return jsonify({"success": True, "message": "User registered successfully"}), 201
    except Exception as e:
        return jsonify({"success": False, "message": f"Registration failed: {str(e)}"}), 500

@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json() or {}
    mobile = (data.get('mobile') or '').strip()
    username = (data.get('username') or '').strip()
    password = data.get('password') or ''

    if not username or not password:
        return jsonify({"success": False, "message": "Username and password are required"}), 400

    db = get_db()
    if db is None:
        return jsonify({"success": False, "message": "Database connection failed"}), 500

    user = None

    # Priority 1: match both mobile + username (most precise)
    if mobile and username:
        user = db.users.find_one({"mobile": mobile, "username": username})

    # Priority 2: match mobile only (covers existing mobile registrations)
    if not user and mobile:
        user = db.users.find_one({"$or": [{"mobile": mobile}, {"email": mobile}]})

    # Priority 3: match username only (supports old email-registered accounts + new ones)
    if not user and username:
        user = db.users.find_one({"username": username})

    if not user or not check_password_hash(user['password_hash'], password):
        return jsonify({"success": False, "message": "Invalid username or password"}), 401
        
    # Set session
    session['user_id'] = str(user['_id'])
    session['username'] = user['username']
    session['email'] = user.get('mobile') or user.get('email')
    
    return jsonify({
        "success": True,
        "message": "Logged in successfully",
        "user": {
            "username": user['username'],
            "email": user.get('mobile') or user.get('email')
        }
    })

@auth_bp.route('/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({"success": True, "message": "Logged out successfully"})

@auth_bp.route('/current_user', methods=['GET'])
def get_current_user():
    if 'user_id' in session:
        return jsonify({
            "logged_in": True,
            "user": {
                "username": session['username'],
                "email": session['email']
            }
        })
    return jsonify({"logged_in": False}), 200
