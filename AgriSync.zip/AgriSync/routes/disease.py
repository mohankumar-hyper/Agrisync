from flask import Blueprint, request, jsonify, session
from werkzeug.utils import secure_filename
from config import Config
from services.disease_api import analyze_plant_disease
from database import get_db
import os
import uuid
import datetime

disease_bp = Blueprint('disease', __name__)

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@disease_bp.route('/detect', methods=['POST'])
def detect_disease():
    if 'file' not in request.files:
        return jsonify({"success": False, "message": "No file part in the request"}), 400
        
    file = request.files['file']
    if file.filename == '':
        return jsonify({"success": False, "message": "No file selected"}), 400
        
    if not (file and allowed_file(file.filename)):
        return jsonify({"success": False, "message": "Invalid file type. Only PNG, JPG, and JPEG are supported."}), 400
        
    db = get_db()
    if db is None:
        return jsonify({"success": False, "message": "Database connection failed"}), 500
        
    unique_name = ""
    filepath = ""
    try:
        # Secure filename and generate temporary location
        ext = file.filename.rsplit('.', 1)[1].lower()
        unique_name = f"{uuid.uuid4().hex}.{ext}"
        filepath = os.path.join(Config.UPLOAD_FOLDER, unique_name)
        
        # Save image physically for processing
        file.save(filepath)
        print(f"Temporary plant leaf saved to: {filepath}")
        
        # Run detection service (calls Kindwise/Plant.id API)
        result = analyze_plant_disease(filepath)
        
        if not result.get("success"):
            # Return error from service, don't crash the application
            return jsonify({
                "success": False,
                "message": result.get("error", "Unable to analyze disease.")
            }), 400
            
        # Determine status flag
        status = result.get("status", "Unknown")
        is_healthy = status == "Healthy"
        
        # Save logs to DB
        user_id = session.get('user_id', 'anonymous')
        disease_doc = {
            "user_id": user_id,
            "filename": unique_name,
            "plant_name": result.get("plant_name", "Unknown"),
            "disease_name": result.get("disease_name", "Unknown"),
            "healthy": is_healthy,
            "confidence": result.get("confidence", 0.0),
            "treatment": result.get("recommended_action", ""),
            "status": status,
            "suggestions": result.get("suggestions", []),
            "created_at": datetime.datetime.utcnow().isoformat()
        }
        db.diseases.insert_one(disease_doc)
        
        # Add a notification trigger if disease is detected
        if not is_healthy and status != "Unable to identify":
            db.notifications.insert_one({
                "title": f"Crop Disease Alert: {result['disease_name']}",
                "message": f"AgriSense detected {result['disease_name']} ({result['confidence']}% confidence) on {result['plant_name']}. Action: {result['recommended_action']}",
                "category": "disease",
                "unread": True,
                "created_at": datetime.datetime.utcnow().isoformat()
            })
            
        # Return success response compatible with both frontend requirements
        return jsonify({
            "success": True,
            "plant_name": result.get("plant_name"),
            "disease_name": result.get("disease_name"),
            "healthy": is_healthy,
            "confidence": result.get("confidence"),
            "status": status,
            "treatment": result.get("recommended_action"),
            "prevention": result.get("suggestions", [{}])[0].get("prevention", "") if result.get("suggestions") else "",
            "suggestions": result.get("suggestions", [])
        })
        
    except Exception as e:
        print(f"Disease detection route failed: {e}")
        return jsonify({"success": False, "message": f"Detection failed: {str(e)}"}), 500
        
    finally:
        # Cleanup temporary files (Requirement 13)
        if filepath and os.path.exists(filepath):
            try:
                os.remove(filepath)
                print(f"Temporary image {filepath} cleaned up.")
            except Exception as cleanup_err:
                print(f"Failed to delete temporary image {filepath}: {cleanup_err}")
