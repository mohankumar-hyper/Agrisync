from flask import Blueprint, request, jsonify
from config import Config
import google.generativeai as genai
import re
import requests

chatbot_bp = Blueprint('chatbot', __name__)

# Configure Gemini key if provided and not a Groq key
gemini_configured = False
if Config.GEMINI_API_KEY and not Config.GEMINI_API_KEY.startswith('gsk_'):
    try:
        genai.configure(api_key=Config.GEMINI_API_KEY)
        gemini_configured = True
    except Exception as e:
        print(f"Error configuring Gemini client: {e}")

@chatbot_bp.route('', methods=['POST'])
def chat():
    data = request.get_json() or {}
    message = data.get('query', '').strip()
    
    if not message:
        return jsonify({"success": False, "message": "Query cannot be empty"}), 400
        
    groq_key = getattr(Config, 'GROQ_API_KEY', '') or ''
    if not groq_key and Config.GEMINI_API_KEY and Config.GEMINI_API_KEY.startswith('gsk_'):
        groq_key = Config.GEMINI_API_KEY

    # Detect if query specifies a crop grown in India
    from routes.learning_data import CROP_AGRONOMY_TEMPLATES
    query_lower = message.lower()
    target_crop = None
    for crop_key in CROP_AGRONOMY_TEMPLATES.keys():
        if crop_key in query_lower:
            target_crop = crop_key
            break

    # Synonyms / multilingual checks for crops grown in India
    if not target_crop:
        if any(w in query_lower for w in ["paddy", "bhath", "ಬೆಳೆ", "ಭತ್ತ", "धान"]):
            target_crop = "rice"
        elif any(w in query_lower for w in ["wheat", "ಗೋಧಿ", "ಗೆहूं", "गेहूं"]):
            target_crop = "wheat"
        elif any(w in query_lower for w in ["maize", "corn", "ಮಕ್ಕೆಜೋಳ", "मक्का"]):
            target_crop = "maize"
        elif any(w in query_lower for w in ["cotton", "ಹತ್ತಿ", "ಕಪಾಸ್", "ಕಪಾಸು"]):
            target_crop = "cotton"
        elif any(w in query_lower for w in ["sugarcane", "ಕಬ್ಬು", "ಗನ್ನಾ", "गन्ना"]):
            target_crop = "sugarcane"
        elif any(w in query_lower for w in ["tomato", "ಟೊಮೆಟೊ", "ಟಮಾಟರ್", "टमाटर"]):
            target_crop = "tomato"
        elif any(w in query_lower for w in ["onion", "ಈರುಳ್ಳಿ", "ಪ್ಯಾಜ್", "प्याज"]):
            target_crop = "onion"
        elif any(w in query_lower for w in ["potato", "ಆಲೂಗಡ್ಡೆ", "ಆಲೂ", "आलू"]):
            target_crop = "potato"
        elif any(w in query_lower for w in ["chilli", "ಚಿಲ್ಲಿ", "ಮೆಣಸಿನಕಾಯಿ", "ಮಿರ್ಚಿ", "मिर्च"]):
            target_crop = "chilli"
        elif any(w in query_lower for w in ["groundnut", "ಶೇಂಗಾ", "ನೆಲಗಡಲೆ", "मूंगफली"]):
            target_crop = "groundnut"
        elif any(w in query_lower for w in ["millet", "ragi", "bajra", "ರಾಗಿ", "ಸಜ್ಜೆ", "बाजरा", "रागी"]):
            target_crop = "millets"
        elif any(w in query_lower for w in ["banana", "ಬಾಳೆಹಣ್ಣು", "ಕೇಲಾ", "केला"]):
            target_crop = "banana"
        elif any(w in query_lower for w in ["mango", "ಮಾವು", "ಆಮ್", "आम"]):
            target_crop = "mango"
        elif any(w in query_lower for w in ["mustard", "ಸಾಸಿವೆ", "ಸಾಸಿವಿ", "सरसों", "सरसो"]):
            target_crop = "mustard"
        elif any(w in query_lower for w in ["chickpea", "gram", "ಕಡಲೆ", "ಚನಾ", "चना"]):
            target_crop = "chickpea"
        elif any(w in query_lower for w in ["turmeric", "ಹಳದಿ", "ಅರಿಶಿನ", "ಹಲ್ದಿ", "हल्दी", "हलदी"]):
            target_crop = "turmeric"

    # Base context for LLM
    context = "You are AgriSense AI, an advanced virtual smart agriculture assistant. Keep your responses structured, helpful, professional, and agriculturally detailed."
    if target_crop:
        crop_data = CROP_AGRONOMY_TEMPLATES[target_crop]
        context += (
            f"\nThe user is asking about the crop '{crop_data['name']}' grown in India. "
            f"Here is the local agronomic package of practices / dataset for '{crop_data['name']}':\n{str(crop_data)}\n"
            f"Make sure to reference this localized information in your reply."
        )

    # Check for Groq API integration
    if groq_key:
        try:
            url = "https://api.groq.com/openai/v1/chat/completions"
            headers = {
                "Authorization": f"Bearer {groq_key}",
                "Content-Type": "application/json"
            }
            payload = {
                "model": "llama-3-8b-8192",
                "messages": [
                    {"role": "system", "content": context},
                    {"role": "user", "content": message}
                ],
                "temperature": 0.7
            }
            response = requests.post(url, json=payload, headers=headers, timeout=10)
            if response.status_code == 200:
                res_data = response.json()
                reply = res_data['choices'][0]['message']['content']
                return jsonify({
                    "success": True,
                    "response": reply,
                    "source": "AgriSense AI (Groq)"
                })
            else:
                print(f"Groq API error status {response.status_code}: {response.text}")
        except Exception as e:
            print(f"Groq API query failed: {e}. Slipping into local agricultural knowledge base.")

    # If Gemini is configured, use the LLM model
    elif gemini_configured:
        try:
            model = genai.GenerativeModel('gemini-pro')
            response = model.generate_content(f"{context}\n\nUser Question: {message}")
            return jsonify({
                "success": True,
                "response": response.text,
                "source": "Google Gemini PRO"
            })
        except Exception as e:
            print(f"Gemini API query failed: {e}. Slipping into local agricultural knowledge base.")
            
    # Local fallback system: Custom Rule-based AI model matching key agriculture domains!
    reply = query_local_knowledge_base(message, target_crop=target_crop)
    return jsonify({
        "success": True,
        "response": reply,
        "source": "AgriSense Local Expert System"
    })


def query_local_knowledge_base(query, target_crop=None):
    query_lower = query.lower()
    
    # Topic 0: Specific crop info lookup from Indian crop dataset
    if target_crop:
        from routes.learning_data import CROP_AGRONOMY_TEMPLATES
        crop_data = CROP_AGRONOMY_TEMPLATES[target_crop]
        return (
            f"🌱 **AgriSense India Crop Database — {crop_data['name']}:**\n\n"
            f"• **Overview:** {crop_data['overview']}\n"
            f"• **Season:** {crop_data['season']}\n"
            f"• **Soil:** {crop_data['soil']}\n"
            f"• **Prep & Sowing:** {crop_data['prep']} / {crop_data['sowing']}\n"
            f"• **Irrigation:** {crop_data['irrigation']}\n"
            f"• **Fertilizer:** {crop_data['fertilizer']}\n"
            f"• **Pest Control:** {crop_data['pest']}\n"
            f"• **Harvest & Yield:** {crop_data['harvest']} (Expected Yield: {crop_data['yield']})\n"
            f"• **Schemes:** {crop_data['schemes']}\n"
            f"• **Profit Margin:** {crop_data['profit']}\n"
            f"• **Growing Regions in India:** {crop_data['growing_regions']}"
        )
    query_lower = query.lower()
    
    # Topic 1: Crop Diseases
    if any(k in query_lower for k in ['disease', 'blight', 'scab', 'blast', 'rust', 'spots', 'leaf', 'mildew']):
        return (
            "🌿 **AgriSense Crop Disease Advisor:**\n\n"
            "Common crop diseases include **Late Blight** (fungal, affects tomatoes/potatoes), **Rice Blast** (affects paddy sheath), and **Apple Scab**.\n\n"
            "**Key Actions:**\n"
            "1. **Detection:** Check under-leaf color, dark spots, and leaf yellowing.\n"
            "2. **Organic Cure:** Spray 1% Neem Oil mixed with soap water or diluted sour buttermilk.\n"
            "3. **Chemical Cure:** Use Hexaconazole, Azoxystrobin, or Copper-oxychloride sprays.\n\n"
            "To diagnose a specific leaf, please upload a picture in our **Disease Diagnosis** panel!"
        )
        
    # Topic 2: Fertilizers
    elif any(k in query_lower for k in ['fertilizer', 'urea', 'npk', 'nitrogen', 'potash', 'phosphorus', 'manure', 'compost', 'dap']):
        return (
            "🧪 **Fertilizer & NPK Management:**\n\n"
            "Crops require three primary macronutrients:\n"
            "- **Nitrogen (N):** Promotes robust green vegetative leaf outgrowth. (Sources: Urea, Ammonium Sulfate)\n"
            "- **Phosphorus (P):** Stimulates root development and flower blossom. (Sources: DAP, Single Super Phosphate)\n"
            "- **Potassium (K):** Confers drought resistance, starch filling, and disease immunity. (Sources: Muriate of Potash)\n\n"
            "**Advice:** Please test your soil and input parameters in the **Crop Recommendation** tab for a custom NPK balance suggestion."
        )
        
    # Topic 3: Irrigation
    elif any(k in query_lower for k in ['irrigation', 'water', 'watering', 'drip', 'sprinkler', 'moisture', 'borewell', 'pumps']):
        return (
            "💧 **Smart Irrigation Practices:**\n\n"
            "Over-watering results in root asphyxiation, while under-watering drops yield.\n"
            "- **Drip Irrigation:** Best for orchard crops, vegetables, and cotton. Saves up to 60% water.\n"
            "- **Sprinkler Irrigation:** Ideal for groundnut, pulses, and wheat.\n"
            "- **Key Rule:** Water early in the morning (5:00 - 7:00 AM) or late afternoon. Never irrigate in high noon to prevent evaporative loss.\n\n"
            "Check our **Smart Irrigation** tab to get real-time watering guidelines based on soil moisture!"
        )
        
    # Topic 4: Weather
    elif any(k in query_lower for k in ['weather', 'forecast', 'rain', 'temperature', 'humidity', 'wind', 'monsoon']):
        return (
            "☀️ **Weather & Agriculture Planning:**\n\n"
            "Weather conditions impact Sowing, Spraying, and Harvesting:\n"
            "- Delay fertilizer inputs and pesticide spraying if rain probability exceeds 60%.\n"
            "- Protect harvested crops in waterproof barns under rain warning conditions.\n\n"
            "Look at the **Live Weather Forecast** on your dashboard for coordinates-linked radar updates."
        )
        
    # Topic 5: Market Prices
    elif any(k in query_lower for k in ['market', 'price', 'rates', 'apmc', 'mandi', 'sell', 'today price', 'wholesale']):
        return (
            "📈 **Crop Market Economics:**\n\n"
            "Currently, crop pricing trends show:\n"
            "- **Paddy:** ₹2,450/quintal (Stable trend)\n"
            "- **Wheat:** ₹2,275/quintal (Firm demand)\n"
            "- **Tomato:** Fluctuating between ₹15-25/kg across mandis.\n\n"
            "Sell direct using our peer-to-peer **Marketplace Hub** to cut middlemen margins and capture retail profit."
        )
        
    # Topic 6: Government Schemes
    elif any(k in query_lower for k in ['scheme', 'subsidies', 'subsidy', 'pm kisan', 'pmfby', 'insurance', 'loan', 'credit card', 'kcc']):
        return (
            "🏛️ **Government Agricultural Subsidies:**\n\n"
            "Important active programs include:\n"
            "1. **PM-KISAN:** Direct transfer of ₹6,000 yearly to marginal landholders.\n"
            "2. **PMFBY (Crop Insurance):** Covers crop losses for natural disasters at 1.5-2% premium rates.\n"
            "3. **Kisan Credit Card (KCC):** Provides agri-loans at concessional interest rates (~4%).\n\n"
            "Head to the **Schemes** tab on the navigation side rail to enter your land parameters and find eligible subsidies."
        )
        
    # Topic 7: Organic Farming
    elif any(k in query_lower for k in ['organic', 'vermicompost', 'panchagavya', 'natural farming', 'bio-fertilizer', 'neem oil', 'cow dung']):
        return (
            "🌱 **Organic & Regenerative Farming:**\n\n"
            "Organic farming preserves soil microbiome and fetches dynamic price premiums:\n"
            "- **Panchagavya:** Liquid fertilizer prepared from cow dung, urine, milk, curd, and ghee. Excellent plant growth promoter.\n"
            "- **Beejamrit:** Cow urine-based microbial seed inoculant that prevents root diseases.\n"
            "- **Compost:** Utilizes vermicompost (earthworms) to turn agricultural residue into humus rich in nitrogen.\n\n"
            "To market organic produce, mark it as 'Organic' in our built-in marketplace!"
        )
        
    # Default hello response
    return (
        "👋 **Hello! I am AgriSense AI, your smart farming assistant.**\n\n"
        "How can I assist you today? I can guide you on:\n"
        "- 🦠 **Diseases:** organic treatments and prevention tips.\n"
        "- 🧪 **NPK/Fertilizers:** optimum soil feeds.\n"
        "- 💧 **Irrigation:** modern drip setups and moisture margins.\n"
        "- 🏆 **Subsidies:** PM-Kisan and local state schemes.\n"
        "- 🌾 **Market Prices:** crop rates and trends.\n"
        "Please ask your question and I will give you expert advice!"
    )
