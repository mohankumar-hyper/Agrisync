from flask import Blueprint, request, jsonify, session
from database import get_db
import datetime

schemes_bp = Blueprint('schemes', __name__)

@schemes_bp.route('/recommend', methods=['POST'])
def recommend_schemes():
    data = request.get_json() or {}
    state = data.get('state', '')
    crop = data.get('crop', '')
    farmer_category = data.get('farmer_category', '')
    
    try:
        land_size = float(data.get('land_size', 0))
    except (TypeError, ValueError):
        land_size = 0.0
        
    db = get_db()
    if db is None:
        return jsonify({"success": False, "message": "Database connection failed"}), 500
        
    try:
        # Build query for MongoDB matching state and eligibility rules
        # General scheme matcher
        query = {
            "$and": [
                # Match state (All States or specific state)
                {"$or": [
                    {"state": "All States"},
                    {"state": {"$regex": f"^{state}$", "$options": "i"}}
                ]},
                # Match land limits
                {"min_land_size": {"$lte": land_size}},
                {"max_land_size": {"$gte": land_size}}
            ]
        }
        
        schemes = list(db.schemes.find(query))
        
        # Sort or refine matches based on Crop or Farmer Category if matching keywords found
        # (Though we filter primarily on State and Land limits, we will sort matches 
        # where the eligible crop matches the user crop)
        refined_schemes = []
        for s in schemes:
            s['_id'] = str(s['_id'])
            
            # Simple match scoring
            score = 0
            if crop and crop.lower() in s.get('eligible_crops', '').lower():
                score += 2
            if farmer_category and farmer_category.lower() in s.get('farmer_category', '').lower():
                score += 1
                
            s['match_score'] = score
            refined_schemes.append(s)
            
        # Sort schemes by match score descending
        refined_schemes.sort(key=lambda x: x['match_score'], reverse=True)
        
        # Log lookups for records
        user_id = session.get('user_id', 'anonymous')
        db.scheme_logs.insert_one({
            "user_id": user_id,
            "inputs": {
                "state": state,
                "crop": crop,
                "land_size": land_size,
                "farmer_category": farmer_category
            },
            "matched_schemes_count": len(refined_schemes),
            "created_at": datetime.datetime.utcnow().isoformat()
        })
        
        return jsonify({
            "success": True,
            "schemes": refined_schemes
        })
        
    except Exception as e:
        return jsonify({"success": False, "message": f"Failed to recommend schemes: {str(e)}"}), 500

@schemes_bp.route('', methods=['GET'])
def get_all_schemes():
    db = get_db()
    if db is None:
        return jsonify({"success": False, "message": "Database connection failed"}), 500
        
    try:
        schemes = list(db.schemes.find({}))
        for s in schemes:
            s['_id'] = str(s['_id'])
        return jsonify({"success": True, "schemes": schemes})
    except Exception as e:
        return jsonify({"success": False, "message": f"Failed to get schemes list: {str(e)}"}), 500
