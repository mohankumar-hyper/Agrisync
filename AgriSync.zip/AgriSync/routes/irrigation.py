from flask import Blueprint, request, jsonify
from models.ai_models import calculate_irrigation

irrigation_bp = Blueprint('irrigation', __name__)

@irrigation_bp.route('/recommend', methods=['POST'])
def recommend_irrigation():
    data = request.get_json() or {}
    
    crop_type = data.get('crop_type')
    weather_condition = data.get('weather_condition')
    
    try:
        soil_moisture = float(data.get('soil_moisture'))
        temperature = float(data.get('temperature'))
    except (TypeError, ValueError):
        return jsonify({"success": False, "message": "Soil moisture and temperature must be valid numbers"}), 400
        
    if not crop_type or not weather_condition:
        return jsonify({"success": False, "message": "Crop type and weather condition are required"}), 400
        
    try:
        recommendation = calculate_irrigation(crop_type, soil_moisture, temperature, weather_condition)
        return jsonify({
            "success": True,
            "data": recommendation
        })
    except Exception as e:
        return jsonify({"success": False, "message": f"Irrigation calculation failed: {str(e)}"}), 500
