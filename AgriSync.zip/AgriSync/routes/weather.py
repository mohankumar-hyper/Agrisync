"""
AgriSense AI — Enhanced Weather Route
- OpenWeatherMap Current Weather API (2.5 and 3.0 compatible)
- 5-Day Forecast (3-hour step → daily summary)
- City-search support
- In-memory cache (5-minute TTL) to reduce API calls
- Smart Agriculture recommendations based on live weather
- Rich simulated fallback when no API key is set
"""

from flask import Blueprint, request, jsonify
from config import Config
import urllib.request
import urllib.parse
import json
import datetime
import random
import time

weather_bp = Blueprint('weather', __name__)

# ── In-Memory Cache ──────────────────────────────────────────────────────────
_cache = {}          # key → {"data": {...}, "ts": <epoch>}
CACHE_TTL = 300      # 5 minutes


def _cache_get(key):
    entry = _cache.get(key)
    if entry and (time.time() - entry["ts"]) < CACHE_TTL:
        return entry["data"]
    return None


def _cache_set(key, data):
    _cache[key] = {"data": data, "ts": time.time()}


# ── Helpers ──────────────────────────────────────────────────────────────────
def _fetch_json(url):
    req = urllib.request.Request(url, headers={"User-Agent": "AgriSenseAI/2.0"})
    with urllib.request.urlopen(req, timeout=8) as resp:
        return json.loads(resp.read().decode())


def _unix_to_time(unix_ts, offset_sec=0):
    """Convert Unix timestamp + UTC offset to HH:MM AM/PM string."""
    dt = datetime.datetime.utcfromtimestamp(unix_ts + offset_sec)
    return dt.strftime("%I:%M %p")


def _rain_probability_label(pop):
    if pop >= 0.7:
        return "Very High"
    if pop >= 0.5:
        return "High"
    if pop >= 0.3:
        return "Moderate"
    if pop >= 0.1:
        return "Low"
    return "Very Low"


def _agri_recommendations(temp, humidity, wind_speed, condition, rain_pop):
    """Generate context-aware farming recommendations from live weather."""
    recs = []
    alerts = []

    cond_lower = condition.lower()
    is_rainy = any(k in cond_lower for k in ["rain", "drizzle", "shower", "thunderstorm"])
    is_hot = temp >= 35
    is_cold = temp <= 12
    is_windy = wind_speed >= 30
    is_humid = humidity >= 80
    high_rain_risk = rain_pop >= 0.5

    # Irrigation
    if is_rainy or high_rain_risk:
        recs.append({
            "icon": "fa-droplet-slash",
            "color": "blue",
            "title": "Skip Irrigation Today",
            "detail": f"Rain probability is {round(rain_pop*100)}%. Natural rainfall will suffice — conserve water.",
        })
    elif is_hot and humidity < 50:
        recs.append({
            "icon": "fa-faucet-drip",
            "color": "orange",
            "title": "irrigate Early Morning",
            "detail": f"Temp {temp}°C with low humidity ({humidity}%). Water crops before 7 AM to reduce evaporative loss.",
        })
    else:
        recs.append({
            "icon": "fa-droplet",
            "color": "green",
            "title": "Normal Irrigation Advised",
            "detail": "Conditions are moderate. Follow your standard irrigation schedule.",
        })

    # Pesticide / Spraying
    if is_windy:
        alerts.append({
            "icon": "fa-wind",
            "color": "orange",
            "title": "Avoid Pesticide Spraying",
            "detail": f"Wind speed {wind_speed} km/h — chemical drift hazard. Delay spraying until wind < 20 km/h.",
        })
    elif is_rainy or high_rain_risk:
        alerts.append({
            "icon": "fa-cloud-showers-heavy",
            "color": "red",
            "title": "Don't Spray — Rain Forecast",
            "detail": "Rain will wash away pesticides. Wait for 2 dry days before applying foliar sprays.",
        })
    else:
        recs.append({
            "icon": "fa-spray-can-sparkles",
            "color": "green",
            "title": "Good Day for Spraying",
            "detail": "Calm winds & no rain. Optimal window: 6 AM – 10 AM or 4 PM – 6 PM.",
        })

    # Disease Risk
    if is_humid and is_rainy:
        alerts.append({
            "icon": "fa-virus",
            "color": "red",
            "title": "High Fungal Disease Risk",
            "detail": f"Humidity {humidity}% + rain → ideal for Late Blight, Powdery Mildew. Scout crops closely and apply preventive fungicides.",
        })
    elif is_humid:
        alerts.append({
            "icon": "fa-triangle-exclamation",
            "color": "orange",
            "title": "Elevated Disease Risk",
            "detail": f"Humidity {humidity}% promotes fungal and bacterial infections. Ensure good field drainage.",
        })

    # Pest Risk
    if temp >= 25 and humidity >= 65 and not is_rainy:
        alerts.append({
            "icon": "fa-bug",
            "color": "orange",
            "title": "Moderate Pest Activity",
            "detail": f"Warm ({temp}°C) & humid ({humidity}%) weather favours aphids, thrips and stem borers. Check crop canopy regularly.",
        })

    # Harvest Warning
    if is_rainy and rain_pop >= 0.6:
        alerts.append({
            "icon": "fa-wheat-awn-circle-exclamation",
            "color": "red",
            "title": "Delay Harvest Operations",
            "detail": "Significant rainfall expected. Delay grain threshing and drying. Wet grains risk mold and quality loss.",
        })
    elif is_hot and humidity < 40:
        recs.append({
            "icon": "fa-sun",
            "color": "green",
            "title": "Excellent Harvest Conditions",
            "detail": f"Low humidity ({humidity}%) and sunshine → ideal for harvesting, drying, and sun-curing grains.",
        })

    # Cold stress
    if is_cold:
        alerts.append({
            "icon": "fa-temperature-low",
            "color": "blue",
            "title": "Cold Stress Alert",
            "detail": f"Temperature {temp}°C may stress frost-sensitive crops. Cover young seedlings and delay transplanting.",
        })

    return {"recommendations": recs, "alerts": alerts}


# ── Real API Processing ───────────────────────────────────────────────────────
def _build_current(current_raw, offset_sec):
    """Build standardised current-weather dict from OWM current endpoint."""
    main = current_raw.get("main", {})
    weather = current_raw.get("weather", [{}])[0]
    wind = current_raw.get("wind", {})
    sys = current_raw.get("sys", {})
    clouds = current_raw.get("clouds", {})
    rain = current_raw.get("rain", {})
    vis = current_raw.get("visibility", 10000)

    temp = round(main.get("temp", 25), 1)
    feels_like = round(main.get("feels_like", temp), 1)
    humidity = main.get("humidity", 60)
    pressure = main.get("pressure", 1013)
    wind_ms = wind.get("speed", 3)
    wind_kmh = round(wind_ms * 3.6, 1)
    wind_dir = wind.get("deg", 0)
    cloud_pct = clouds.get("all", 0)
    rain_1h = rain.get("1h", 0.0)
    visibility_km = round(vis / 1000, 1)
    pop = current_raw.get("pop", 0.0)

    sunrise = _unix_to_time(sys.get("sunrise", 0), offset_sec)
    sunset = _unix_to_time(sys.get("sunset", 0), offset_sec)

    cond = weather.get("main", "Clear")
    desc = weather.get("description", "clear sky").capitalize()
    icon = weather.get("icon", "01d")

    now_ist = datetime.datetime.utcnow() + datetime.timedelta(seconds=offset_sec)

    agri = _agri_recommendations(temp, humidity, wind_kmh, cond, pop)

    return {
        "city": current_raw.get("name", "My Farm"),
        "country": sys.get("country", "IN"),
        "temperature": temp,
        "feels_like": feels_like,
        "humidity": humidity,
        "pressure": pressure,
        "wind_speed": wind_kmh,
        "wind_direction": wind_dir,
        "cloud_coverage": cloud_pct,
        "rain_1h": rain_1h,
        "visibility_km": visibility_km,
        "condition": cond,
        "description": desc,
        "icon": icon,
        "rain_prediction": _rain_probability_label(pop),
        "rain_probability": round(pop * 100),
        "sunrise": sunrise,
        "sunset": sunset,
        "last_updated": now_ist.strftime("%d %b %Y, %I:%M %p"),
        "latitude": current_raw.get("coord", {}).get("lat"),
        "longitude": current_raw.get("coord", {}).get("lon"),
        "agri_insights": agri,
    }


def _build_forecast(forecast_raw):
    """Collapse 3-hour OWM entries into daily forecast summaries (5 days)."""
    days = {}
    for item in forecast_raw.get("list", []):
        date_str = item["dt_txt"].split(" ")[0]
        if date_str not in days:
            days[date_str] = []
        days[date_str].append(item)

    result = []
    for date_str, items in list(days.items())[:5]:
        temps = [i["main"]["temp"] for i in items]
        humids = [i["main"]["humidity"] for i in items]
        pops = [i.get("pop", 0) for i in items]
        # Pick midday item for condition/icon
        midday = next((i for i in items if "12:00" in i["dt_txt"]), items[len(items) // 2])
        cond_w = midday["weather"][0]
        dt = datetime.datetime.strptime(date_str, "%Y-%m-%d")

        result.append({
            "date": date_str,
            "day": dt.strftime("%A"),
            "short_day": dt.strftime("%a"),
            "display_date": dt.strftime("%b %d"),
            "temp_max": round(max(temps), 1),
            "temp_min": round(min(temps), 1),
            "humidity": round(sum(humids) / len(humids)),
            "rain_prob": round(max(pops) * 100),
            "condition": cond_w["main"],
            "description": cond_w["description"].capitalize(),
            "icon": cond_w["icon"],
        })

    return result


# ── Route: Current + Forecast by lat/lon ─────────────────────────────────────
@weather_bp.route("", methods=["GET"])
def get_weather():
    lat = request.args.get("lat")
    lon = request.args.get("lon")
    city = request.args.get("city", "").strip()
    api_key = Config.OPENWEATHER_API_KEY

    cache_key = f"{lat},{lon},{city}"
    cached = _cache_get(cache_key)
    if cached:
        return jsonify({"success": True, "source": cached.get("source", "cache"), "data": cached, "cached": True})

    if api_key:
        try:
            if city:
                # Geocode city → lat/lon first
                geo_url = (
                    f"https://api.openweathermap.org/geo/1.0/direct"
                    f"?q={urllib.parse.quote(city)}&limit=1&appid={api_key}"
                )
                geo = _fetch_json(geo_url)
                if not geo:
                    return jsonify({"success": False, "message": f"City '{city}' not found. Please check the spelling."}), 404
                lat = str(geo[0]["lat"])
                lon = str(geo[0]["lon"])

            if not lat or not lon:
                # Default — Bangalore
                lat, lon = "12.9716", "77.5946"

            # Current weather
            cur_url = (
                f"https://api.openweathermap.org/data/2.5/weather"
                f"?lat={lat}&lon={lon}&appid={api_key}&units=metric"
            )
            cur_raw = _fetch_json(cur_url)
            offset_sec = cur_raw.get("timezone", 19800)  # default IST

            # 5-day forecast
            fc_url = (
                f"https://api.openweathermap.org/data/2.5/forecast"
                f"?lat={lat}&lon={lon}&appid={api_key}&units=metric"
            )
            fc_raw = _fetch_json(fc_url)

            current = _build_current(cur_raw, offset_sec)
            current["forecast"] = _build_forecast(fc_raw)
            current["source"] = "OpenWeatherMap API"

            _cache_set(cache_key, current)
            return jsonify({"success": True, "source": "api", "data": current})

        except urllib.error.HTTPError as e:
            if e.code == 401:
                return jsonify({
                    "success": False,
                    "message": "Invalid OpenWeatherMap API key. Please check OPENWEATHER_API_KEY in your .env file.",
                    "data": _generate_simulated(lat, lon),
                    "source": "simulated",
                })
            if e.code == 404:
                return jsonify({"success": False, "message": f"Location not found by weather API. ({e.code})"}), 404
            print(f"Weather HTTP error {e.code}: {e}")

        except Exception as e:
            print(f"Weather API exception: {e}. Falling back to simulated data.")

    # Simulated fallback (no API key, or API error)
    sim = _generate_simulated(lat, lon, city)
    _cache_set(cache_key, sim)
    return jsonify({"success": True, "source": "simulated", "data": sim})


# ── Route: City Search ────────────────────────────────────────────────────────
@weather_bp.route("/search", methods=["GET"])
def search_city():
    city = request.args.get("city", "").strip()
    if not city:
        return jsonify({"success": False, "message": "City name required"}), 400
    # Re-use main route logic by calling get_weather with city param
    return get_weather()


# ── Route: Cache Clear (debug/refresh) ───────────────────────────────────────
@weather_bp.route("/refresh", methods=["POST"])
def refresh_weather():
    _cache.clear()
    return jsonify({"success": True, "message": "Weather cache cleared. Next request will fetch fresh data."})


# ── Simulated Fallback Generator ──────────────────────────────────────────────
def _generate_simulated(lat=None, lon=None, city=None):
    seed = (
        int(float(lat) * 100 + float(lon) * 100) % 1000
        if lat and lon else random.randint(0, 999)
    )
    random.seed(seed)

    temp = round(22 + random.uniform(5, 13), 1)
    feels_like = round(temp - random.uniform(1, 4), 1)
    humidity = random.randint(52, 88)
    pressure = random.randint(1005, 1020)
    wind_kmh = round(5 + random.uniform(2, 18), 1)
    wind_dir = random.randint(0, 359)
    visibility_km = round(random.uniform(5, 15), 1)
    cloud_pct = random.randint(10, 80)

    conditions_pool = [
        ("Rain", "Light rain showers", "10d", 0.72),
        ("Clouds", "Scattered clouds", "03d", 0.18),
        ("Clear", "Clear sunny day", "01d", 0.04),
        ("Thunderstorm", "Heavy thunderstorm", "11d", 0.85),
        ("Drizzle", "Light drizzle", "09d", 0.45),
    ]
    weights = [0.20, 0.25, 0.40, 0.05, 0.10]
    choice = random.choices(conditions_pool, weights=weights)[0]
    cond, desc, icon, pop = choice

    base = datetime.datetime.now()
    sunrise = (base.replace(hour=6, minute=random.randint(10, 30))).strftime("%I:%M %p")
    sunset = (base.replace(hour=18, minute=random.randint(20, 45))).strftime("%I:%M %p")

    forecast = []
    forecast_conds = [
        ("Clear", "Clear sky", "01d"), ("Clouds", "Partly cloudy", "02d"),
        ("Rain", "Light showers", "10d"), ("Clouds", "Overcast", "04d"),
        ("Thunderstorm", "Thunderstorm", "11d"),
    ]
    for i in range(5):
        dd = base + datetime.timedelta(days=i)
        fc = forecast_conds[i % len(forecast_conds)]
        d_temp = round(temp + random.uniform(-4, 4), 1)
        forecast.append({
            "date": dd.strftime("%Y-%m-%d"),
            "day": dd.strftime("%A"),
            "short_day": dd.strftime("%a"),
            "display_date": dd.strftime("%b %d"),
            "temp_max": round(d_temp + random.uniform(1, 3), 1),
            "temp_min": round(d_temp - random.uniform(2, 5), 1),
            "humidity": min(100, max(20, humidity + random.randint(-12, 12))),
            "rain_prob": 75 if "Rain" in fc[0] or "Thunder" in fc[0] else (35 if "Cloud" in fc[0] else 8),
            "condition": fc[0],
            "description": fc[1],
            "icon": fc[2],
        })

    random.seed(None)
    agri = _agri_recommendations(temp, humidity, wind_kmh, cond, pop)

    location_name = city if city else ("Farm Location" if lat and lon else "Vikas Farm, Bangalore")

    return {
        "city": location_name,
        "country": "IN",
        "temperature": temp,
        "feels_like": feels_like,
        "humidity": humidity,
        "pressure": pressure,
        "wind_speed": wind_kmh,
        "wind_direction": wind_dir,
        "cloud_coverage": cloud_pct,
        "rain_1h": 0.0,
        "visibility_km": visibility_km,
        "condition": cond,
        "description": desc.capitalize(),
        "icon": icon,
        "rain_prediction": _rain_probability_label(pop),
        "rain_probability": round(pop * 100),
        "sunrise": sunrise,
        "sunset": sunset,
        "last_updated": datetime.datetime.now().strftime("%d %b %Y, %I:%M %p"),
        "latitude": float(lat) if lat else 12.9716,
        "longitude": float(lon) if lon else 77.5946,
        "agri_insights": agri,
        "forecast": forecast,
        "source": "simulated",
    }
