from flask import Blueprint, request, jsonify, session
from models.ai_models import predict_crop
from database import get_db
import datetime

crop_bp = Blueprint('crop', __name__)

@crop_bp.route('/recommend', methods=['POST'])
def recommend_crop():
    data = request.get_json() or {}
    
    # Input validation
    try:
        n = float(data.get('N'))
        p = float(data.get('P'))
        k = float(data.get('K'))
        temp = float(data.get('temperature'))
        hum = float(data.get('humidity'))
        ph = float(data.get('ph'))
        rain = float(data.get('rainfall'))
    except (TypeError, ValueError):
        return jsonify({"success": False, "message": "All parameters (N, P, K, temperature, humidity, ph, rainfall) must be valid numbers"}), 400
        
    try:
        crop_name, confidence = predict_crop(n, p, k, temp, hum, ph, rain)
        
        # Log to MongoDB
        db = get_db()
        if db is not None:
            user_id = session.get('user_id', 'anonymous')
            log_doc = {
                "user_id": user_id,
                "inputs": {
                    "N": n, "P": p, "K": k,
                    "temperature": temp, "humidity": hum,
                    "ph": ph, "rainfall": rain
                },
                "recommended_crop": crop_name,
                "confidence": confidence,
                "created_at": datetime.datetime.utcnow().isoformat()
            }
            db.crops.insert_one(log_doc)
            
        return jsonify({
            "success": True,
            "recommended_crop": crop_name,
            "confidence": confidence,
            "fertilizer_tip": get_fertilizer_tip(crop_name, n, p, k)
        })
    except Exception as e:
        return jsonify({"success": False, "message": f"Crop recommendation failed: {str(e)}"}), 500

def get_fertilizer_tip(crop, n, p, k):
    """Provides dynamic guidelines based on values and recommended crop."""
    tips = []
    if n < 40:
        tips.append("Nitrogen level is low. Consider adding Urea or organic manure.")
    elif n > 110:
        tips.append("Nitrogen level is high. Reduce nitrogenous fertilizers to avoid leaf burn.")
        
    if p < 30:
        tips.append("Phosphorus is weak. Add Single Super Phosphate (SSP) or DAP.")
        
    if k < 20:
        tips.append("Potash deficiency detected. Apply Muriate of Potash (MOP) to boost crop strength.")
        
    if not tips:
        tips.append("Your N-P-K balances look optimal. Maintain standard organic compost additions.")
        
    return " ".join(tips)
