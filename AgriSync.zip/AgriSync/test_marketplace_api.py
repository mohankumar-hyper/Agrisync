import unittest
import json
from unittest.mock import patch
from app import app

class TestMarketplaceAPI(unittest.TestCase):
    def setUp(self):
        self.app = app.test_client()
        self.app.testing = True

    def test_get_products(self):
        response = self.app.get('/api/marketplace')
        data = json.loads(response.data)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(data['success'])
        self.assertIn('products', data)

    def test_add_product_validation(self):
        # Missing product_name and category
        payload = {
            "price": "abc",
            "quantity": "10"
        }
        response = self.app.post('/api/marketplace/upload', data=payload)
        data = json.loads(response.data)
        self.assertEqual(response.status_code, 400)
        self.assertFalse(data['success'])
        self.assertEqual(data['message'], "Price and Quantity must be numbers")

    def test_add_product_success(self):
        payload = {
            "product_name": "Test Basmati Grain",
            "category": "Grains",
            "price": "95.5",
            "quantity": "250",
            "unit": "kg",
            "description": "Organic premium quality Basmati rice from organic farm."
        }
        response = self.app.post('/api/marketplace/upload', data=payload)
        data = json.loads(response.data)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(data['success'])
        self.assertEqual(data['message'], "Product added successfully!")

    def test_contact_farmer_validation(self):
        # Missing contact details
        payload = {
            "product_name": "Test Basmati Grain",
            "farmer_name": "Farmer Vikas"
        }
        response = self.app.post('/api/marketplace/contact', 
                                 data=json.dumps(payload),
                                 content_type='application/json')
        data = json.loads(response.data)
        self.assertEqual(response.status_code, 400)
        self.assertFalse(data['success'])
        self.assertIn("required", data['message'])

    def test_contact_farmer_success(self):
        payload = {
            "product_name": "Test Basmati Grain",
            "farmer_name": "Farmer Vikas",
            "buyer_name": "Rohan Wholesaler",
            "buyer_contact": "+91 9777788888",
            "message": "Interested in buying 100 kgs. Please contact back."
        }
        response = self.app.post('/api/marketplace/contact', 
                                 data=json.dumps(payload),
                                 content_type='application/json')
        data = json.loads(response.data)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(data['success'])
        self.assertEqual(data['message'], "Farmer notified successfully. They will contact you shortly.")

if __name__ == '__main__':
    unittest.main()
