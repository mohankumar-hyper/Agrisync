import os
import base64
import requests
import logging
from config import Config

logger = logging.getLogger(__name__)

def analyze_plant_disease(image_path: str):
    """
    Sends the leaf image to the external Plant.id API for health assessment and identification.
    Handles exceptions like timeout, rate limit, invalid credentials, and bad responses.
    
    Returns a dict containing:
        - success (bool)
        - error (str or None)
        - plant_name (str)
        - disease_name (str)
        - confidence (float)
        - status (str)
        - recommended_action (str)
        - suggestions (list of dicts containing name and confidence)
    """
    api_key = os.environ.get('DISEASE_API_KEY', '').strip()
    api_url = os.environ.get('DISEASE_API_URL', '').strip()

    # Default to Plant.id official URL if not specified
    if not api_url:
        api_url = "https://api.plant.id/v3/health_assessment"

    # Input validations
    if not image_path or not os.path.exists(image_path):
        return {
            "success": False,
            "error": "Invalid image: File does not exist.",
            "plant_name": "Unknown",
            "disease_name": "Unknown",
            "confidence": 0.0,
            "status": "Error",
            "recommended_action": "Please upload a valid image file.",
            "suggestions": []
        }

    # Verify if file size is reasonable (e.g. < 15MB to be safe, Plant.id limit is 50MB)
    try:
        file_size = os.path.getsize(image_path)
        if file_size > 15 * 1024 * 1024:
            return {
                "success": False,
                "error": "Invalid image: File size too large (maximum 15MB).",
                "plant_name": "Unknown",
                "disease_name": "Unknown",
                "confidence": 0.0,
                "status": "Error",
                "recommended_action": "Please resize your image and try again.",
                "suggestions": []
            }
    except Exception as e:
        logger.error(f"Failed to check image file size: {e}")

    # Read and encode image to base64
    try:
        with open(image_path, "rb") as image_file:
            encoded_string = base64.b64encode(image_file.read()).decode('utf-8')
    except Exception as e:
        return {
            "success": False,
            "error": f"Invalid image: Failed to read or process the image file. Details: {str(e)}",
            "plant_name": "Unknown",
            "disease_name": "Unknown",
            "confidence": 0.0,
            "status": "Error",
            "recommended_action": "Please ensure the file is a valid image (PNG or JPG) and not corrupted.",
            "suggestions": []
        }

    # If API key is missing or is the placeholder, return a user-friendly configuration notice or mock prediction
    # to facilitate testing/demo, but clearly mark it as mock.
    is_placeholder_key = not api_key or "your_api_key" in api_key.lower() or api_key == "PLACEHOLDER"
    
    if is_placeholder_key:
        logger.warning("DISEASE_API_KEY is not configured or is a placeholder. Returning simulated response for local testing.")
        return get_mock_response()

    # Prepare API Request
    headers = {
        "Api-Key": api_key,
        "Content-Type": "application/json"
    }
    
    # We want to retrieve details: common names, description, treatment, etc.
    # The API endpoint supports query params for extra details.
    params = {
        "details": "local_name,description,treatment,classification,cause,common_names"
    }
    
    payload = {
        "images": [encoded_string]
    }

    try:
        # Send HTTP request with a 12-second timeout
        response = requests.post(api_url, headers=headers, json=payload, params=params, timeout=12)
        
        # 1. API key auth failure
        if response.status_code in (401, 403):
            return {
                "success": False,
                "error": "Invalid API key: Unauthorized access to plant disease detection service.",
                "plant_name": "Unknown",
                "disease_name": "Unknown",
                "confidence": 0.0,
                "status": "Unauthorized",
                "recommended_action": "Please configure a valid DISEASE_API_KEY in your .env file.",
                "suggestions": []
            }
        
        # 2. Rate limit hit
        if response.status_code == 429:
            return {
                "success": False,
                "error": "API rate limit exceeded: Too many requests sent to the disease API.",
                "plant_name": "Unknown",
                "disease_name": "Unknown",
                "confidence": 0.0,
                "status": "Rate Limited",
                "recommended_action": "Please wait a moment before uploading another leaf image.",
                "suggestions": []
            }
            
        # 3. Server errors or other unexpected status codes
        if response.status_code != 200:
            return {
                "success": False,
                "error": f"API unavailable: The plant disease detection server returned status code {response.status_code}.",
                "plant_name": "Unknown",
                "disease_name": "Unknown",
                "confidence": 0.0,
                "status": "Server Error",
                "recommended_action": "Please try again later. If the issue persists, contact support.",
                "suggestions": []
            }

        # Try to parse JSON output
        try:
            data = response.json()
        except ValueError:
            return {
                "success": False,
                "error": "Unexpected API response: The server response is not in valid JSON format.",
                "plant_name": "Unknown",
                "disease_name": "Unknown",
                "confidence": 0.0,
                "status": "Invalid JSON",
                "recommended_action": "Please check the API URL configuration and try again.",
                "suggestions": []
            }
        
        # Check if the result details are present
        if "result" not in data:
            return {
                "success": False,
                "error": "Unexpected API response: Missing 'result' block in API response payload.",
                "plant_name": "Unknown",
                "disease_name": "Unknown",
                "confidence": 0.0,
                "status": "Malformed Response",
                "recommended_action": "Please verify if the configured API URL endpoint is correct.",
                "suggestions": []
            }
            
        result = data["result"]
        
        # Check if it was identified as a plant.
        # If is_plant is clearly False, we display "Unable to identify the disease..."
        is_plant_data = result.get("is_plant")
        if is_plant_data:
            # binary flag or low probability (< 0.4)
            is_plant_binary = is_plant_data.get("binary", True)
            is_plant_prob = is_plant_data.get("probability", 1.0)
            if not is_plant_binary or is_plant_prob < 0.4:
                return {
                    "success": False,
                    "error": "Unable to identify the disease. Please upload a clearer leaf image.",
                    "plant_name": "Unknown",
                    "disease_name": "Unknown",
                    "confidence": 0.0,
                    "status": "Not a Plant Leaf",
                    "recommended_action": "Please select a clearer, well-lit close-up photo of the single leaf query.",
                    "suggestions": []
                }

        # 4. Extract Crop/Plant Name
        plant_name = "Unknown Plant"
        classification = result.get("classification")
        if classification and classification.get("suggestions"):
            top_class = classification["suggestions"][0]
            # Try to get the common name
            details = top_class.get("details", {})
            common_names = details.get("common_names")
            if common_names and isinstance(common_names, list) and len(common_names) > 0:
                plant_name = common_names[0].strip().title()
            else:
                plant_name = top_class.get("name", "Unknown Plant").strip().title()

        # 5. Extract Health Status
        # Retrieve the helper blocks
        health_assessment = result.get("health_assessment", result.get("health", {}))
        
        # Standard v3 API has helper is_healthy boolean
        is_healthy_data = health_assessment.get("is_healthy", {})
        is_healthy = is_healthy_data.get("binary", True)
        is_healthy_prob = is_healthy_data.get("probability", 1.0)
        
        # 6. Extract Disease list and metadata
        # Plant.id uses "diseases" or "suggestions" under health_assessment
        api_diseases = health_assessment.get("diseases", health_assessment.get("suggestions", []))
        
        # If the API says it's healthy, or there are no disease suggestions
        if is_healthy or not api_diseases:
            healthy_confidence = round(is_healthy_prob * 100, 1)
            return {
                "success": True,
                "error": None,
                "plant_name": plant_name,
                "disease_name": "No disease detected",
                "confidence": healthy_confidence,
                "status": "Healthy",
                "recommended_action": "No treatment required. Maintain regular irrigation and organic compost.",
                "suggestions": []
            }
            
        # If unhealthy, compile the diseases list
        disease_suggestions = []
        for dis in api_diseases:
            name = dis.get("name", "Unknown Disease").strip()
            prob = dis.get("probability", 0.0)
            
            dis_details = dis.get("details", {})
            treatment_info = dis_details.get("treatment", {})
            
            # treatment can be a string, list, or dict
            treatment_str = ""
            if isinstance(treatment_info, dict):
                # Collect subfields if it has chemical/biological/prevention guidelines
                parts = []
                for k, v in treatment_info.items():
                    if v:
                        if isinstance(v, list):
                            parts.append(f"{k.capitalize()}: {', '.join(v)}")
                        else:
                            parts.append(f"{k.capitalize()}: {v}")
                treatment_str = " | ".join(parts) if parts else ""
            elif isinstance(treatment_info, list):
                treatment_str = ", ".join(treatment_info)
            elif isinstance(treatment_info, str):
                treatment_str = treatment_info
                
            # Fallback warning if treatment is not provided
            if not treatment_str or len(treatment_str.strip()) < 5:
                treatment_str = "Consult a local agricultural expert for appropriate treatment."
                
            # Grab prevention if exists
            prevention_info = dis_details.get("prevention", "")
            prevention_str = ""
            if isinstance(prevention_info, list):
                prevention_str = ", ".join(prevention_info)
            elif isinstance(prevention_info, str):
                prevention_str = prevention_info

            disease_suggestions.append({
                "name": name,
                "confidence": round(prob * 100, 1),
                "treatment": treatment_str.strip(),
                "prevention": prevention_str.strip()
            })
            
        # Sort by confidence descending
        disease_suggestions.sort(key=lambda x: x["confidence"], reverse=True)
        
        # Primary disease details
        primary_disease = disease_suggestions[0]
        
        return {
            "success": True,
            "error": None,
            "plant_name": plant_name,
            "disease_name": primary_disease["name"],
            "confidence": primary_disease["confidence"],
            "status": "Diseased",
            "recommended_action": primary_disease["treatment"],
            "suggestions": disease_suggestions
        }

    # 7. Handle requests client connection problems
    except requests.exceptions.Timeout:
        return {
            "success": False,
            "error": "API timeout: The plant disease detection API request timed out.",
            "plant_name": "Unknown",
            "disease_name": "Unknown",
            "confidence": 0.0,
            "status": "Timeout",
            "recommended_action": "Please check your internet connection and try diagnosing again.",
            "suggestions": []
        }
        
    except requests.exceptions.ConnectionError:
        return {
            "success": False,
            "error": "API unavailable: Could not establish a connection to the disease detection server.",
            "plant_name": "Unknown",
            "disease_name": "Unknown",
            "confidence": 0.0,
            "status": "Connection Error",
            "recommended_action": "Verify if the server is online or if your network profile allows outgoing API calls.",
            "suggestions": []
        }
        
    except Exception as e:
        return {
            "success": False,
            "error": f"Unexpected API response: An error occurred during request handling. Details: {str(e)}",
            "plant_name": "Unknown",
            "disease_name": "Unknown",
            "confidence": 0.0,
            "status": "Fail",
            "recommended_action": "Consult a local agricultural expert for appropriate treatment.",
            "suggestions": []
        }

def get_mock_response():
    """
    Returns a realistic mock response for local environment testing.
    This simulates standard disease API responses if key is not configured.
    """
    # Simply randomize or return some standard options for Paddy or Tomato leaf
    mock_choice = os.urandom(1)[0] % 4
    
    if mock_choice == 0:
        return {
            "success": True,
            "error": None,
            "plant_name": "Paddy (Rice)",
            "disease_name": "Leaf Blast",
            "confidence": 94.0,
            "status": "Diseased",
            "recommended_action": "Avoid excess nitrogen fertilizer, maintain proper field flooding, and use blast-resistant seeds. Consult a local agricultural expert for appropriate chemical treatment.",
            "suggestions": [
                {"name": "Leaf Blast", "confidence": 94.0},
                {"name": "Brown Spot", "confidence": 18.5},
                {"name": "Bacterial Leaf Blight", "confidence": 8.0}
            ]
        }
    elif mock_choice == 1:
        return {
            "success": True,
            "error": None,
            "plant_name": "Tomato",
            "disease_name": "Late Blight",
            "confidence": 88.5,
            "status": "Diseased",
            "recommended_action": "Use disease-free seed, avoid overhead irrigation, ensure wider spacing between plants. Clean all infected residues after harvest.",
            "suggestions": [
                {"name": "Late Blight", "confidence": 88.5},
                {"name": "Early Blight", "confidence": 72.3},
                {"name": "Septoria Leaf Spot", "confidence": 23.0}
            ]
        }
    elif mock_choice == 2:
        return {
            "success": True,
            "error": None,
            "plant_name": "Corn",
            "disease_name": "Common Rust",
            "confidence": 91.0,
            "status": "Diseased",
            "recommended_action": "Plant resistant hybrids, remove crop residues, rotate crops with non-grasses to break lifecycle.",
            "suggestions": [
                {"name": "Common Rust", "confidence": 91.0},
                {"name": "Southern Rust", "confidence": 42.0}
            ]
        }
    else:
        return {
            "success": True,
            "error": None,
            "plant_name": "Apple",
            "disease_name": "No disease detected",
            "confidence": 97.5,
            "status": "Healthy",
            "recommended_action": "No treatment required. Maintain regular irrigation and organic compost.",
            "suggestions": []
        }
