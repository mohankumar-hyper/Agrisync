import os
import requests
import json

def test_disease_detection():
    url = "http://127.0.0.1:5000/api/disease/detect"
    img_path = os.path.join("static", "uploads", "seed_default.jpg")
    
    if not os.path.exists(img_path):
        print(f"Error: Seed file {img_path} not found.")
        return
        
    try:
        with open(img_path, "rb") as f:
            files = {"file": ("seed_default.jpg", f, "image/jpeg")}
            response = requests.post(url, files=files, timeout=12)
            
            with open("test_out_utf8.txt", "w", encoding="utf-8") as out_file:
                out_file.write(f"Status Code: {response.status_code}\n")
                out_file.write(json.dumps(response.json(), indent=2))
            print("Successfully written to test_out_utf8.txt.")
    except Exception as e:
        print(f"Test failed with error: {e}")

if __name__ == "__main__":
    test_disease_detection()
