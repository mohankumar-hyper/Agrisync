import logging
from pymongo import MongoClient
from config import Config

logger = logging.getLogger(__name__)

# Global mongo client and database instances
client = None
db = None

def init_db(app=None):
    """
    Connect to MongoDB and seed configurations.
    Returns the database client and database object.
    """
    global client, db
    
    mongo_uri = Config.MONGO_URI
    try:
        client = MongoClient(mongo_uri, serverSelectionTimeoutMS=5000)
        # Check connection
        client.server_info()
        # Get database from URI (extracting from URI, default is 'agrisense_db')
        db_name = mongo_uri.split('/')[-1].split('?')[0]
        if not db_name:
            db_name = 'agrisense_db'
        db = client[db_name]
        logger.info(f"Successfully connected to MongoDB database: {db_name}")
        print(f"Connected to MongoDB at {mongo_uri}")
        
        # Seed default collections and sample data
        seed_marketplace()
        seed_workers()
        seed_schemes()
        seed_market_prices()
        seed_notifications()
        
        return db
    except Exception as e:
        logger.error(f"Error connecting to MongoDB: {e}")
        print(f"MongoDB connection failed: {e}")
        # Return none or raise. We can return a mini mock-client or let it run, 
        # but since MongoDB is running, it will succeed!
        return None

def get_db():
    global db
    if db is None:
        # fallback initialisation without app
        init_db()
    return db

def seed_marketplace():
    """Seed marketplace products if empty."""
    database = get_db()
    if database is None:
        return
    col = database['marketplace']
    if col.count_documents({}) == 0:
        sample_products = [
            {
                "product_name": "Premium Basmati Rice",
                "category": "Grains",
                "price": 85.00,
                "quantity": 500,
                "unit": "kg",
                "farmer_name": "Vikas Patel",
                "farmer_contact": "+91 9876543210",
                "location": "Punjab",
                "image_url": "/static/uploads/seed_basmati.jpg",
                "description": "Organic basmati rice, direct from farm, aged 1 year.",
                "created_at": "2026-08-07T12:00:00Z"
            },
            {
                "product_name": "Fresh Red Tomatoes",
                "category": "Vegetables",
                "price": 25.00,
                "quantity": 200,
                "unit": "kg",
                "farmer_name": "Rajesh Kumar",
                "farmer_contact": "+91 8765432109",
                "location": "Karnataka",
                "image_url": "/static/uploads/seed_tomato.jpg",
                "description": "Succulent, chemical-free red tomatoes harvested today.",
                "created_at": "2026-08-07T13:00:00Z"
            },
            {
                "product_name": "Organic Turmeric Powder",
                "category": "Spices",
                "price": 180.00,
                "quantity": 100,
                "unit": "kg",
                "farmer_name": "Ananya Sharma",
                "farmer_contact": "+91 7654321098",
                "location": "Kerala",
                "image_url": "/static/uploads/seed_turmeric.jpg",
                "description": "Pure organic ground turmeric from high curcumin roots.",
                "created_at": "2026-08-07T14:00:00Z"
            },
            {
                "product_name": "Pure Wild Honey",
                "category": "Others",
                "price": 450.00,
                "quantity": 50,
                "unit": "litres",
                "farmer_name": "Venkatesh Rao",
                "farmer_contact": "+91 6543210987",
                "location": "Andhra Pradesh",
                "image_url": "/static/uploads/seed_honey.jpg",
                "description": "Raw unpasteurized honey collected from forest beehives.",
                "created_at": "2026-08-07T15:00:00Z"
            }
        ]
        col.insert_many(sample_products)
        print("Marketplace collection seeded successfully.")

def seed_workers():
    """Seed workers collection if empty."""
    database = get_db()
    if database is None:
        return
    col = database['workers']
    if col.count_documents({}) == 0:
        sample_workers = [
            {
                "name": "Ramesh Gowda",
                "age": 34,
                "skills": ["Harvesting", "Ploughing", "Sowing"],
                "experience_years": 8,
                "daily_wage": 450.00,
                "phone": "+91 9900881122",
                "state": "Karnataka",
                "availability": "Available",
                "rating": 4.8
            },
            {
                "name": "Amit Sharma",
                "age": 28,
                "skills": ["Pesticide Spraying", "Pruning", "Irrigation Setup"],
                "experience_years": 5,
                "daily_wage": 500.00,
                "phone": "+91 9922334455",
                "state": "Punjab",
                "availability": "Available",
                "rating": 4.5
            },
            {
                "name": "Muthu Velu",
                "age": 42,
                "skills": ["Coconut Climbing", "Tractor Driving", "Harvesting"],
                "experience_years": 15,
                "daily_wage": 600.00,
                "phone": "+91 9844556677",
                "state": "Tamil Nadu",
                "availability": "Busy",
                "rating": 4.9
            },
            {
                "name": "Subodh Patil",
                "age": 31,
                "skills": ["Organic Composting", "Sowing", "Weeding"],
                "experience_years": 6,
                "daily_wage": 400.00,
                "phone": "+91 9123456780",
                "state": "Maharashtra",
                "availability": "Available",
                "rating": 4.2
            }
        ]
        col.insert_many(sample_workers)
        print("Workers collection seeded successfully.")

def seed_schemes():
    """Seed Government Schemes if empty."""
    database = get_db()
    if database is None:
        return
    col = database['schemes']
    if col.count_documents({}) == 0:
        sample_schemes = [
            {
                "scheme_name": "PM Kisan Samman Nidhi (PM-KISAN)",
                "state": "All States",
                "min_land_size": 0,
                "max_land_size": 2, # hectares
                "farmer_category": "Small & Marginal",
                "description": "An initiative by the Government of India that provides up to ₹6,000 per year in three equal installments to small and marginal farmers.",
                "benefits": "₹6,000 per year direct benefit transfer",
                "eligible_crops": "All Crops",
                "apply_link": "https://pmkisan.gov.in"
            },
            {
                "scheme_name": "Pradhan Mantri Fasal Bima Yojana (PMFBY)",
                "state": "All States",
                "min_land_size": 0,
                "max_land_size": 100,
                "farmer_category": "All Categories",
                "description": "A crop insurance scheme that protects farmers against crop loss due to natural calamities, pests, and diseases.",
                "benefits": "Financial support for crop damage with minimal premium rates (1.5% to 2% premium)",
                "eligible_crops": "Rice, Wheat, Pulses, Oilseeds, Commercial crops",
                "apply_link": "https://pmfby.gov.in"
            },
            {
                "scheme_name": "Krishi Bhagya Scheme",
                "state": "Karnataka",
                "min_land_size": 0.5,
                "max_land_size": 5,
                "farmer_category": "All Categories",
                "description": "Securing rainwater through farm ponds and promoting micro-irrigation systems in dryland farming areas in Karnataka.",
                "benefits": "90% subsidy for SC/ST and 80% subsidy for General category farmers for building farm ponds and poly houses.",
                "eligible_crops": "Millets, Pulses, Maize",
                "apply_link": "https://krishibhagya.karnataka.gov.in"
            },
            {
                "scheme_name": "Rythu Bandhu Scheme",
                "state": "Telangana",
                "min_land_size": 0,
                "max_land_size": 50,
                "farmer_category": "All Categories",
                "description": "Investment support scheme for agriculture and horticulture crops. Capital support is provided of ₹5,000 per acre per season.",
                "benefits": "₹10,000 per acre annually for purchasing seeds, fertilizers, and inputs.",
                "eligible_crops": "Paddy, Cotton, Maize, Chilli",
                "apply_link": "http://rythubandhu.telangana.gov.in"
            },
            {
                "scheme_name": "Paramparagat Krishi Vikas Yojana (PKVY)",
                "state": "All States",
                "min_land_size": 0.1,
                "max_land_size": 20,
                "farmer_category": "All Categories",
                "description": "Promotes organic farming through cluster approach and Participatory Guarantee System (PGS) certification.",
                "benefits": "Financial assistance of ₹50,000 per hectare for 3 years, of which 62% is given for organic cultivation components.",
                "eligible_crops": "Organic Fruits, Vegetables, Grains",
                "apply_link": "https://dcfw.gov.in"
            }
        ]
        col.insert_many(sample_schemes)
        print("Government Schemes collection seeded successfully.")

def seed_market_prices():
    """Seed Crop Market Prices collection if empty."""
    database = get_db()
    if database is None:
        return
    col = database['market_prices']
    if col.count_documents({}) == 0:
        sample_prices = [
            {"crop_name": "Paddy (Rice)", "market_name": "Yeshwanthpur (Bengaluru)", "state": "Karnataka", "today_price": 2450.0, "unit": "Quintal", "trend": "Up"},
            {"crop_name": "Wheat", "market_name": "Khanna Market", "state": "Punjab", "today_price": 2275.0, "unit": "Quintal", "trend": "Stable"},
            {"crop_name": "Tomato", "market_name": "Kolar APMC", "state": "Karnataka", "today_price": 1800.0, "unit": "Quintal", "trend": "Down"},
            {"crop_name": "Onion", "market_name": "Lasalgaon APMC", "state": "Maharashtra", "today_price": 2800.0, "unit": "Quintal", "trend": "Up"},
            {"crop_name": "Cotton", "market_name": "Adoni APMC", "state": "Andhra Pradesh", "today_price": 7100.0, "unit": "Quintal", "trend": "Up"},
            {"crop_name": "Chilli (Dry)", "market_name": "Guntur APMC", "state": "Andhra Pradesh", "today_price": 16500.0, "unit": "Quintal", "trend": "Stable"},
            {"crop_name": "Turmeric", "market_name": "Erode APMC", "state": "Tamil Nadu", "today_price": 11200.0, "unit": "Quintal", "trend": "Up"}
        ]
        col.insert_many(sample_prices)
        print("Market prices seeded successfully.")

def seed_notifications():
    """Seed initial notifications if empty."""
    database = get_db()
    if database is None:
        return
    col = database['notifications']
    if col.count_documents({}) == 0:
        sample_notifs = [
            {
                "title": "Severe Rain Alert",
                "message": "Heavy rainfall (+45mm) is predicted in Southern districts over the next 48 hours. Please secure harvested crops and delay pesticide spraying.",
                "category": "weather",
                "unread": True,
                "created_at": "2026-08-07T18:00:00Z"
            },
            {
                "title": "Market Alert: Tomato Prices Increase",
                "message": "Tomato prices in Kolar APMC rose by 12% today due to reduced supply. Good time to sell if your crops are ready.",
                "category": "market",
                "unread": True,
                "created_at": "2026-08-07T16:30:00Z"
            },
            {
                "title": "New Government Scheme Registered",
                "message": "Karnataka Government has opened registrations for Krishi Bhagya Scheme subsidies. Verify your eligibility in the Schemes tab.",
                "category": "scheme",
                "unread": True,
                "created_at": "2026-08-07T10:00:00Z"
            }
        ]
        col.insert_many(sample_notifs)
        print("Notifications seeded successfully.")
