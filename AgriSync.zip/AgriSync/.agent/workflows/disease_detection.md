---
description: How to configure, run, and test the Plant Disease Detection API module in AgriSync
---

# Plant Disease Detection Integration Workflow

This workflow describes the step-by-step procedure to add the real API key, configure the endpoints, launch the Flask server, and test the Plant Disease Detection interface.

## 1. Configure the API Key and URL
API credentials must be stored securely on the backend in the environment configuration file.

1. Open the `.env` file located in the project root:
   - Add your premium/free Plant.id API key to `DISEASE_API_KEY`:
     ```ini
     DISEASE_API_KEY=your_actual_plant_id_api_key_here
     ```
   - Specify the Plant.id Health Assessment endpoint:
     ```ini
     DISEASE_API_URL=https://api.plant.id/v3/health_assessment
     ```
2. For team deployment, ensure that the `.env.example` file contains the corresponding variables without the actual secrets:
   ```ini
   DISEASE_API_KEY=your_api_key_here
   DISEASE_API_URL=https://api.plant.id/v3/health_assessment
   ```

## 2. Start the Backend Server
Make sure the dependencies are installed and startup checks pass.

// turbo
1. Install requirements:
   ```powershell
   pip install -r requirements.txt
   ```

2. Start the Flask application:
   ```powershell
   python app.py
   ```
   The application will start on `http://localhost:5000` (or the port specified in `.env`).

## 3. Test Disease Detection
You can test the module using either the developer verification script or the web UI.

### Option A: Command Line Verification
Run the diagnostic test script which uploads the default leaf graphic to verify the API response structure:
```powershell
python test_disease_API.py
```
Check the output saved in `test_out_utf8.txt` to review the returned fields.

### Option B: Web UI Testing
1. Navigate to `http://localhost:5000` in a web browser.
2. Sign in or register a test account on the mobile auth layout.
3. Select "Plant Disease / Leaf Pathology" from the dashboard tabs.
4. Drag and drop or select a leaf photo (PNG or JPG under 10MB).
5. Click **Diagnose Image**. 
6. Review the generated **Pathology Report**:
   - Leaf/Plant variety classification,
   - Diagnosis result and Confidence rating,
   - Detailed Recommended treatment action (expert fallback displayed if the API has no cure text),
   - List of other potential match suggestions under "Additional Possibilities".
7. Click **Scan Another Leaf** to reset and perform another query.
