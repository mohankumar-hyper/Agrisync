# AgriSense AI 🌾 — Smart Agriculture Platform

A production-ready, full-stack AI-powered Smart Agriculture Web Application built with Python Flask, MongoDB, Scikit-learn, OpenCV, Chart.js, and Leaflet.js.

---

## 🚀 Quick Start

### 1. Prerequisites
- Python 3.10+
- MongoDB running on `localhost:27017`
- (Optional) OpenWeatherMap API key & Google Gemini API key

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Configure Environment
```bash
cp .env.example .env
# Edit .env and add your API keys (optional but recommended)
```

### 4. Run the App
```bash
python app.py
```

Open your browser at: **http://localhost:5000**

---

## 🌟 Features

| Module | Description |
|---|---|
| **Auth** | Register & Login with bcrypt hashed passwords |
| **Weather** | OpenWeatherMap or simulated 5-day forecast |
| **GPS Farm** | Leaflet + OpenStreetMap farm location pinning |
| **Crop Recommend** | Random Forest model on N/P/K/pH/Rain inputs |
| **Disease Detector** | OpenCV HSV color segmentation on leaf photos |
| **Smart Irrigation** | Rule-based water volume & timing advisory |
| **Pest Predictor** | Random Forest pest risk classifier |
| **Yield Forecast** | Random Forest regressor for harvest & profit |
| **Farm Calendar** | Sowing → Fertilize → Irrigate → Harvest timeline |
| **Gov. Schemes** | MongoDB-based subsidy eligibility matching |
| **Worker Booking** | Farm labor directory & contract booking |
| **Marketplace** | Farmer-to-Buyer product listings & inquiries |
| **AI Chatbot** | Google Gemini or local expert knowledge base |
| **Voice Assistant** | Web Speech API — English + 6 Indian languages |
| **Notifications** | Alerts for rain, disease, markets, bookings |

---

## 📁 Project Structure

```
AgriSync/
├── app.py              ← Flask app + blueprint registration
├── config.py           ← Environment config loader
├── database.py         ← MongoDB setup + seed data
├── requirements.txt
├── .env.example
├── models/
│   └── ai_models.py    ← All ML models (Scikit-learn + OpenCV)
├── routes/
│   ├── auth.py
│   ├── weather.py
│   ├── farm.py
│   ├── crop.py
│   ├── disease.py
│   ├── irrigation.py
│   ├── pest.py
│   ├── predictions.py
│   ├── calendar.py
│   ├── schemes.py
│   ├── workers.py
│   ├── marketplace.py
│   ├── notifications.py
│   ├── market_prices.py
│   └── chatbot.py
├── static/
│   ├── css/style.css
│   ├── js/app.js
│   └── uploads/        ← User-uploaded images
└── templates/
    └── index.html
```

---

## 🔑 Environment Variables

Copy `.env.example` to `.env` and set:

```
SECRET_KEY=your_flask_secret_key
MONGO_URI=mongodb://localhost:27017/agrisense_db
OPENWEATHER_API_KEY=your_key       # optional
GEMINI_API_KEY=your_key            # optional (chatbot falls back locally)
```

---

## 🤖 AI Models

All models are **trained at startup** if not already serialized:

- **Crop Recommender** — `scikit-learn RandomForestClassifier` on 500 balanced synthetic soil samples
- **Yield Predictor** — `RandomForestRegressor` for harvest tonnage & profit estimation
- **Pest Classifier** — `RandomForestClassifier` for infestation risk scoring
- **Disease Detector** — `OpenCV HSV Color Segmentation` — real computer vision leaf analysis

> To enable YOLO or TensorFlow, uncomment lines in `requirements.txt` and install them.

---

## 📱 Responsive Design

- ✅ Mobile-first sidebar navigation
- ✅ Dark / Light theme toggle
- ✅ Glassmorphism UI with animated gradients
- ✅ Touch-friendly drag-drop image upload

---

## 🌐 Voice Commands (Examples)

| Language | Command |
|---|---|
| English | "Open Disease Checker" |
| Kannada | "ರೋಗ ತೆರೆಯಿರಿ" |
| Hindi | "फसल अनुशंसा खोलें" |
| Tamil | "சந்தை திற" |
