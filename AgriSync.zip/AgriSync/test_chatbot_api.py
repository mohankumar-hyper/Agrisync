import unittest
import json
from unittest.mock import patch
from app import app

class TestChatbotAPI(unittest.TestCase):
    def setUp(self):
        self.app = app.test_client()
        self.app.testing = True

    def test_chatbot_validation(self):
        payload = {"query": ""}
        response = self.app.post('/api/chatbot', 
                                 data=json.dumps(payload),
                                 content_type='application/json')
        data = json.loads(response.data)
        self.assertEqual(response.status_code, 400)
        self.assertFalse(data['success'])

    def test_chatbot_local_fallback(self):
        # Using a pattern that triggers local fallback even if api key is configured
        # Or disable / mock API key to test local fallback
        with patch('config.Config.GROQ_API_KEY', ''), patch('config.Config.GEMINI_API_KEY', ''):
            payload = {"query": "How is the weather today?"}
            response = self.app.post('/api/chatbot', 
                                     data=json.dumps(payload),
                                     content_type='application/json')
            data = json.loads(response.data)
            self.assertEqual(response.status_code, 200)
            self.assertTrue(data['success'])
            self.assertEqual(data['source'], "AgriSense Local Expert System")
            self.assertIn("Weather", data['response'])

    @patch('requests.post')
    def test_chatbot_groq_integration(self, mock_post):
        # Mock requests.post response
        mock_response = mock_post.return_value
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "choices": [
                {
                    "message": {
                        "content": "To reduce water waste, you should install drip emitters close to crop rootzones."
                    }
                }
            ]
        }
        
        with patch('config.Config.GROQ_API_KEY', 'gsk_testkey_123'):
            payload = {"query": "Tell me about irrigation"}
            response = self.app.post('/api/chatbot', 
                                     data=json.dumps(payload),
                                     content_type='application/json')
            data = json.loads(response.data)
            self.assertEqual(response.status_code, 200)
            self.assertTrue(data['success'])
            self.assertEqual(data['source'], "AgriSense AI (Groq)")
            self.assertIn("drip emitters", data['response'])
            
            # Verify mock called correctly
            mock_post.assert_called_once()
            args, kwargs = mock_post.call_args
            self.assertEqual(args[0], "https://api.groq.com/openai/v1/chat/completions")
            self.assertEqual(kwargs['headers']['Authorization'], "Bearer gsk_testkey_123")

    @patch('requests.post')
    def test_chatbot_learning_groq(self, mock_post):
        mock_response = mock_post.return_value
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "choices": [
                {
                    "message": {
                        "content": "Vermicompost is excellent for organic farming."
                    }
                }
            ]
        }
        
        with patch('config.Config.GROQ_API_KEY', 'gsk_testkey_123'):
            payload = {"query": "Explain organic farming", "lang": "en"}
            response = self.app.post('/api/learning/chat', 
                                     data=json.dumps(payload),
                                     content_type='application/json')
            data = json.loads(response.data)
            self.assertEqual(response.status_code, 200)
            self.assertTrue(data['success'])
            self.assertEqual(data['source'], "AI Learning Engine (Groq)")
            self.assertIn("Vermicompost", data['response'])

    def test_chatbot_crop_local_fallback(self):
        with patch('config.Config.GROQ_API_KEY', ''), patch('config.Config.GEMINI_API_KEY', ''):
            # Test mustard crop query (new crop)
            payload = {"query": "Tell me about mustard"}
            response = self.app.post('/api/chatbot', 
                                     data=json.dumps(payload),
                                     content_type='application/json')
            data = json.loads(response.data)
            self.assertEqual(response.status_code, 200)
            self.assertTrue(data['success'])
            self.assertEqual(data['source'], "AgriSense Local Expert System")
            self.assertIn("Mustard", data['response'])
            self.assertIn("oilseed", data['response'])

            # Test paddy crop query
            payload = {"query": "Tell me about paddy crop"}
            response = self.app.post('/api/chatbot',
                                     data=json.dumps(payload),
                                     content_type='application/json')
            data = json.loads(response.data)
            self.assertEqual(response.status_code, 200)
            self.assertTrue(data['success'])
            self.assertEqual(data['source'], "AgriSense Local Expert System")
            self.assertIn("Rice", data['response'])
            self.assertIn("Kharif", data['response'])

            # Test sugar cane crop query
            payload = {"query": "Tell me about sugar cane"}
            response = self.app.post('/api/chatbot',
                                     data=json.dumps(payload),
                                     content_type='application/json')
            data = json.loads(response.data)
            self.assertEqual(response.status_code, 200)
            self.assertTrue(data['success'])
            self.assertEqual(data['source'], "AgriSense Local Expert System")
            self.assertIn("Sugarcane", data['response'])
            self.assertIn("furrows", data['response'])

    @patch('requests.post')
    def test_chatbot_crop_groq_context_injection(self, mock_post):
        mock_response = mock_post.return_value
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "choices": [
                {
                    "message": {
                        "content": "Turmeric is a high-value spice grown in India, best harvested when leaves dry."
                    }
                }
            ]
        }
        with patch('config.Config.GROQ_API_KEY', 'gsk_testkey_123'):
            payload = {"query": "how to grow turmeric in india"}
            response = self.app.post('/api/chatbot', 
                                     data=json.dumps(payload),
                                     content_type='application/json')
            data = json.loads(response.data)
            self.assertEqual(response.status_code, 200)
            self.assertTrue(data['success'])
            self.assertEqual(data['source'], "AgriSense AI (Groq)")
            
            # Verify system context was modified appropriately to include turmeric local dataset
            args, kwargs = mock_post.call_args
            system_message = kwargs['json']['messages'][0]['content']
            self.assertIn("Turmeric", system_message)
            self.assertIn("rhizomes", system_message)
            self.assertIn("Telangana", system_message)

if __name__ == '__main__':
    unittest.main()

