"""
One-shot cleanup: Remove all marketplace products except Tomato listings.
Run once with: python clear_marketplace.py
"""
from pymongo import MongoClient
import re

client = MongoClient("mongodb://localhost:27017/")
db = client["agrisense_db"]

# Count before
total_before = db.marketplace.count_documents({})
print(f"Total products before cleanup: {total_before}")

# Delete everything that is NOT a tomato (case-insensitive match on product_name OR category)
result = db.marketplace.delete_many({
    "$and": [
        {"product_name": {"$not": re.compile("tomato", re.IGNORECASE)}},
        {"category": {"$not": re.compile("vegetable|tomato", re.IGNORECASE)}}
    ]
})

# Count after
total_after = db.marketplace.count_documents({})
print(f"Deleted {result.deleted_count} non-tomato products.")
print(f"Total products remaining (tomato only): {total_after}")

# Show remaining items
remaining = list(db.marketplace.find({}, {"product_name": 1, "category": 1, "farmer_name": 1}))
for p in remaining:
    print(f"  - {p.get('product_name')} [{p.get('category')}] by {p.get('farmer_name')}")

client.close()
print("Done.")
