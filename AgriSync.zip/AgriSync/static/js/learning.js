/* =====================================================
   AGRICULTURE LEARNING CENTRE FRONTEND LOGIC
   ===================================================== */

"use strict";

let lrnState = {
  currentSubtab: 'dash',
  activeQuizCategory: null,
  quizQuestions: [],
  userQuizAnswers: {},
  bookmarkedVideos: JSON.parse(localStorage.getItem('agri_bookmarks') || '[]'),
  offlineVideos: JSON.parse(localStorage.getItem('agri_offline') || '[]'),
};

/**
 * Entry initializing point for AgriSync Learning Centre
 */
function initLearning() {
  // 1. Setup Subtab Navigation Click Handlers
  document.querySelectorAll('.lrn-nav-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const targetSubtab = btn.dataset.subtab;
      switchLearningSubtab(targetSubtab);
    });
  });

  // 2. Trigger loading data on tab click from sidebar
  const mainTabBtn = document.querySelector('.menu-item[data-tab="learning"]');
  if (mainTabBtn) {
    mainTabBtn.addEventListener('click', () => {
      loadLearningDashboard();
    });
  }

  // 3. Search input controls
  const searchBtn = $('btn-lrn-search');
  if (searchBtn) {
    searchBtn.addEventListener('click', executeLearningSearch);
    $('lrn-search-input').addEventListener('keypress', (e) => {
      if (e.key === 'Enter') executeLearningSearch();
    });
  }

  // 4. Initialize Crop Profile Section menu links
  document.querySelectorAll('.lrn-pmenu-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.lrn-pmenu-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const targetSection = btn.dataset.sect;
      document.querySelectorAll('.lrn-profile-section').forEach(sec => sec.classList.remove('active'));
      const activeSec = $(`lrn-csect-${targetSection}`);
      if (activeSec) activeSec.classList.add('active');
    });
  });

  // Back button in Crop Profile details
  const backCropBtn = $('btn-crop-profile-back');
  if (backCropBtn) {
    backCropBtn.addEventListener('click', () => {
      hide($('lrn-crop-profile-panel'));
      show($('lrn-crops-grid-container'));
    });
  }

  // GM Plants Profile Section sub-tab menu links
  document.querySelectorAll('.lrn-gm-pmenu-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.lrn-gm-pmenu-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const targetSection = btn.dataset.sect;
      document.querySelectorAll('#lrn-gm-profile-panel .lrn-profile-section').forEach(sec => sec.classList.remove('active'));
      const activeSec = $(`lrn-gm-sect-${targetSection}`);
      if (activeSec) activeSec.classList.add('active');
    });
  });

  // Back button in GM Profile details
  const backGmBtn = $('btn-gm-profile-back');
  if (backGmBtn) {
    backGmBtn.addEventListener('click', () => {
      hide($('lrn-gm-profile-panel'));
      show($('lrn-gm-grid-container'));
    });
  }





  // Resume lesson button bound
  const resumeBtn = $('btn-lrn-continue-resume');
  if (resumeBtn) {
    resumeBtn.addEventListener('click', () => {
      switchLearningSubtab('crops');
    });
  }

  // 5. Initial loads
  // If the dashboard is already visible, trigger load immediately
  if ($('panel-learning').classList.contains('active')) {
    loadLearningDashboard();
  }
}

/**
 * Handles subtab switching inside the Learning Centre SPA view
 */
function switchLearningSubtab(subtabKey) {
  lrnState.currentSubtab = subtabKey;

  // Toggle active class on navigation button ribbons
  document.querySelectorAll('.lrn-nav-btn').forEach(btn => {
    if (btn.dataset.subtab === subtabKey) {
      btn.classList.add('active');
    } else {
      btn.classList.remove('active');
    }
  });

  // Toggle active pane display
  document.querySelectorAll('.lrn-subpane').forEach(pane => {
    if (pane.id === `lrn-pane-${subtabKey}`) {
      pane.classList.add('active');
    } else {
      pane.classList.remove('active');
    }
  });

  // Trigger loads based on target subtab
  if (subtabKey === 'crops') {
    loadCropsLibrary();
  } else if (subtabKey === 'guides') {
    loadFarmingGuides();
  } else if (subtabKey === 'images') {
    loadVisualPathology();
  } else if (subtabKey === 'gm') {
    loadGMPlants();
  }
}

/**
 * 1. Fetch Dashboard Stats & Profile Info
 */
async function loadLearningDashboard() {
  const data = await api('/learning/dashboard');
  if (!data.success) {
    console.error('Failed to load learning stats');
    return;
  }

  // Render Stats
  const badgesContainer = $('lrn-stats-badges');
  if (data.badges && data.badges.length > 0) {
    badgesContainer.innerHTML = data.badges.map(b => `
      <div class="lrn-badge-pill" title="Earned on ${b.date}">
        <i class="fa-solid ${b.icon || 'fa-award'}"></i>
        <span>${b.name}</span>
      </div>
    `).join('');
  } else {
    badgesContainer.innerHTML = '<p class="empty-text">No badges earned yet. Take a quiz to certify your skills!</p>';
  }

  // Continue Learning Card
  if (data.continue_learning) {
    $('lrn-continue-title').textContent = data.continue_learning.title;
    $('lrn-continue-next').textContent = `Next Up: ${data.continue_learning.next_lesson}`;
    $('lrn-continue-progress').style.width = `${data.continue_learning.progress_percent}%`;
    const progressSpan = document.querySelector('#lrn-continue-card span');
    if (progressSpan) progressSpan.textContent = `${data.continue_learning.progress_percent}% Complete`;
  }

  // Recommended Content Recommendation list
  const recsBody = $('lrn-recs-list');
  if (data.recommended_videos && data.recommended_videos.length > 0) {
    recsBody.innerHTML = data.recommended_videos.slice(0, 3).map(v => `
      <div class="lrn-mini-item">
        <i class="fa-solid fa-graduation-cap text-green"></i>
        <div style="flex-grow:1;min-width:0">
          <div class="lrn-mini-title">${v.title}</div>
          <div class="lrn-mini-meta">${v.category} — ${v.language} [${v.duration}]</div>
        </div>
        <i class="fa-solid fa-book-open text-muted"></i>
      </div>
    `).join('');
  } else {
    recsBody.innerHTML = '<p class="empty-text">No recommendations. Select a crop of interest in the Crops tab!</p>';
  }
}

/**
 * Render standard video card layout
 */
function renderVideoCardHtml(v) {
  const isBookmarked = lrnState.bookmarkedVideos.includes(v.id);
  const isOffline = lrnState.offlineVideos.includes(v.id);

  return `
    <div class="glass lrn-video-card">
      <div class="video-thumb-container">
        <img src="${v.thumbnail || 'https://img.youtube.com/vi/' + v.youtube_id + '/0.jpg'}" alt="${v.title}">
        <span class="video-duration">${v.duration}</span>
        <div class="video-play-overlay" onclick="playYouTubeVideo('${v.youtube_id}', '${v.title.replace(/'/g, "\\'")}')">
          <i class="fa-solid fa-circle-play"></i>
        </div>
      </div>
      <div class="video-info-body">
        <h4>${v.title}</h4>
        <div class="video-meta-row">
          <span><i class="fa-solid fa-eye"></i> ${v.views} views</span>
          <span><i class="fa-solid fa-language"></i> ${v.language}</span>
        </div>
        <div class="video-actions-row">
          <button class="video-action-btn ${isBookmarked ? 'active' : ''}" onclick="toggleBookmark('${v.id}')">
            <i class="fa-solid fa-bookmark"></i>
            <span>${isBookmarked ? 'Saved' : 'Bookmark'}</span>
          </button>
          <button class="video-action-btn ${isOffline ? 'active' : ''}" onclick="saveVideoOffline('${v.id}')">
            <i class="fa-solid fa-cloud-arrow-down"></i>
            <span>${isOffline ? 'Offline Active' : 'Download'}</span>
          </button>
          <button class="video-action-btn" onclick="shareVideo('${v.youtube_id}', '${v.title.replace(/'/g, "\\'")}')">
            <i class="fa-solid fa-share-nodes"></i>
            <span>Share</span>
          </button>
        </div>
      </div>
    </div>
  `;
}

/**
 * 2. Load Crops Library grid and handle selection logic
 */
async function loadCropsLibrary() {
  const data = await api('/learning/crops');
  if (!data.success) {
    toast('Error fetching supported agronomy crops', 'error');
    return;
  }

  const gridBody = $('lrn-crops-cards-body');
  const cropIcons = {
    rice: 'fa-wheat-awn',
    wheat: 'fa-wheat-awn-circle-exclamation',
    maize: 'fa-seedling',
    cotton: 'fa-broom',
    sugarcane: 'fa-tree',
    tomato: 'fa-apple-whole',
    onion: 'fa-circle-radiation',
    potato: 'fa-cubes',
    chilli: 'fa-pepper-hot',
    groundnut: 'fa-cookie',
    millets: 'fa-wheat-leaf',
    banana: 'fa-lemon',
    mango: 'fa-circle'
  };

  gridBody.innerHTML = data.crops.map(crop => {
    const key = crop.toLowerCase();
    const icon = cropIcons[key] || 'fa-seedling';
    return `
      <div class="glass lrn-crop-card" onclick="exploreCropAgronomy('${key}')">
        <div class="lrn-crop-card-icon"><i class="fa-solid ${icon}"></i></div>
        <h4>${crop}</h4>
        <p>Click to explore complete organic sowing, weeding, fertilizing & yields.</p>
      </div>
    `;
  }).join('');
}

/**
 * Fetch detailed crop agronomy and display section tabs
 */
async function exploreCropAgronomy(cropKey) {
  const data = await api('/learning/crops?crop=' + cropKey);
  if (!data.success) {
    toast('Could not load specific crop agronomy', 'error');
    return;
  }

  const agro = data.agronomy;

  // Set headers
  $('lrn-crop-selected-name').textContent = agro.name;
  $('lrn-crop-selected-season').textContent = agro.season;

  // Set individual sections DOM text fields
  $('prof-overview').textContent = agro.overview;
  $('prof-season').textContent = agro.season;
  $('prof-soil').textContent = agro.soil;
  $('prof-seed').textContent = agro.seed;
  $('prof-prep').textContent = agro.prep;
  $('prof-sowing').textContent = agro.sowing;
  $('prof-irrigation').textContent = agro.irrigation;
  $('prof-fertilizer').textContent = agro.fertilizer;
  $('prof-weed').textContent = agro.weed;
  $('prof-pest').textContent = agro.pest;
  $('prof-harvest').textContent = agro.harvest;
  $('prof-storage').textContent = agro.storage;
  $('prof-yield').textContent = agro.yield;
  $('prof-schemes').textContent = agro.schemes;
  $('prof-profit').textContent = agro.profit;
  const growingRegionsEl = $('prof-growing-regions');
  if (growingRegionsEl) {
    growingRegionsEl.textContent = agro.growing_regions || '-';
  }

  // Render crop profile menu reset
  document.querySelectorAll('.lrn-pmenu-btn').forEach(btn => {
    btn.classList.remove('active');
    if (btn.dataset.sect === 'overview') btn.classList.add('active');
  });
  document.querySelectorAll('.lrn-profile-section').forEach(sec => {
    sec.classList.remove('active');
    if (sec.id === 'lrn-csect-overview') sec.classList.add('active');
  });

  // Toggle views
  hide($('lrn-crops-grid-container'));
  show($('lrn-crop-profile-panel'));
}

/**
 * 3. Video Library rendering and categories filter controls
 */
async function loadVideoLibrary(filterCategory = '', targetSearch = '') {
  // Fetch available videos
  let query = '';
  if (filterCategory) query += `?category=${encodeURIComponent(filterCategory)}`;
  if (targetSearch) query += `${query ? '&' : '?'}search=${encodeURIComponent(targetSearch)}`;

  const data = await api('/learning/videos' + query);
  if (!data.success) {
    toast('Error loading educational video files', 'error');
    return;
  }

  // Load category chips once (17 categories)
  const categories = [
    "Drip Irrigation", "Organic Farming", "Vermicomposting", "Fertigation",
    "Dairy Farming", "Hydroponics", "Mushroom Farming", "Poultry Farming",
    "Soil Health", "Compost Making", "Greenhouse Farming", "Goat Farming",
    "Beekeeping", "Precision Agriculture", "Smart Farming using AI",
    "Government Agriculture Programs", "Natural Farming"
  ];

  const catContainer = $('lrn-video-categories');
  if (catContainer.children.length === 0) {
    catContainer.innerHTML = `<button class="lrn-category-pill active" onclick="filterVideoCategory('')">All Videos</button>` +
      categories.map(c => `<button class="lrn-category-pill text-nowrap" onclick="filterVideoCategory('${c}')" data-cat="${c}">${c}</button>`).join('');
  }

  // Update active pill styling
  document.querySelectorAll('.lrn-category-pill').forEach(pill => {
    if (pill.dataset.cat === filterCategory || (filterCategory === '' && !pill.dataset.cat)) {
      pill.classList.add('active');
    } else {
      pill.classList.remove('active');
    }
  });

  // Populating grid
  const videoGrid = $('lrn-video-cards-container');
  if (data.videos && data.videos.length > 0) {
    videoGrid.innerHTML = data.videos.map(v => renderVideoCardHtml(v)).join('');
  } else {
    videoGrid.innerHTML = '<p class="empty-text">No instructional videos match this filter/search.</p>';
  }
}

function filterVideoCategory(cat) {
  loadVideoLibrary(cat, '');
}

/**
 * YouTube inline watch triggers
 */
function playYouTubeVideo(youtubeId, title) {
  $('lrn-video-modal-title').textContent = title;
  $('lrn-video-iframe').src = `https://www.youtube.com/embed/${youtubeId}?autoplay=1`;
  show($('lrn-video-modal'));
}

/**
 * Bookmarks and offline storage simulated actions
 */
function toggleBookmark(videoId) {
  let bookmarks = lrnState.bookmarkedVideos;
  if (bookmarks.includes(videoId)) {
    bookmarks = bookmarks.filter(id => id !== videoId);
    toast('Removed from bookmarks');
  } else {
    bookmarks.push(videoId);
    toast('Added to bookmarks');
  }
  lrnState.bookmarkedVideos = bookmarks;
  localStorage.setItem('agri_bookmarks', JSON.stringify(bookmarks));

  // Reload current display context
  if (lrnState.currentSubtab === 'videos') {
    const activePill = document.querySelector('.lrn-category-pill.active');
    const activeCat = activePill ? (activePill.dataset.cat || '') : '';
    loadVideoLibrary(activeCat);
  } else {
    loadLearningDashboard();
  }
}

function saveVideoOffline(videoId) {
  let offline = lrnState.offlineVideos;
  if (offline.includes(videoId)) {
    offline = offline.filter(id => id !== videoId);
    toast('Deleted offline file cache');
  } else {
    offline.push(videoId);
    toast('Video saved offline successfully!');
  }
  lrnState.offlineVideos = offline;
  localStorage.setItem('agri_offline', JSON.stringify(offline));

  if (lrnState.currentSubtab === 'videos') {
    const activePill = document.querySelector('.lrn-category-pill.active');
    const activeCat = activePill ? (activePill.dataset.cat || '') : '';
    loadVideoLibrary(activeCat);
  } else {
    loadLearningDashboard();
  }
}

function shareVideo(youtubeId, title) {
  const shareLink = `https://youtu.be/${youtubeId}`;
  if (navigator.clipboard) {
    navigator.clipboard.writeText(shareLink);
    toast('Video share link copied to clipboard!');
  } else {
    toast(`Share Link: ${shareLink}`);
  }
}

/**
 * 4. Step-by-Step Farming guides
 */
async function loadFarmingGuides() {
  const data = await api('/learning/guides');
  if (!data.success) {
    toast('Failed to load step-by-step guides', 'error');
    return;
  }

  const container = $('lrn-guides-container');
  container.innerHTML = data.guides.map(g => {
    return `
      <div class="glass lrn-guide-card" id="guide-${g.id}">
        <h3>${g.title}</h3>
        <div class="guide-step-tracker margin-top-1">
          ${g.steps.map(step => `
            <div class="guide-step-row">
              <div class="guide-step-num">${step.num}</div>
              <div class="guide-step-desc">
                <input type="checkbox" id="chk-g-${g.id}-${step.num}" onchange="updateGuideLessonProgress('${g.id}', ${g.steps.length})" style="margin-right:0.5rem">
                <span>${step.desc}</span>
              </div>
            </div>
          `).join('')}
        </div>
        <div class="lrn-progress-container margin-top-1" style="justify-content:flex-start; gap: 1.5rem">
          <div class="lrn-progress-bar" style="max-width:300px">
            <div class="fill green" id="bar-progress-${g.id}" style="width: 0%"></div>
          </div>
          <span id="txt-progress-${g.id}">Checked: 0 / ${g.steps.length} Steps</span>
        </div>
        <div class="guide-meta-cards margin-top-1">
          <div class="guide-meta-p">
            <strong>Estimated setup duration</strong>
            <span>${g.time}</span>
          </div>
          <div class="guide-meta-p">
            <strong>Required tools & supplies</strong>
            <span>${g.tools}</span>
          </div>
        </div>
        <div class="prof-item margin-top-1" style="background:rgba(16, 185, 129, 0.05)">
          <strong>Expert Agronomist Advice</strong>
          <p style="font-size:0.85rem">${g.tips}</p>
        </div>
        <div class="prof-item margin-top-1" style="background:rgba(239, 68, 68, 0.05); border-color: rgba(239, 68, 68, 0.15)">
          <strong style="color:var(--danger)">Common Mistakes to avoid</strong>
          <p style="font-size:0.85rem; color:var(--text-muted)">${g.mistakes}</p>
        </div>
      </div>
    `;
  }).join('');
}

/**
 * Handle progress tracking checkboxes in Guides
 */
function updateGuideLessonProgress(guideId, totalSteps) {
  let checkedCount = 0;
  for (let i = 1; i <= totalSteps; i++) {
    const chk = document.getElementById(`chk-g-${guideId}-${i}`);
    if (chk && chk.checked) {
      checkedCount++;
    }
  }

  const pct = Math.round((checkedCount / totalSteps) * 100);
  const bar = document.getElementById(`bar-progress-${guideId}`);
  const txt = document.getElementById(`txt-progress-${guideId}`);

  if (bar) bar.style.width = `${pct}%`;
  if (txt) txt.textContent = `Checked: ${checkedCount} / ${totalSteps} Steps (${pct}%)`;

  if (checkedCount === totalSteps) {
    toast(`Congratulations! You completed: ${document.querySelector('#guide-' + guideId + ' h3').textContent}`);
  }
}

/**
 * 5. Interactive Quizzes Logic
 */
async function startQuizSession(category) {
  const data = await api(`/learning/quiz?category=${category}`);
  if (!data.success) {
    toast('Error downloading quiz variables', 'error');
    return;
  }

  lrnState.activeQuizCategory = category;
  lrnState.quizQuestions = data.questions;
  lrnState.userQuizAnswers = {};

  $('lrn-quiz-category-title').textContent = category === 'organic' ? 'Organic & Bio-Agri Techniques' : 'Smart Irrigation & Hydrology';
  $('lrn-quiz-timer').textContent = `Process: Q 1 / ${data.questions.length}`;

  // Populate Questions UI
  const qContainer = $('lrn-quiz-questions-body');
  qContainer.innerHTML = data.questions.map((q, idx) => {
    return `
      <div class="quiz-question-card" id="quiz-qc-${q.id}">
        <h4>Question ${idx + 1}: ${q.q}</h4>
        <div class="quiz-options-group">
          ${q.opt.map((option, optIdx) => `
            <div class="quiz-option-item" id="opt-item-${q.id}-${optIdx}" onclick="selectQuizOption(${q.id}, ${optIdx})">
              ${option}
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }).join('');

  hide($('lrn-quiz-list-panel'));
  show($('lrn-quiz-play-panel'));
}

function selectQuizOption(questionId, optionIndex) {
  // Clear previous selections for this question
  const qObj = lrnState.quizQuestions.find(q => q.id === questionId);
  if (!qObj) return;

  const totalOptions = qObj.opt.length;
  for (let i = 0; i < totalOptions; i++) {
    const el = document.getElementById(`opt-item-${questionId}-${i}`);
    if (el) el.classList.remove('selected');
  }

  // Set active selection
  const target = document.getElementById(`opt-item-${questionId}-${optionIndex}`);
  if (target) target.classList.add('selected');

  // Store in state
  lrnState.userQuizAnswers[questionId] = optionIndex;

  // Update progress tracker text
  const answeredCount = Object.keys(lrnState.userQuizAnswers).length;
  $('lrn-quiz-timer').textContent = `Answered: ${answeredCount} / ${lrnState.quizQuestions.length}`;
}

async function submitActiveQuiz() {
  const answeredCount = Object.keys(lrnState.userQuizAnswers).length;
  const total = lrnState.quizQuestions.length;

  if (answeredCount < total) {
    if (!confirm('You have not selected options for all questions. Do you still want to submit?')) {
      return;
    }
  }

  // Format payload
  const payload = {
    category: lrnState.activeQuizCategory,
    answers: lrnState.userQuizAnswers
  };

  const data = await api('/learning/quiz/submit', {
    method: 'POST',
    body: JSON.stringify(payload)
  });

  if (!data.success) {
    toast('Error checking quiz replies', 'error');
    return;
  }

  // Hide play and display results panels
  hide($('lrn-quiz-play-panel'));
  show($('lrn-quiz-results-panel'));

  // Update results panel metrics
  $('lrn-results-pct').textContent = `Score: ${data.percentage}%`;

  const statusIcon = $('lrn-results-status-icon');
  const statusText = $('lrn-results-status');
  const detailText = $('lrn-results-detail');

  if (data.passed) {
    statusIcon.innerHTML = '<i class="fa-solid fa-trophy text-orange fa-bounce"></i>';
    statusText.innerHTML = `Congratulations! You Passed!`;
    detailText.textContent = data.badge_awarded ?
      `You unlocked the certified "${data.badge_awarded}" verified farming badge!` :
      `You cleared the baseline. Excellent performance!`;
    toast('Passed! Badge gained.', 'success');
  } else {
    statusIcon.innerHTML = '<i class="fa-solid fa-circle-xmark text-red"></i>';
    statusText.textContent = 'Did not clear target threshold (70%)';
    detailText.textContent = 'Review correct explanations below and try again to unlock the award badge!';
  }

  // Answers reviews rendering
  const reviewBody = $('lrn-results-review-body');
  reviewBody.innerHTML = data.results.map((r, idx) => {
    const isCorrect = r.correct;
    return `
      <div class="review-item margin-top-1">
        <strong>Q ${idx + 1}: ${r.question}</strong>
        <p style="margin-top:0.25rem">
          Your Answer: <span style="font-weight:700; color:${isCorrect ? 'var(--primary)' : 'var(--danger)'}">${r.user_answer || 'Skipped'}</span>
          ${!isCorrect ? ` | Correct: <span style="font-weight:700; color:var(--primary)">${r.correct_answer}</span>` : ''}
        </p>
        <p style="font-size:0.8rem; color:var(--text-muted); margin-top:0.25rem">
          <i class="fa-solid fa-lightbulb text-orange"></i> Explanation: ${r.explanation}
        </p>
      </div>
    `;
  }).join('');
}

/**
 * 6. Visual Pathology Zoom & Comparison Slider
 */
async function loadVisualPathology() {
  const data = await api('/learning/images');
  if (!data.success) {
    toast('Error loading image comparisons', 'error');
    return;
  }

  const container = $('lrn-images-container');
  container.innerHTML = data.images.map(img => {
    return `
      <div class="glass lrn-image-compare-box" id="vc-${img.id}">
        <h3>${img.title}</h3>
        <p class="prof-desc" style="margin-top:0.35rem">${img.desc}</p>
        
        <div class="lrn-images-dual-frame margin-top-1">
          <!-- Healthy -->
          <div class="comp-viewer">
            <div class="comp-img-wrapper">
              <img id="img-h-${img.id}" src="${img.healthy_img}" alt="Healthy state">
              <span class="comp-badge healthy">Healthy State</span>
            </div>
            <div class="img-zoom-bar">
              <span>Zoom</span>
              <input type="range" min="1" max="2.5" step="0.1" value="1" oninput="adjustPathologyImageZoom('img-h-${img.id}', this.value)">
            </div>
          </div>

          <!-- Diseased / Deficiency -->
          <div class="comp-viewer">
            <div class="comp-img-wrapper">
              <img id="img-d-${img.id}" src="${img.diseased_img}" alt="Diseased state">
              <span class="comp-badge diseased">Infection State</span>
            </div>
            <div class="img-zoom-bar">
              <span>Zoom</span>
              <input type="range" min="1" max="2.5" step="0.1" value="1" oninput="adjustPathologyImageZoom('img-d-${img.id}', this.value)">
            </div>
          </div>
        </div>

        <div class="indicators-check-list">
          <h5>Key Visual Diagnosis Indicators:</h5>
          <div>
            ${img.indicators.map(ind => `<span class="ind-pill"><i class="fa-solid fa-circle-check text-green"></i> ${ind}</span>`).join('')}
          </div>
        </div>
      </div>
    `;
  }).join('');
}

function adjustPathologyImageZoom(imgId, scaleVal) {
  const imgEL = document.getElementById(imgId);
  if (imgEL) {
    imgEL.style.transform = `scale(${scaleVal})`;
  }
}

/**
 * 7. Download Centre Documents Fetch
 */
async function loadDownloadCentre() {
  const data = await api('/learning/downloads');
  if (!data.success) {
    toast('Error loading downloadable documents', 'error');
    return;
  }

  const listBody = $('lrn-downloads-list-body');
  listBody.innerHTML = data.downloads.map(doc => {
    return `
      <div class="glass lrn-download-doc-card">
        <div class="doc-dl-icon"><i class="fa-solid fa-file-pdf"></i></div>
        <div class="doc-info">
          <h4>${doc.title}</h4>
          <span>Format: ${doc.type} (${doc.size})</span>
        </div>
        <a href="${doc.link}" download class="doc-dl-btn" title="Download Offline Copy">
          <i class="fa-solid fa-angles-down"></i>
        </a>
      </div>
    `;
  }).join('');
}

/**
 * 8. AI Learning Tutor Assistant Integration
 */
async function sendTutorQuery() {
  const input = $('lrn-tutor-input');
  const queryText = input.value.trim();
  if (!queryText) return;

  // Clear inputs
  input.value = '';

  const log = $('lrn-tutor-chat-log');
  // Append User message
  log.innerHTML += `
    <div class="t-msg user">
      <div class="msg-bubble">${queryText.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')}</div>
    </div>
  `;
  log.scrollTop = log.scrollHeight;

  // Append Thinking Indicator
  const typingId = `tutor-typing-${Date.now()}`;
  log.innerHTML += `
    <div class="t-msg bot" id="${typingId}">
      <div class="msg-bubble" style="color:var(--text-muted)">
        <i class="fa-solid fa-ellipsis fa-beat"></i> Consulting Agronomy manuals...
      </div>
    </div>
  `;
  log.scrollTop = log.scrollHeight;

  const targetLang = $('lrn-tutor-lang').value;
  const payload = {
    query: queryText,
    lang: targetLang
  };

  const data = await api('/learning/chat', {
    method: 'POST',
    body: JSON.stringify(payload)
  });

  // Remove thinking bubble
  const typingEl = document.getElementById(typingId);
  if (typingEl) typingEl.remove();

  const reply = data.success ? data.response : 'I apologize, my AI scheduler returned an processing error. Please try again.';

  // Format response formatting (support simple newlines and bold indicators)
  const formattedHtml = reply
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    .replace(/\n/g, '<br>');

  log.innerHTML += `
    <div class="t-msg bot">
      <div class="msg-bubble">${formattedHtml}</div>
    </div>
  `;
  log.scrollTop = log.scrollHeight;
}

/**
 * Executes a holistic Search from the Dashboard Search controls
 */
function executeLearningSearch() {
  const query = $('lrn-search-input').value.trim().toLowerCase();
  const filterCrop = $('lrn-filter-crop').value;

  if (query.includes('disease') || query.includes('blast') || query.includes('blight') || query.includes('symptom')) {
    switchLearningSubtab('images');
  } else if (query.includes('guide') || query.includes('vermicompost') || query.includes('drip setup')) {
    switchLearningSubtab('guides');
  } else if (query.includes('gm') || query.includes('genetically') || query.includes('bt cotton')) {
    switchLearningSubtab('gm');
  } else {
    // default: filter crops agronomy
    switchLearningSubtab('crops');
    if (query) {
      exploreCropAgronomy(query);
    }
  }
}

/**
 * 9. Genetically Modified (GM) Plants Section
 */
async function loadGMPlants() {
  const data = await api('/learning/gm');
  if (!data.success) {
    toast('Error loading GM Plants dataset', 'error');
    return;
  }

  const gridBody = $('lrn-gm-cards-body');
  if (!gridBody) return;

  gridBody.innerHTML = data.plants.map(p => {
    const icon = p.icon || 'fa-dna';
    let badgeClass = 'tag-green';
    if (p.status_badge.includes('Import') || p.status_badge.includes('Review')) {
      badgeClass = 'tag-yellow';
    } else if (p.status_badge.includes('Moratorium') || p.status_badge.includes('Discontinued')) {
      badgeClass = 'tag-red';
    }

    return `
      <div class="glass lrn-crop-card" onclick="exploreGMPlant('${p.id}')" style="cursor: pointer;">
        <div class="lrn-crop-card-icon" style="background: rgba(16, 185, 129, 0.1); color: var(--primary);"><i class="fa-solid ${icon}"></i></div>
        <h4 style="margin-top: 0.75rem; font-size: 1.1rem;">${p.name}</h4>
        <div class="market-tag ${badgeClass}" style="display: inline-block; margin: 0.5rem 0; font-size: 0.75rem;">${p.status_badge}</div>
        <p style="font-size: 0.85rem; color: var(--text-muted); line-height: 1.4;">${p.what_is_gm.substring(0, 110)}...</p>
        <span class="text-green" style="font-size: 0.85rem; font-weight: 600; display: inline-block; margin-top: 0.75rem;">Explore Profile <i class="fa-solid fa-arrow-right"></i></span>
      </div>
    `;
  }).join('');
}

async function exploreGMPlant(plantId) {
  const data = await api(`/learning/gm?plant=${plantId}`);
  if (!data.success) {
    toast('Could not load GM plant profile details', 'error');
    return;
  }

  const p = data.plant;

  // Set headers
  $('lrn-gm-selected-name').textContent = p.name;

  const statusBadge = $('lrn-gm-selected-badge');
  statusBadge.textContent = p.status_badge;
  statusBadge.className = 'market-tag'; // reset
  if (p.status_badge.includes('Import') || p.status_badge.includes('Review')) {
    statusBadge.classList.add('tag-yellow');
  } else if (p.status_badge.includes('Moratorium') || p.status_badge.includes('Discontinued')) {
    statusBadge.classList.add('tag-red');
  } else {
    statusBadge.classList.add('tag-green');
  }

  // Set fields
  $('gm-prof-overview').textContent = p.what_is_gm;
  $('gm-prof-developer').textContent = p.developer;
  $('gm-prof-year').textContent = p.approval_year;

  $('gm-prof-method').textContent = p.modification_method;
  $('gm-prof-genes').textContent = p.genes_inserted;
  $('gm-prof-traits').textContent = p.traits_added;
  $('gm-prof-explanation').textContent = p.genetic_modification;

  $('gm-prof-regions').textContent = p.growing_regions;
  $('gm-prof-climate').textContent = p.climate;
  $('gm-prof-soil').textContent = p.soil;

  // Benefits & Concerns lists
  $('gm-prof-benefits').innerHTML = p.benefits.map(b => `<li style="margin-bottom: 0.4rem;">${b}</li>`).join('');
  $('gm-prof-concerns').innerHTML = p.concerns.map(c => `<li style="margin-bottom: 0.4rem;">${c}</li>`).join('');

  $('gm-prof-regulations').textContent = p.regulatory_status;

  // Reset tab menu inside GM profile panel
  document.querySelectorAll('.lrn-gm-pmenu-btn').forEach(btn => {
    btn.classList.remove('active');
    if (btn.dataset.sect === 'gm-overview') btn.classList.add('active');
  });

  document.querySelectorAll('#lrn-gm-profile-panel .lrn-profile-section').forEach(sec => {
    sec.classList.remove('active');
    if (sec.id === 'lrn-gm-sect-gm-overview') sec.classList.add('active');
  });

  // Toggle views
  hide($('lrn-gm-grid-container'));
  show($('lrn-gm-profile-panel'));
}

