/* =====================================================
   AgriSense AI — Full Single-Page App JavaScript
   ===================================================== */

"use strict";

/* ── GLOBAL STATE ── */
const state = {
  currentUser: null,
  farmLat: 12.9716,
  farmLon: 77.5946,
  farmMarker: null,
  leafletMap: null,
  marketChart: null,
  selectedWorker: null,
};

/* ── DOM HELPERS ── */
const $ = (id) => document.getElementById(id);
const show = (el) => el && el.classList.remove('hidden');
const hide = (el) => el && el.classList.add('hidden');
const fmt = (n) => new Intl.NumberFormat('en-IN').format(Math.round(n));

/* ── API BASE ── */
async function api(path, opts = {}) {
  const res = await fetch('/api' + path, {
    headers: { 'Content-Type': 'application/json', ...opts.headers },
    credentials: 'same-origin',
    ...opts,
  });
  return res.json();
}

/* ── TOAST NOTIFICATION ── */
function toast(msg, type = 'success') {
  const t = document.createElement('div');
  t.className = `toast toast-${type}`;
  t.innerHTML = `<i class="fa-solid ${type === 'success' ? 'fa-circle-check' : 'fa-circle-exclamation'}"></i> ${msg}`;
  document.body.appendChild(t);
  setTimeout(() => t.classList.add('show'), 50);
  setTimeout(() => { t.classList.remove('show'); setTimeout(() => t.remove(), 400); }, 3500);
}

/* Dynamically inject toast styles once */
(function injectToastCSS() {
  const s = document.createElement('style');
  s.textContent = `
    .toast{position:fixed;bottom:80px;left:50%;transform:translateX(-50%) translateY(30px);
      background:rgba(18,28,24,.95);color:#f3f4f6;padding:.75rem 1.5rem;border-radius:12px;
      font-size:.875rem;font-weight:600;opacity:0;transition:opacity .35s,transform .35s;
      display:flex;align-items:center;gap:.5rem;z-index:9999;border:1px solid rgba(255,255,255,.08);}
    .toast.show{opacity:1;transform:translateX(-50%) translateY(0);}
    .toast-success i{color:#10b981;}
    .toast-error i{color:#ef4444;}
  `;
  document.head.appendChild(s);
})();

/* =====================================================
   AUTH
   ===================================================== */
/* =====================================================
   AUTH SECTION REDESIGN
   ===================================================== */
window.togglePasswordVisibility = function (inputId, btnEl) {
  const input = document.getElementById(inputId);
  if (!input) return;
  const isPass = input.type === 'password';
  input.type = isPass ? 'text' : 'password';
  const icon = btnEl.querySelector('i');
  if (icon) {
    icon.className = isPass ? 'fa-solid fa-eye-slash attr-toggle-active' : 'fa-solid fa-eye';
  }
};

function triggerCardShake() {
  const card = document.querySelector('.auth-card');
  if (card) {
    card.classList.add('shake-anim');
    setTimeout(() => card.classList.remove('shake-anim'), 600);
  }
}

function triggerSuccessAnim(callback) {
  const card = document.querySelector('.auth-card');
  if (card) {
    card.classList.add('success-scale-anim');
    const overlay = document.createElement('div');
    overlay.className = 'auth-success-overlay';
    overlay.innerHTML = '<div class="success-icon-circle"><i class="fa-solid fa-circle-check"></i></div>';
    card.appendChild(overlay);
    setTimeout(() => {
      callback();
      overlay.remove();
      card.classList.remove('success-scale-anim');
    }, 1200);
  } else {
    callback();
  }
}

function validateAuthForm(formId) {
  const isLogin = formId === 'login-form';
  const prefix = isLogin ? 'login' : 'reg';

  const mobileInput = $(`${prefix}-mobile`);
  const usernameInput = $(`${prefix}-username`);
  const passwordInput = $(`${prefix}-password`);

  const mobileErr = $(`err-${prefix}-mobile`);
  const usernameErr = $(`err-${prefix}-username`);
  const passwordErr = $(`err-${prefix}-password`);

  let isValid = true;

  // Reset previous errors
  [mobileErr, usernameErr, passwordErr].forEach(el => {
    if (el) {
      el.classList.remove('show');
      el.style.maxHeight = '0px';
    }
  });
  [mobileInput, usernameInput, passwordInput].forEach(el => {
    if (el) el.closest('.input-group').classList.remove('input-error');
  });

  // Mobile Validation: 7 to 15 digits
  // On Login: mobile is OPTIONAL — only validate if the user typed something
  const mobileVal = mobileInput ? mobileInput.value.trim() : '';
  const mobileRegex = /^\d{7,15}$/;
  const mobileRequired = !isLogin; // required only on registration
  if (mobileRequired && !mobileRegex.test(mobileVal)) {
    isValid = false;
    showInputError(mobileInput, mobileErr);
  } else if (!mobileRequired && mobileVal !== '' && !mobileRegex.test(mobileVal)) {
    // Login: validate format only if something was typed
    isValid = false;
    showInputError(mobileInput, mobileErr);
  }

  // Username Validation
  const usernameVal = usernameInput ? usernameInput.value.trim() : '';
  if (usernameVal.length === 0) {
    isValid = false;
    showInputError(usernameInput, usernameErr);
  }

  // Password Validation
  const passwordVal = passwordInput ? passwordInput.value : '';
  if (passwordVal.length < 8) {
    isValid = false;
    showInputError(passwordInput, passwordErr);
  }

  if (!isValid) {
    triggerCardShake();
  }
  return isValid;
}

function showInputError(inputEl, errorEl) {
  if (inputEl) {
    inputEl.closest('.input-group').classList.add('input-error');
  }
  if (errorEl) {
    errorEl.classList.add('show');
    errorEl.style.maxHeight = '32px';
  }
}

function initAuth() {
  $('login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!validateAuthForm('login-form')) return;

    const btn = e.target.querySelector('.btn-text');
    const ldr = e.target.querySelector('.btn-loader');
    btn && hide(btn); ldr && show(ldr);

    const cc = $('login-country-code').value;
    const mob = $('login-mobile').value.trim();
    const fullMobile = cc + mob;

    const data = await api('/auth/login', {
      method: 'POST',
      body: JSON.stringify({
        mobile: fullMobile,
        username: $('login-username').value.trim(),
        password: $('login-password').value,
      }),
    });

    btn && show(btn); ldr && hide(ldr);

    if (data.success) {
      state.currentUser = data.user;
      triggerSuccessAnim(() => {
        showDashboard();
      });
    } else {
      triggerCardShake();
      toast(data.message || 'Login failed', 'error');
    }
  });

  $('register-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!validateAuthForm('register-form')) return;

    const btn = e.target.querySelector('.btn-text');
    const ldr = e.target.querySelector('.btn-loader');
    btn && hide(btn); ldr && show(ldr);

    const cc = $('reg-country-code').value;
    const mob = $('reg-mobile').value.trim();
    const fullMobile = cc + mob;

    const data = await api('/auth/register', {
      method: 'POST',
      body: JSON.stringify({
        username: $('reg-username').value.trim(),
        mobile: fullMobile,
        password: $('reg-password').value,
      }),
    });

    btn && show(btn); ldr && hide(ldr);

    if (data.success) {
      triggerSuccessAnim(() => {
        toast('Registered! Please sign in.');
        toggleAuthForms('login');
      });
    } else {
      triggerCardShake();
      toast(data.message || 'Registration failed', 'error');
    }
  });

  $('to-register').addEventListener('click', (e) => { e.preventDefault(); toggleAuthForms('register'); });
  $('to-login').addEventListener('click', (e) => { e.preventDefault(); toggleAuthForms('login'); });

  $('btn-logout').addEventListener('click', async () => {
    await api('/auth/logout', { method: 'POST' });
    state.currentUser = null;
    hide($('app-container'));
    show($('auth-container'));
    toggleAuthForms('login');
    toast('Logged out successfully');
  });

  // Adding visual focus handlers to inputs
  document.querySelectorAll('.auth-input').forEach(input => {
    const group = input.closest('.input-group');
    input.addEventListener('focus', () => group.classList.add('focused'));
    input.addEventListener('blur', () => group.classList.remove('focused'));
  });
}

function toggleAuthForms(which) {
  // Clear any existing validation states/errors
  document.querySelectorAll('.error-msg-pop').forEach(el => {
    el.classList.remove('show');
    el.style.maxHeight = '0px';
  });
  document.querySelectorAll('.input-group').forEach(el => {
    el.classList.remove('input-error');
  });

  if (which === 'register') {
    hide($('login-form')); show($('register-form'));
  } else {
    hide($('register-form')); show($('login-form'));
  }
}

async function checkSession() {
  const data = await api('/auth/current_user');
  if (data.logged_in) {
    state.currentUser = data.user;
    showDashboard();
  } else {
    hide($('app-loader'));
    show($('auth-container'));
  }
}

function showDashboard() {
  hide($('auth-container'));
  hide($('app-loader'));
  show($('app-container'));
  $('user-display-name').textContent = state.currentUser.username || 'Farmer Vikas';
  $('user-display-email').textContent = state.currentUser.email || '';
  setTimeout(() => {
    initMap();
    loadMarketPrices();
    loadNotifications();
    loadMarketplace();
    loadWorkers();
    setDefaultCalendarDate();
    // Auto-detect GPS for accurate weather & map pin on login
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const lat = pos.coords.latitude;
          const lon = pos.coords.longitude;
          state.farmLat = lat;
          state.farmLon = lon;
          if (state.leafletMap && state.farmMarker) {
            state.leafletMap.setView([lat, lon], 14);
            state.farmMarker.setLatLng([lat, lon]);
          }
          const latEl = $('val-lat');
          const lonEl = $('val-lon');
          if (latEl) latEl.textContent = lat.toFixed(5);
          if (lonEl) lonEl.textContent = lon.toFixed(5);
          loadWeather(lat, lon);
        },
        () => loadWeather(),   // fallback: no GPS, use backend default
        { timeout: 8000, maximumAge: 60000 }
      );
    } else {
      loadWeather();
    }
  }, 200);
}

/* =====================================================
   SIDEBAR / TAB NAVIGATION  
   ===================================================== */
function initNavigation() {
  const pageTitles = {
    dashboard: 'Farmer Dashboard',
    crop: 'AI Crop Recommender',
    disease: 'Plant Disease Detection',
    irrigation: 'Smart Irrigation Planner',
    pest: 'Pest Risk Predictor',
    yield: 'Yield & Profit Forecast',
    calendar: 'Farm Operations Diary',
    schemes: 'Government Scheme Finder',
    workers: 'Farm Labor Booking',
    marketplace: 'Farmer Exchange Marketplace',
    learning: 'Agriculture Learning Centre',
  };

  document.querySelectorAll('.menu-item').forEach((link) => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const tab = link.dataset.tab;
      document.querySelectorAll('.menu-item').forEach((l) => l.classList.remove('active'));
      link.classList.add('active');
      document.querySelectorAll('.tab-panel').forEach((p) => p.classList.remove('active'));
      const panel = $(`panel-${tab}`);
      if (panel) panel.classList.add('active');
      $('page-title').textContent = pageTitles[tab] || tab;
      // Collapse sidebar on mobile
      if (window.innerWidth <= 768) document.querySelector('.sidebar').classList.remove('active');
    });
  });

  $('sidebar-toggle').addEventListener('click', () => {
    document.querySelector('.sidebar').classList.toggle('active');
  });
}

/* =====================================================
   THEME TOGGLE
   ===================================================== */
function initTheme() {
  const btn = $('theme-toggle');
  btn.addEventListener('click', () => {
    const html = document.documentElement;
    const isDark = html.getAttribute('data-theme') === 'dark';
    html.setAttribute('data-theme', isDark ? 'light' : 'dark');
    btn.querySelector('i').className = isDark ? 'fa-solid fa-sun' : 'fa-solid fa-moon';
  });
}

/* =====================================================
   LEAFLET MAP
   ===================================================== */
function initMap() {
  if (state.leafletMap) return;

  state.leafletMap = L.map('farm-map').setView([state.farmLat, state.farmLon], 13);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors',
  }).addTo(state.leafletMap);

  const greenIcon = L.divIcon({
    className: '',
    html: `<div style="background:#10b981;width:18px;height:18px;border-radius:50%;border:3px solid #fff;box-shadow:0 0 8px rgba(16,185,129,.6)"></div>`,
    iconSize: [18, 18],
    iconAnchor: [9, 9],
  });

  state.farmMarker = L.marker([state.farmLat, state.farmLon], { draggable: true, icon: greenIcon })
    .addTo(state.leafletMap)
    .bindPopup('📍 Your Farm Location')
    .openPopup();

  state.farmMarker.on('dragend', (e) => {
    const { lat, lng } = e.target.getLatLng();
    state.farmLat = lat;
    state.farmLon = lng;
    $('val-lat').textContent = lat.toFixed(5);
    $('val-lon').textContent = lng.toFixed(5);
  });

  // Update map pin from GPS — weather is loaded by showDashboard's GPS handler
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition((pos) => {
      const { latitude, longitude } = pos.coords;
      state.farmLat = latitude;
      state.farmLon = longitude;
      state.leafletMap.setView([latitude, longitude], 14);
      state.farmMarker.setLatLng([latitude, longitude]);
      $('val-lat').textContent = latitude.toFixed(5);
      $('val-lon').textContent = longitude.toFixed(5);
    }, () => { });
  }

  $('btn-save-gps').addEventListener('click', async () => {
    const data = await api('/farm', {
      method: 'POST',
      body: JSON.stringify({ latitude: state.farmLat, longitude: state.farmLon, farm_name: 'My AgriSense Farm' }),
    });
    if (data.success) toast('Farm GPS location saved!');
    else toast(data.message || 'Failed to save', 'error');
  });
}

/* =====================================================
   WEATHER
   ===================================================== */
async function loadWeather(lat, lon) {
  const params = lat && lon ? `?lat=${lat}&lon=${lon}` : '';
  const data = await api(`/weather${params}`);
  if (data.success) {
    const w = data.data;
    $('dash-weather-city').textContent = w.city;
    $('dash-weather-temp').textContent = `${w.temperature}°C`;
    $('dash-weather-desc').textContent = w.description;
    $('dash-weather-hum').textContent = `${w.humidity}%`;
    $('dash-weather-wind').textContent = `${w.wind_speed} km/h`;
    $('dash-weather-rain').textContent = w.rain_prediction;
    $('dash-weather-icon').src = `https://openweathermap.org/img/wn/${w.icon}@2x.png`;

    // Smart Agriculture Integration: Autofill inputs with live data
    if ($('soil-temp')) $('soil-temp').value = w.temperature;
    if ($('soil-hum')) $('soil-hum').value = w.humidity;
    if ($('irr-temp')) $('irr-temp').value = w.temperature;
    if ($('pest-temp')) $('pest-temp').value = w.temperature;
    if ($('pest-hum')) $('pest-hum').value = w.humidity;
    if ($('irr-weather')) {
      const cond = (w.condition || '').toLowerCase();
      if (cond.includes('thunderstorm')) {
        $('irr-weather').value = 'Thunderstorm';
      } else if (cond.includes('rain') || cond.includes('drizzle')) {
        $('irr-weather').value = 'Rainy';
      } else if (cond.includes('cloud') || cond.includes('mist') || cond.includes('fog') || cond.includes('haze')) {
        $('irr-weather').value = 'Cloudy';
      } else {
        $('irr-weather').value = 'Sunny';
      }
    }
  }
}

/* =====================================================
   MARKET PRICES + INTERACTIVE CHART.JS
   ===================================================== */
let _mandiAllPrices = [];   // master list from backend
let _mandiChartType = 'bar';
let _mandiFilter = 'all';

async function loadMarketPrices() {
  const data = await api('/market-prices');
  if (!data.success) return;
  _mandiAllPrices = data.prices;

  const listEl = $('dash-price-list');
  listEl.innerHTML = '';
  data.prices.forEach((p) => {
    const trendCls = p.trend === 'Up' ? 'up' : p.trend === 'Down' ? 'down' : 'stable';
    const trendIcon = p.trend === 'Up' ? '▲' : p.trend === 'Down' ? '▼' : '—';
    listEl.innerHTML += `
      <div class="price-strip-item">
        <div class="strip-crop">
          <h4>${p.crop_name}</h4><span>${p.market_name}</span>
        </div>
        <div class="strip-val">
          <h4>₹${fmt(p.today_price)}<small>/Q</small></h4>
          <span class="${trendCls}">${trendIcon} ${p.trend}</span>
        </div>
      </div>`;
  });

  // Wire filter chips
  document.querySelectorAll('.mandi-chip').forEach((btn) => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.mandi-chip').forEach((b) => {
        b.style.background = 'rgba(255,255,255,0.05)';
        b.style.color = '#9ca3af';
      });
      btn.style.background = 'rgba(16,185,129,0.25)';
      btn.style.color = '#10b981';
      _mandiFilter = btn.dataset.filter;
      drawMandiChart();
    });
  });

  // Wire chart-type toggle
  document.querySelectorAll('.chart-ctrl-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.chart-ctrl-btn').forEach((b) => {
        b.style.background = 'transparent';
        b.style.color = '#9ca3af';
      });
      btn.style.background = 'rgba(59,130,246,0.3)';
      btn.style.color = '#3b82f6';
      _mandiChartType = btn.dataset.type;
      drawMandiChart();
    });
  });

  drawMandiChart();
}

function drawMandiChart() {
  const ctx = $('marketChart');
  const noDataEl = $('mandi-no-data');
  if (!ctx) return;

  // Apply filter
  let prices = _mandiAllPrices;
  if (_mandiFilter === 'up') prices = prices.filter((p) => p.trend === 'Up');
  if (_mandiFilter === 'down') prices = prices.filter((p) => p.trend === 'Down');

  if (prices.length === 0) {
    ctx.style.display = 'none';
    show(noDataEl);
    return;
  }
  ctx.style.display = 'block';
  hide(noDataEl);

  const COLORS = ['#10b981', '#3b82f6', '#f97316', '#8b5cf6', '#ec4899', '#eab308', '#06b6d4'];
  const bgColors = prices.map((_, i) => COLORS[i % COLORS.length] + 'cc');
  const borderColors = prices.map((_, i) => COLORS[i % COLORS.length]);

  if (state.marketChart) state.marketChart.destroy();
  state.marketChart = new Chart(ctx, {
    type: _mandiChartType,
    data: {
      labels: prices.map((p) => p.crop_name.split(' ')[0]),
      datasets: [{
        label: '₹ / Quintal',
        data: prices.map((p) => p.today_price),
        backgroundColor: _mandiChartType === 'line' ? 'rgba(59,130,246,0.15)' : bgColors,
        borderColor: _mandiChartType === 'line' ? '#3b82f6' : borderColors,
        borderWidth: _mandiChartType === 'line' ? 2 : 1,
        borderRadius: _mandiChartType === 'bar' ? 8 : 0,
        borderSkipped: false,
        fill: _mandiChartType === 'line',
        tension: 0.4,
        pointBackgroundColor: borderColors,
        pointRadius: _mandiChartType === 'line' ? 5 : 0,
        pointHoverRadius: 7,
      }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: { duration: 600, easing: 'easeOutQuart' },
      plugins: {
        legend: { display: false },
        tooltip: {
          enabled: true,
          callbacks: {
            title: (items) => {
              const p = prices[items[0].dataIndex];
              return p ? p.crop_name : items[0].label;
            },
            label: (item) => {
              const p = prices[item.dataIndex];
              return [`  ₹${fmt(item.raw)} / Quintal`, `  Market: ${p.market_name}`, `  Trend: ${p.trend}`];
            },
          },
        },
      },
      onHover: (evt, elements) => {
        if (elements && elements.length > 0) {
          const idx = elements[0].index;
          const p = prices[idx];
          $('mandi-hover-crop').textContent = p.crop_name;
          $('mandi-hover-price').textContent = fmt(p.today_price);
          $('mandi-hover-trend').textContent = p.trend;
          $('mandi-hover-market').textContent = p.market_name;
          show($('mandi-hover-info'));
        } else {
          hide($('mandi-hover-info'));
        }
      },
      onClick: (evt, elements) => {
        if (elements && elements.length > 0) {
          const p = prices[elements[0].index];
          toast(`${p.crop_name}: ₹${fmt(p.today_price)}/Quintal — ${p.trend} — ${p.market_name}`);
        }
      },
      scales: {
        x: { grid: { display: false }, ticks: { color: '#9ca3af', font: { size: 11 } } },
        y: {
          grid: { color: 'rgba(255,255,255,0.04)' },
          ticks: {
            color: '#9ca3af', font: { size: 11 },
            callback: (v) => '₹' + new Intl.NumberFormat('en-IN').format(v)
          },
        },
      },
    },
  });
}

/* =====================================================
   DASHBOARD SMART CROP CARD
   ===================================================== */
function initDashboardCropCard() {
  const btn = $('btn-dash-crop-detect');
  if (!btn) return;

  async function runSmartCropRecommend(lat, lon) {
    // Step 1: fetch weather to get live temp & humidity
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Fetching weather…';
    let temp = 27, humidity = 70, rainfall = 120;

    try {
      const wxData = await api(`/weather?lat=${lat}&lon=${lon}`);
      if (wxData.success && wxData.data) {
        temp = wxData.data.temperature || temp;
        humidity = wxData.data.humidity || humidity;
        rainfall = wxData.data.rain_prediction === 'High' ? 200
          : wxData.data.rain_prediction === 'Medium' ? 120 : 60;
      }
    } catch (_) { /* use defaults */ }

    // Step 2: region-typical soil defaults (Karnataka/South India default)
    // These are sensible mid-range values — user can fine-tune in the full Crop tab
    const payload = {
      N: 80, P: 40, K: 35,
      temperature: temp,
      humidity: humidity,
      ph: 6.5,
      rainfall: rainfall,
    };

    btn.innerHTML = '<i class="fa-solid fa-brain fa-spin"></i> Running ML model…';

    try {
      const cropData = await api('/crop/recommend', { method: 'POST', body: JSON.stringify(payload) });
      if (cropData.success) {
        $('dash-stat-crop').textContent = cropData.recommended_crop;
        $('dash-crop-conf-val').textContent = `${cropData.confidence}% ML confidence`;
        $('dash-crop-conf').style.display = 'flex';
        $('dash-crop-prompt').textContent = `Based on live weather (${temp}°C, ${humidity}% RH)`;
        btn.innerHTML = '<i class="fa-solid fa-rotate"></i> Refresh Recommendation';
        toast(`📍 Location crop → ${cropData.recommended_crop} (${cropData.confidence}%)`);
      } else {
        btn.innerHTML = '<i class="fa-solid fa-location-crosshairs"></i> Detect & Recommend';
        toast(cropData.message || 'Recommendation failed', 'error');
      }
    } catch (err) {
      btn.innerHTML = '<i class="fa-solid fa-location-crosshairs"></i> Detect & Recommend';
      toast('Network error, please try again.', 'error');
    }
    btn.disabled = false;
  }

  btn.addEventListener('click', () => {
    if (!navigator.geolocation) {
      toast('Geolocation not available on this browser.', 'error');
      return;
    }
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-location-crosshairs fa-spin"></i> Detecting GPS…';
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude: lat, longitude: lon } = pos.coords;
        runSmartCropRecommend(lat.toFixed(4), lon.toFixed(4));
      },
      () => {
        // GPS denied — fall back to Bangalore defaults
        toast('GPS denied. Using Bengaluru as default location.', 'error');
        runSmartCropRecommend(12.9716, 77.5946);
      },
      { timeout: 8000 }
    );
  });
}



/* =====================================================
   NOTIFICATIONS
   ===================================================== */
async function loadNotifications() {
  const data = await api('/notifications');
  if (!data.success) return;
  const notifs = data.notifications;
  const badge = $('notif-badge');
  const list = $('notif-list');
  const unreadCount = notifs.filter((n) => n.unread).length;

  if (unreadCount > 0) { badge.textContent = unreadCount; show(badge); }
  else { hide(badge); }

  if (notifs.length === 0) {
    list.innerHTML = '<p class="empty-notif">No new alerts</p>';
    return;
  }

  list.innerHTML = notifs.map((n) => `
    <div class="notif-card-item ${n.unread ? 'unread' : ''}">
      <h4>${n.title}</h4>
      <p>${n.message}</p>
    </div>`).join('');

  $('btn-notif').addEventListener('click', () => {
    $('notif-dropdown').classList.toggle('hidden');
  });

  $('btn-clear-notif').addEventListener('click', async () => {
    await api('/notifications/read-all', { method: 'POST' });
    hide(badge);
    $('notif-dropdown').querySelectorAll('.notif-card-item').forEach((el) => el.classList.remove('unread'));
    toast('All notifications cleared');
  });
}

/* =====================================================
   CROP RECOMMENDATION
   ===================================================== */
function initCropRecommendation() {
  $('crop-recommendation-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const payload = {
      N: parseFloat($('soil-n').value),
      P: parseFloat($('soil-p').value),
      K: parseFloat($('soil-k').value),
      temperature: parseFloat($('soil-temp').value),
      humidity: parseFloat($('soil-hum').value),
      ph: parseFloat($('soil-ph').value),
      rainfall: parseFloat($('soil-rain').value),
    };

    const btn = e.target.querySelector('.btn-primary');
    btn.disabled = true; btn.textContent = 'Running Model…';
    const data = await api('/crop/recommend', { method: 'POST', body: JSON.stringify(payload) });
    btn.disabled = false; btn.innerHTML = '<span>Run Random Forest Classifier</span><i class="fa-solid fa-calculator"></i>';

    if (data.success) {
      const conf = data.confidence;
      hide($('crop-result-empty'));
      show($('crop-result-box'));
      $('crop-result-box').classList.add('animate-fade-in');
      $('rec-crop-name').textContent = data.recommended_crop;
      $('rec-crop-conf').textContent = `${conf}%`;
      $('rec-crop-bar').style.width = `${conf}%`;
      $('rec-crop-tips').textContent = data.fertilizer_tip;
      // Update dashboard stat card
      $('dash-stat-crop').textContent = data.recommended_crop;
      toast(`Recommended: ${data.recommended_crop}`);
    } else {
      toast(data.message || 'Request failed', 'error');
    }
  });
}

/* =====================================================
   PLANT DISEASE DETECTION
   ===================================================== */
function initDiseaseDetection() {
  const container = $('disease-upload-container');
  const fileInput = $('disease-file-input');
  const previewBox = $('disease-preview-container');
  const previewImg = $('disease-img-preview');

  const ALLOWED_MIME = ['image/png', 'image/jpeg', 'image/jpg'];
  const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB

  container.addEventListener('click', () => fileInput.click());
  container.addEventListener('dragover', (e) => e.preventDefault());
  container.addEventListener('drop', (e) => {
    e.preventDefault();
    if (e.dataTransfer.files[0]) loadImagePreview(e.dataTransfer.files[0]);
  });

  fileInput.addEventListener('change', () => {
    if (fileInput.files[0]) loadImagePreview(fileInput.files[0]);
  });

  function loadImagePreview(file) {
    if (!ALLOWED_MIME.includes(file.type)) {
      toast('Invalid file type. Only PNG, JPG, and JPEG are supported.', 'error');
      fileInput.value = '';
      return;
    }
    if (file.size > MAX_FILE_SIZE) {
      toast('File size exceeds 10MB limit.', 'error');
      fileInput.value = '';
      return;
    }

    const reader = new FileReader();
    reader.onload = (ev) => {
      previewImg.src = ev.target.result;
      hide(container);
      show(previewBox);
    };
    reader.readAsDataURL(file);
  }

  const resetDiseaseUI = () => {
    fileInput.value = '';
    previewImg.src = '';
    hide(previewBox);
    show(container);
    hide($('disease-result-box'));
    show($('disease-result-empty'));
  };

  $('btn-cancel-disease').addEventListener('click', resetDiseaseUI);
  $('btn-scan-another').addEventListener('click', resetDiseaseUI);

  $('btn-submit-disease').addEventListener('click', async () => {
    if (!fileInput.files[0] && !previewImg.src) { toast('Please select an image', 'error'); return; }

    const formData = new FormData();
    formData.append('file', fileInput.files[0]);
    const btn = $('btn-submit-disease');

    // Show loading indicator
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> Analyzing...';

    try {
      const res = await fetch('/api/disease/detect', { method: 'POST', body: formData, credentials: 'same-origin' });
      const data = await res.json();

      btn.disabled = false;
      btn.innerHTML = '<i class="fa-solid fa-microscope"></i> Diagnose Image';

      if (data.success) {
        hide($('disease-result-empty'));
        show($('disease-result-box'));
        $('disease-result-box').classList.add('animate-fade-in');

        // Render fields
        $('disease-lbl-plant').textContent = data.plant_name || 'Unknown Crop';
        $('disease-lbl-name').textContent = data.disease_name || 'Unknown disease';
        $('disease-lbl-conf').textContent = data.confidence ? `${data.confidence}%` : '—';
        $('disease-lbl-treatment').textContent = data.treatment || 'Consult a local agricultural expert for appropriate treatment.';

        // Update dashboard status
        $('dash-stat-disease').textContent = data.healthy ? 'Healthy' : (data.disease_name || 'Checked');

        // Render health status badge
        const badge = $('disease-health-badge');
        const status = data.status || (data.healthy ? 'Healthy' : 'Diseased');

        badge.textContent = status;
        if (status === 'Healthy') {
          badge.className = 'badge-danger';
          badge.style.background = 'rgba(16,185,129,.15)';
          badge.style.color = '#10b981';
          hide($('disease-prevention-container-el'));
        } else if (status === 'Unable to identify' || status === 'Not a Plant Leaf') {
          badge.className = 'badge-danger';
          badge.style.background = 'rgba(249,115,22,.15)';
          badge.style.color = '#f97316';
          hide($('disease-prevention-container-el'));
        } else {
          badge.className = 'badge-danger';
          badge.style.background = 'rgba(239,68,68,.15)';
          badge.style.color = '#ef4444';
          show($('disease-prevention-container-el'));
          if (data.prevention) {
            $('disease-lbl-prevention').textContent = data.prevention;
          } else {
            $('disease-lbl-prevention').textContent = 'Maintain field hygiene. Consult an expert if symptoms spread.';
          }
        }

        // Render other suggestions if they exist
        const suggestionsBox = $('disease-suggestions-box');
        const suggestionsList = $('disease-suggestions-list');

        if (data.suggestions && data.suggestions.length > 1) {
          show(suggestionsBox);
          const others = data.suggestions.slice(1);
          suggestionsList.innerHTML = others.map(s => {
            const prob = s.confidence ? `${s.confidence}%` : '—';
            return `
              <li style="font-size:0.85rem; color:var(--text-muted); background:rgba(255,255,255,0.02); border:1px solid var(--card-border); padding:0.5rem 0.75rem; border-radius:8px; display:flex; justify-content:space-between; align-items:center;">
                <span class="suggested-disease-name">🦠 ${escHtml(s.name)}</span>
                <span class="suggested-disease-prob" style="font-weight:700; color:var(--primary);">${prob}</span>
              </li>
            `;
          }).join('');
        } else {
          hide(suggestionsBox);
          suggestionsList.innerHTML = '';
        }

        toast(data.healthy ? 'Leaf diagnosed: Healthy!' : `Diagnosis: ${data.disease_name}`);
      } else {
        // Show friendly error result in pathology report instead of crashing or showing a raw toast
        hide($('disease-result-empty'));
        show($('disease-result-box'));

        $('disease-lbl-plant').textContent = 'Error';
        $('disease-lbl-name').textContent = 'Diagnosis Failed';
        $('disease-lbl-conf').textContent = '—';

        const badge = $('disease-health-badge');
        badge.textContent = 'Diagnostic Error';
        badge.style.background = 'rgba(239,68,68,.15)';
        badge.style.color = '#ef4444';

        const errMsg = data.message || 'Unable to identify the disease. Please upload a clearer leaf image.';
        $('disease-lbl-treatment').textContent = errMsg;
        hide($('disease-prevention-container-el'));
        hide($('disease-suggestions-box'));

        toast(data.message || 'Detection failed', 'error');
      }
    } catch (err) {
      btn.disabled = false;
      btn.innerHTML = '<i class="fa-solid fa-microscope"></i> Diagnose Image';
      toast('An unexpected network error occurred while communicating with the disease API.', 'error');
      console.error(err);
    }
  });
}

/* =====================================================
   SMART IRRIGATION
   ===================================================== */
function initIrrigation() {
  $('irrigation-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const payload = {
      crop_type: $('irr-crop').value,
      soil_moisture: parseFloat($('irr-moisture').value),
      temperature: parseFloat($('irr-temp').value),
      weather_condition: $('irr-weather').value,
    };
    const data = await api('/irrigation/recommend', { method: 'POST', body: JSON.stringify(payload) });
    if (data.success) {
      const r = data.data;
      hide($('irr-result-empty'));
      show($('irr-result-box'));
      $('irr-result-box').classList.add('animate-fade-in');
      $('irr-lbl-water').innerHTML = r.irrigation_required
        ? `${r.water_amount} <span>litres/m²</span>`
        : `0 <span>litres/m²</span>`;
      $('irr-lbl-time').textContent = r.best_irrigation_time;
      $('irr-lbl-reason').textContent = r.reason;
      toast(r.irrigation_required ? `Water: ${r.water_amount} L/m²` : 'No irrigation needed today!');
    } else {
      toast(data.message || 'Calculation failed', 'error');
    }
  });
}

/* =====================================================
   PEST PREDICTION
   ===================================================== */
function initPestPrediction() {
  $('pest-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const payload = {
      crop_name: $('pest-crop').value,
      temperature: parseFloat($('pest-temp').value),
      humidity: parseFloat($('pest-hum').value),
      rainfall: parseFloat($('pest-rain').value),
    };
    const data = await api('/pest/predict', { method: 'POST', body: JSON.stringify(payload) });
    if (data.success) {
      const r = data.data;
      hide($('pest-result-empty'));
      show($('pest-result-box'));
      $('pest-result-box').classList.add('animate-fade-in');
      $('pest-lbl-name').textContent = r.pest_name;
      $('pest-lbl-pct').textContent = `${r.risk_percentage}%`;
      const lvlBadge = $('pest-lbl-level');
      lvlBadge.textContent = `${r.risk} Risk`;
      const riskColor = r.risk === 'High' ? '#ef4444' : r.risk === 'Medium' ? '#f97316' : '#10b981';
      lvlBadge.style.color = riskColor;
      lvlBadge.style.background = riskColor + '20';
      $('pest-lbl-prevent').textContent = r.prevention;
      $('pest-lbl-pesticide').textContent = r.pesticide;
      toast(`Pest Risk: ${r.pest_name} — ${r.risk}`);
    } else {
      toast(data.message || 'Prediction failed', 'error');
    }
  });
}

/* =====================================================
   YIELD & PROFIT FORECAST
   ===================================================== */
function initYieldForecast() {
  $('yield-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const payload = {
      crop_name: $('yield-crop').value,
      area: parseFloat($('yield-area').value),
      temperature: parseFloat($('yield-temp').value),
      rainfall: parseFloat($('yield-rain').value),
      ph: parseFloat($('yield-ph').value),
    };
    const data = await api('/predictions/yield', { method: 'POST', body: JSON.stringify(payload) });
    if (data.success) {
      const r = data.data;
      hide($('yield-result-empty'));
      show($('yield-result-box'));
      $('yield-result-box').classList.add('animate-fade-in');
      $('yield-lbl-tons').textContent = `${r.predicted_yield_tons} Tons`;
      $('yield-lbl-gross').textContent = `₹${fmt(r.gross_revenue)}`;
      $('yield-lbl-cost').textContent = `₹${fmt(r.cost_of_cultivation)}`;
      $('yield-lbl-profit').textContent = `₹${fmt(r.expected_profit)}`;
      toast(`Projected profit: ₹${fmt(r.expected_profit)}`);
    } else {
      toast(data.message || 'Forecast failed', 'error');
    }
  });
}

/* =====================================================
   FARMING CALENDAR
   ===================================================== */
function setDefaultCalendarDate() {
  const today = new Date().toISOString().split('T')[0];
  $('cal-sowing-date').value = today;
}

function initCalendar() {
  $('calendar-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const payload = {
      crop_type: $('cal-crop').value,
      sowing_date: $('cal-sowing-date').value,
    };
    const data = await api('/calendar/schedule', { method: 'POST', body: JSON.stringify(payload) });
    if (data.success) {
      renderCalendarEvents(data.events, data.crop);
      toast(`${data.crop} calendar created!`);
    } else {
      toast(data.message || 'Failed', 'error');
    }
  });
}

function renderCalendarEvents(events, cropName) {
  const trail = $('calendar-events-list');
  const empty = $('calendar-events-empty');
  trail.innerHTML = events.map((ev) => `
    <div class="timeline-event">
      <div class="node"></div>
      <div class="event-header">
        <h4>${ev.title}</h4>
        <span>${ev.date}</span>
      </div>
      <p>${ev.description}</p>
    </div>`).join('');
  hide(empty);
  show(trail);
}

/* =====================================================
   GOVERNMENT SCHEMES
   ===================================================== */
function initSchemes() {
  $('schemes-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const payload = {
      state: $('scheme-state').value,
      crop: $('scheme-crop').value,
      land_size: parseFloat($('scheme-land').value),
      farmer_category: $('scheme-category').value,
    };
    const data = await api('/schemes/recommend', { method: 'POST', body: JSON.stringify(payload) });
    const list = $('schemes-list');
    if (data.success && data.schemes.length > 0) {
      list.innerHTML = data.schemes.map((s) => `
        <div class="scheme-card">
          <h3>${s.scheme_name}</h3>
          <div class="scheme-tags-row">
            <span class="sc-tag">${s.state}</span>
            <span class="sc-tag">${s.farmer_category}</span>
            <span class="sc-tag">${s.eligible_crops}</span>
          </div>
          <p>${s.description}</p>
          <div class="scheme-details">
            <strong>Benefits:</strong> ${s.benefits}
          </div>
          <a href="${s.apply_link}" target="_blank" class="scheme-action-btn">
            <i class="fa-solid fa-external-link"></i> Apply Online
          </a>
        </div>`).join('');
      toast(`${data.schemes.length} schemes found!`);
    } else if (data.success) {
      list.innerHTML = '<div class="result-placeholder"><i class="fa-solid fa-empty-set" style="font-size:2rem;color:var(--text-muted)"></i><p>No schemes matched the current criteria. Try broadening parameters.</p></div>';
    } else {
      toast(data.message || 'Query failed', 'error');
    }
  });
}

/* =====================================================
   WORKER BOOKING
   ===================================================== */
async function loadWorkers() {
  const data = await api('/workers');
  if (!data.success) return;
  const container = $('workers-list-body');
  container.innerHTML = data.workers.map((w) => `
    <div class="worker-card-item" data-id="${w._id}" data-wage="${w.daily_wage}" data-name="${w.name}">
      <div class="worker-avatar"><i class="fa-solid fa-user-tie"></i></div>
      <div class="worker-profile-info">
        <h4>${w.name}</h4>
        <p>${w.skills.join(', ')}</p>
        <p class="rating">★ ${w.rating} · ${w.experience_years} yrs · ${w.state}</p>
      </div>
      <div class="worker-economic-info">
        <span class="worker-wage-tag">₹${fmt(w.daily_wage)}/day</span>
        <span class="avail-badge ${w.availability === 'Available' ? 'available' : 'busy'}">${w.availability}</span>
      </div>
    </div>`).join('');

  container.querySelectorAll('.worker-card-item').forEach((card) => {
    card.addEventListener('click', () => {
      if (card.querySelector('.avail-badge.busy')) {
        toast('Worker is currently busy', 'error'); return;
      }
      container.querySelectorAll('.worker-card-item').forEach((c) => c.classList.remove('selected'));
      card.classList.add('selected');
      state.selectedWorker = { id: card.dataset.id, name: card.dataset.name, wage: parseFloat(card.dataset.wage) };
      $('book-worker-id').value = state.selectedWorker.id;
      $('booking-selected-label').innerHTML = `
        <div class="highlight-worker">
          <h4><i class="fa-solid fa-user-check text-green"></i> ${state.selectedWorker.name}</h4>
          <p>₹${fmt(state.selectedWorker.wage)}/day — Selected for booking</p>
        </div>`;
      $('book-date').disabled = false;
      $('book-days').disabled = false;
      $('btn-submit-booking').disabled = false;
      show($('wages-calc-card'));
      updateWageCalc();
    });
  });

  $('book-days').addEventListener('input', updateWageCalc);

  // Load Hired Labor Contracts History
  loadBookings();
}

async function loadBookings() {
  const data = await api('/workers/bookings');
  if (!data.success) return;
  const historyEl = $('workers-history-body');
  if (!historyEl) return;

  if (data.bookings.length === 0) {
    historyEl.innerHTML = '<p class="empty-bookings" style="color: var(--text-muted); text-align: center; padding: 2rem;">No active labor contracts.</p>';
    return;
  }

  historyEl.innerHTML = data.bookings.map((b) => `
    <div class="worker-card-item" style="cursor: default;">
      <div class="worker-avatar" style="background: rgba(16,185,129,.15); color: #10b981;"><i class="fa-solid fa-user-check"></i></div>
      <div class="worker-profile-info">
        <h4>${escHtml(b.worker_name)}</h4>
        <p>Booked Date: ${new Date(b.booking_date).toLocaleDateString('en-IN', { year: 'numeric', month: 'long', day: 'numeric' })} · Period: ${b.num_days} Day(s)</p>
      </div>
      <div class="worker-economic-info">
        <span class="worker-wage-tag">₹${fmt(b.total_wages)}</span>
        <span class="avail-badge available" style="color: var(--primary); font-size: 0.75rem; font-weight: 700; display: block; margin-top: 0.25rem;">
          <i class="fa-solid fa-circle-check"></i> ${b.status}
        </span>
      </div>
    </div>`).join('');
}

function updateWageCalc() {
  if (!state.selectedWorker) return;
  const days = parseInt($('book-days').value) || 1;
  $('total-wages-lbl').textContent = `₹${fmt(state.selectedWorker.wage * days)}`;
}

function initWorkerBooking() {
  $('booking-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!state.selectedWorker) { toast('Select a worker first', 'error'); return; }
    const payload = {
      worker_id: state.selectedWorker.id,
      booking_date: $('book-date').value,
      num_days: parseInt($('book-days').value),
    };
    const data = await api('/workers/book', { method: 'POST', body: JSON.stringify(payload) });
    if (data.success) {
      toast(`${state.selectedWorker.name} booked successfully!`);
      // Reset selected worker state
      state.selectedWorker = null;
      $('book-worker-id').value = '';
      $('booking-selected-label').innerHTML = `<p>Select a worker from the sidebar list to reserve scheduling.</p>`;
      $('book-date').value = '';
      $('book-date').disabled = true;
      $('book-days').value = 1;
      $('book-days').disabled = true;
      $('btn-submit-booking').disabled = true;
      hide($('wages-calc-card'));

      loadWorkers();
    } else {
      toast(data.message || 'Booking failed', 'error');
    }
  });
}

/* =====================================================
   MARKETPLACE
   ===================================================== */
async function loadMarketplace() {
  const data = await api('/marketplace');
  if (!data.success) return;
  const body = $('market-products-body');
  if (data.products.length === 0) {
    body.innerHTML = '<p style="color:var(--text-muted);grid-column:1/-1;text-align:center;padding:2rem">No listings yet. Be the first to sell!</p>';
    return;
  }
  body.innerHTML = data.products.map((p) => `
    <div class="glass market-card-item" style="border-radius:16px;overflow:hidden">
      <img src="${p.image_url}" alt="${p.product_name}" onerror="this.onerror=null;this.src='/static/uploads/seed_default.jpg'" loading="lazy">
      <div class="market-card-content">
        <div class="market-header-row">
          <span class="market-category">${p.category}</span>
          <span class="market-price">₹${p.price}/${p.unit}</span>
        </div>
        <h3>${p.product_name}</h3>
        <p>${p.description}</p>
        <p style="margin-top:.4rem;font-size:.75rem;color:var(--text-muted)">Qty: ${p.quantity} ${p.unit}</p>
        <div class="market-farmer-tag"><i class="fa-solid fa-user"></i>${p.farmer_name}${p.location ? ' · ' + p.location : ''}</div>
        <button class="btn-contact" data-pname="${p.product_name}" data-fname="${p.farmer_name}">
          <i class="fa-solid fa-phone"></i> Contact Farmer
        </button>
      </div>
    </div>`).join('');

  body.querySelectorAll('.btn-contact').forEach((btn) => {
    btn.addEventListener('click', () => {
      $('contact-prod-name').value = btn.dataset.pname;
      $('contact-farmer-name').value = btn.dataset.fname;
      show($('contact-modal'));
    });
  });
}

function initMarketplace() {
  $('btn-open-sell-modal').addEventListener('click', () => show($('sell-modal')));
  $('btn-close-modal').addEventListener('click', () => hide($('sell-modal')));
  $('btn-close-contact').addEventListener('click', () => hide($('contact-modal')));

  $('sell-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = new FormData();
    form.append('product_name', $('sell-pname').value);
    form.append('category', $('sell-cat').value);
    form.append('price', $('sell-price').value);
    form.append('quantity', $('sell-qty').value);
    form.append('unit', $('sell-unit').value);
    form.append('description', $('sell-desc').value);
    const imgFile = $('sell-img').files[0];
    if (imgFile) form.append('image', imgFile);

    const res = await fetch('/api/marketplace/upload', { method: 'POST', body: form, credentials: 'same-origin' });
    const data = await res.json();
    if (data.success) {
      toast('Product listed successfully!');
      hide($('sell-modal'));
      $('sell-form').reset();
      loadMarketplace();
    } else {
      toast(data.message || 'Upload failed', 'error');
    }
  });

  $('contact-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const payload = {
      product_name: $('contact-prod-name').value,
      farmer_name: $('contact-farmer-name').value,
      buyer_name: $('contact-name').value,
      buyer_contact: $('contact-phone').value,
      message: $('contact-msg').value,
    };
    const data = await api('/marketplace/contact', { method: 'POST', body: JSON.stringify(payload) });
    if (data.success) {
      toast('Message sent to farmer!');
      hide($('contact-modal'));
      $('contact-form').reset();
    } else {
      toast(data.message || 'Send failed', 'error');
    }
  });
}

/* =====================================================
   AI CHATBOT (GEMINI / LOCAL FALLBACK)
   ===================================================== */
function initChatbot() {
  const widget = $('chatbot-widget');
  const chatWin = $('chatbot-window');

  widget.addEventListener('click', () => chatWin.classList.toggle('hidden'));
  $('btn-close-chat').addEventListener('click', () => hide(chatWin));

  $('chat-send-btn').addEventListener('click', sendChatMessage);
  $('chat-query-input').addEventListener('keypress', (e) => { if (e.key === 'Enter') sendChatMessage(); });
}

async function sendChatMessage() {
  const input = $('chat-query-input');
  const query = input.value.trim();
  if (!query) return;
  input.value = '';

  const msgContainer = $('chat-messages-container');
  // User bubble
  msgContainer.innerHTML += `
    <div class="chat-msg user">
      <div class="msg-bubble">${escHtml(query)}</div>
    </div>`;
  msgContainer.scrollTop = msgContainer.scrollHeight;

  // Typing indicator
  const typingId = 'typing-' + Date.now();
  msgContainer.innerHTML += `
    <div class="chat-msg bot" id="${typingId}">
      <div class="bot-avatar-icon"><i class="fa-solid fa-robot"></i></div>
      <div class="msg-bubble" style="color:var(--text-muted)"><i class="fa-solid fa-ellipsis fa-beat"></i> Thinking…</div>
    </div>`;
  msgContainer.scrollTop = msgContainer.scrollHeight;

  const data = await api('/chatbot', { method: 'POST', body: JSON.stringify({ query }) });

  const typingEl = document.getElementById(typingId);
  if (typingEl) typingEl.remove();

  const reply = data.success ? data.response : 'Sorry, I could not process that request.';
  msgContainer.innerHTML += `
    <div class="chat-msg bot">
      <div class="bot-avatar-icon"><i class="fa-solid fa-robot"></i></div>
      <div class="msg-bubble">${escHtml(reply)}</div>
    </div>`;
  msgContainer.scrollTop = msgContainer.scrollHeight;
}

function escHtml(str) {
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n/g, '<br>');
}

// Voice assistant removed

/* =====================================================
   LIVE WEATHER MODULE
   ===================================================== */
let _wxLastParams = {};   // remember last fetch params for refresh

function initWeather() {
  const btnGps = $('btn-detect-gps');
  const btnSearch = $('btn-wx-search');
  const btnRefresh = $('btn-wx-refresh');
  const btnRetry = $('btn-wx-retry');
  const cityInput = $('wx-city-input');

  // Auto-fetch on first visit to tab: try GPS
  document.querySelector('.menu-item[data-tab="weather"]').addEventListener('click', () => {
    if (!$('wx-content').classList.contains('hidden') || !$('wx-loading').classList.contains('hidden')) return;
    attemptGps();
  });

  btnGps.addEventListener('click', attemptGps);

  btnSearch.addEventListener('click', () => {
    const city = cityInput.value.trim();
    if (!city) { toast('Please enter a city name', 'error'); return; }
    fetchWeather({ city });
  });

  cityInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') btnSearch.click();
  });

  btnRefresh.addEventListener('click', async () => {
    const icon = btnRefresh.querySelector('i');
    icon.classList.add('wx-spin');
    setTimeout(() => icon.classList.remove('wx-spin'), 750);
    // Clear backend cache
    await api('/weather/refresh', { method: 'POST' });
    fetchWeather(_wxLastParams);
  });

  btnRetry.addEventListener('click', () => fetchWeather(_wxLastParams));
}

function attemptGps() {
  if (!navigator.geolocation) {
    toast('Geolocation is not supported by this browser. Please search by city.', 'error');
    return;
  }
  const btn = $('btn-detect-gps');
  btn.innerHTML = '<i class="fa-solid fa-location-crosshairs fa-spin"></i><span>Detecting...</span>';
  btn.disabled = true;

  navigator.geolocation.getCurrentPosition(
    (pos) => {
      btn.innerHTML = '<i class="fa-solid fa-location-crosshairs"></i><span>Detect My Location</span>';
      btn.disabled = false;
      fetchWeather({ lat: pos.coords.latitude.toFixed(4), lon: pos.coords.longitude.toFixed(4) });
    },
    (err) => {
      btn.innerHTML = '<i class="fa-solid fa-location-crosshairs"></i><span>Detect My Location</span>';
      btn.disabled = false;
      const msgs = {
        1: 'Location access denied. Please search by city name instead.',
        2: 'Location unavailable. Search by city name.',
        3: 'Location request timed out. Search by city name.',
      };
      toast(msgs[err.code] || 'GPS error. Please search by city.', 'error');
      fetchWeather({ city: 'Bangalore' }); // sensible default
    },
    { timeout: 8000, maximumAge: 300000 }
  );
}

async function fetchWeather(params = {}) {
  _wxLastParams = params;

  // Show skeleton, hide content/error
  show($('wx-loading'));
  hide($('wx-content'));
  hide($('wx-error'));

  let query = '';
  if (params.lat && params.lon) query = `?lat=${params.lat}&lon=${params.lon}`;
  else if (params.city) query = `?city=${encodeURIComponent(params.city)}`;

  const data = await api('/weather' + query);

  hide($('wx-loading'));

  if (!data.success) {
    show($('wx-error'));
    const errEl = $('wx-error-msg');
    if (errEl) errEl.textContent = data.message || 'Could not fetch weather data.';
    return;
  }

  const w = data.data;
  renderWeather(w, data.source);
}

function renderWeather(w, source) {
  // ── Source badge ──
  const badge = $('wx-api-badge');
  if (source === 'api') {
    badge.textContent = '🌐 Live API';
    badge.className = 'wx-source-badge';
  } else {
    badge.textContent = '🔁 Simulated';
    badge.className = 'wx-source-badge sim';
  }
  show(badge);

  // ── Location + datetime ──
  $('wx-city-name').textContent = w.city;
  $('wx-country-name').textContent = w.country ? ` — ${w.country}` : '';
  $('wx-datetime-str').textContent = new Date().toLocaleDateString('en-IN', {
    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
  }) + ', ' + new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });

  // ── Temperature ──
  $('wx-temp-val').textContent = `${w.temperature}°C`;
  $('wx-condition-desc').textContent = w.description;
  $('wx-feels-val').textContent = w.feels_like;

  // ── OWM weather icon (large) ──
  const iconEl = $('wx-main-icon');
  iconEl.src = `https://openweathermap.org/img/wn/${w.icon}@4x.png`;
  iconEl.onerror = () => { iconEl.src = ''; iconEl.style.display = 'none'; };

  // ── Stat pills ──
  $('wx-stat-hum').textContent = `${w.humidity}%`;
  $('wx-stat-wind').textContent = `${w.wind_speed} km/h`;
  $('wx-stat-pressure').textContent = `${w.pressure} hPa`;
  $('wx-stat-vis').textContent = `${w.visibility_km} km`;
  $('wx-stat-rain').textContent = `${w.rain_prediction} (${w.rain_probability}%)`;
  $('wx-stat-cloud').textContent = `${w.cloud_coverage}%`;

  // ── Sunrise / Sunset / Last Updated ──
  $('wx-sunrise').textContent = w.sunrise || '—';
  $('wx-sunset').textContent = w.sunset || '—';
  $('wx-updated').textContent = w.last_updated || '—';

  // ── 5-Day Forecast ──
  const forecastRow = $('wx-forecast-row');
  forecastRow.innerHTML = '';
  const todayStr = new Date().toISOString().split('T')[0];
  (w.forecast || []).forEach((f, idx) => {
    const isToday = f.date === todayStr || idx === 0;
    forecastRow.innerHTML += `
      <div class="wx-fc-card ${isToday ? 'today' : ''}">
        <div class="wx-fc-day">${f.short_day || f.day.slice(0, 3)}</div>
        <div class="wx-fc-date">${f.display_date}</div>
        <img class="wx-fc-icon" src="https://openweathermap.org/img/wn/${f.icon}@2x.png"
          alt="${f.condition}" onerror="this.style.display='none'">
        <div class="wx-fc-cond">${f.description}</div>
        <div class="wx-fc-temps">
          <span class="hi">${f.temp_max}°</span>
          <span class="lo">${f.temp_min}°</span>
        </div>
        <div class="wx-fc-rain"><i class="fa-solid fa-droplet"></i> ${f.rain_prob}%</div>
      </div>`;
  });

  // ── Agriculture Insights ──
  const insights = w.agri_insights || {};
  renderAgriList($('wx-recs-list'), insights.recommendations || []);
  renderAgriList($('wx-alerts-list'), insights.alerts || []);

  // Smart Agriculture Integration: Autofill inputs with live data
  if ($('soil-temp')) $('soil-temp').value = w.temperature;
  if ($('soil-hum')) $('soil-hum').value = w.humidity;
  if ($('irr-temp')) $('irr-temp').value = w.temperature;
  if ($('pest-temp')) $('pest-temp').value = w.temperature;
  if ($('pest-hum')) $('pest-hum').value = w.humidity;
  if ($('irr-weather')) {
    const cond = (w.condition || '').toLowerCase();
    if (cond.includes('thunderstorm')) {
      $('irr-weather').value = 'Thunderstorm';
    } else if (cond.includes('rain') || cond.includes('drizzle')) {
      $('irr-weather').value = 'Rainy';
    } else if (cond.includes('cloud') || cond.includes('mist') || cond.includes('fog') || cond.includes('haze')) {
      $('irr-weather').value = 'Cloudy';
    } else {
      $('irr-weather').value = 'Sunny';
    }
  }

  // ── Show content ──
  $('wx-content').classList.add('animate-fade-in');
  show($('wx-content'));
}

function renderAgriList(container, items) {
  if (!items.length) {
    container.innerHTML = '<p class="wx-agri-empty"><i class="fa-solid fa-circle-check"></i> All clear — no items to show.</p>';
    return;
  }
  container.innerHTML = items.map(item => `
    <div class="wx-agri-item">
      <div class="wx-agri-icon ${item.color}">
        <i class="fa-solid ${item.icon}"></i>
      </div>
      <div class="wx-agri-text">
        <h4>${item.title}</h4>
        <p>${item.detail}</p>
      </div>
    </div>
  `).join('');
}

/* =====================================================
   ENTRY POINT
   ===================================================== */
window.addEventListener('DOMContentLoaded', () => {
  initAuth();
  initNavigation();
  initTheme();
  initWeather();
  initCropRecommendation();
  initDiseaseDetection();
  initIrrigation();
  initPestPrediction();
  initYieldForecast();
  initCalendar();
  initSchemes();
  initWorkerBooking();
  initMarketplace();
  initChatbot();
  if (typeof initLearning === 'function') initLearning();
  // Check existing session
  checkSession();

  // Dashboard card & fast action buttons click navigation helper
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('.dashboard-action-btn');
    if (btn) {
      e.stopPropagation();
      const destTab = btn.dataset.nav;
      if (destTab) {
        const link = document.querySelector(`.menu-item[data-tab="${destTab}"]`);
        if (link) {
          link.click();
        }
      }
    }
  });
});
