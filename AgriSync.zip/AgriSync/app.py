from flask import Flask, render_template, session, redirect, url_for
from config import Config
from database import init_db
from models.ai_models import init_ai_models
import os

# Initialize Flask Application
app = Flask(__name__, static_folder="static", template_folder="templates")
app.config.from_object(Config)

# Register Blueprints
from routes.auth import auth_bp
from routes.weather import weather_bp
from routes.farm import farm_bp
from routes.crop import crop_bp
from routes.disease import disease_bp
from routes.irrigation import irrigation_bp
from routes.pest import pest_bp
from routes.predictions import predictions_bp
from routes.calendar import calendar_bp
from routes.schemes import schemes_bp
from routes.workers import workers_bp
from routes.marketplace import marketplace_bp
from routes.notifications import notifications_bp
from routes.chatbot import chatbot_bp
from routes.market_prices import market_prices_bp
from routes.learning import learning_bp

app.register_blueprint(auth_bp, url_prefix='/api/auth')
app.register_blueprint(weather_bp, url_prefix='/api/weather')
app.register_blueprint(farm_bp, url_prefix='/api/farm')
app.register_blueprint(crop_bp, url_prefix='/api/crop')
app.register_blueprint(disease_bp, url_prefix='/api/disease')
app.register_blueprint(irrigation_bp, url_prefix='/api/irrigation')
app.register_blueprint(pest_bp, url_prefix='/api/pest')
app.register_blueprint(predictions_bp, url_prefix='/api/predictions')
app.register_blueprint(calendar_bp, url_prefix='/api/calendar')
app.register_blueprint(schemes_bp, url_prefix='/api/schemes')
app.register_blueprint(workers_bp, url_prefix='/api/workers')
app.register_blueprint(marketplace_bp, url_prefix='/api/marketplace')
app.register_blueprint(notifications_bp, url_prefix='/api/notifications')
app.register_blueprint(chatbot_bp, url_prefix='/api/chatbot')
app.register_blueprint(market_prices_bp, url_prefix='/api/market-prices')
app.register_blueprint(learning_bp, url_prefix='/api/learning')

# Serve SPA Frontend
@app.route('/')
def home():
    # If user is logged in, serve dashboard, otherwise check auth state
    # Since it's a seamless SPA, we'll render base index.html,
    # and the frontend JS will handle showing login screen or dashboard
    # based on the current session API (/api/auth/current_user).
    return render_template('index.html')

# Incase index.html is served, static uploads should exist
UPLOAD_DIR = Config.UPLOAD_FOLDER
os.makedirs(UPLOAD_DIR, exist_ok=True)

# Generate default static placeholder image if needed
DEFAULT_IMG_PATH = os.path.join(UPLOAD_DIR, 'seed_default.jpg')
if not os.path.exists(DEFAULT_IMG_PATH):
    try:
        # Just create an empty/dummy image to avoid missing resource
        with open(DEFAULT_IMG_PATH, 'wb') as f:
            f.write(b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x06\x00\x00\x00\x1f\x15c4\x00\x00\x00\nIDATx\x9cc`\x00\x00\x00\x02\x00\x01H\xaf\xa4q\x00\x00\x00\x00IEND\xaeB`\x82')
        # Seed crop images too to bypass missing link errors
        for name in ['seed_basmati.jpg', 'seed_tomato.jpg', 'seed_turmeric.jpg', 'seed_honey.jpg']:
            with open(os.path.join(UPLOAD_DIR, name), 'wb') as f:
                f.write(b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x06\x00\x00\x00\x1f\x15c4\x00\x00\x00\nIDATx\x9cc`\x00\x00\x00\x02\x00\x01H\xaf\xa4q\x00\x00\x00\x00IEND\xaeB`\x82')
    except Exception as e:
        print(f"Failed to create seed graphics: {e}")

# Startup checklist
print("Initializing MongoDB and Seeding Data...")
init_db(app)

print("Initializing AI Models (Generative Training if needed)...")
try:
    init_ai_models()
except Exception as err:
    print(f"Warning: AI Model Initialization returned errors (we will use fallback logic if models are needed): {err}")

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    # Run server
    app.run(host='0.0.0.0', port=port, debug=False)
