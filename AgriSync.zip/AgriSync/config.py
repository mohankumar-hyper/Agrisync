import os
from dotenv import load_dotenv

# Load env variables from physical .env file
load_dotenv()

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'default_agrisense_sec_key_19283')
    MONGO_URI = os.environ.get('MONGO_URI', 'mongodb://localhost:27017/agrisense_db')
    OPENWEATHER_API_KEY = os.environ.get('OPENWEATHER_API_KEY', '')
    GEMINI_API_KEY = os.environ.get('GEMINI_API_KEY', '')
    GROQ_API_KEY = os.environ.get('GROQ_API_KEY', '')
    DISEASE_API_KEY = os.environ.get('DISEASE_API_KEY', '')
    DISEASE_API_URL = os.environ.get('DISEASE_API_URL', 'https://api.plant.id/v3/health_assessment')
    FLASK_ENV = os.environ.get('FLASK_ENV', 'development')
    UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static', 'uploads')

    
    # Ensure upload folder exists
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
