import unittest
import json
from app import app

class TestLearningCentre(unittest.TestCase):
    def setUp(self):
        self.app = app.test_client()
        self.app.testing = True

    def test_get_dashboard_summary(self):
        response = self.app.get('/api/learning/dashboard')
        data = json.loads(response.data)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(data['success'])
        self.assertIn('crop_focus', data)
        self.assertIn('continue_learning', data)

    def test_get_crops_list(self):
        response = self.app.get('/api/learning/crops')
        data = json.loads(response.data)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(data['success'])
        self.assertIn('crops', data)
        self.assertTrue(len(data['crops']) >= 18)

    def test_get_crop_agronomy_rice(self):
        response = self.app.get('/api/learning/crops?crop=rice')
        data = json.loads(response.data)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(data['success'])
        self.assertEqual(data['crop'], 'rice')
        self.assertIn('agronomy', data)
        self.assertEqual(data['agronomy']['name'], 'Rice (Paddy / ಭತ್ತ / धान)')
        self.assertIn('growing_regions', data['agronomy'])
        self.assertTrue(len(data['agronomy']['growing_regions']) > 0)

    def test_get_gm_plants_list(self):
        response = self.app.get('/api/learning/gm')
        data = json.loads(response.data)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(data['success'])
        self.assertIn('plants', data)
        self.assertEqual(len(data['plants']), 8)

    def test_get_gm_plant_by_id(self):
        # gm1 is Bt Cotton per learning_data.py GM_PLANTS list
        response = self.app.get('/api/learning/gm?plant=gm1')
        data = json.loads(response.data)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(data['success'])
        self.assertIn('plant', data)
        self.assertEqual(data['plant']['common_name'], 'Bt Cotton')
        self.assertIn('growing_regions', data['plant'])
        self.assertIn('modification_method', data['plant'])

    def test_get_videos(self):
        response = self.app.get('/api/learning/videos')
        data = json.loads(response.data)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(data['success'])
        self.assertTrue(len(data['videos']) >= 1)

    def test_get_videos_filter(self):
        response = self.app.get('/api/learning/videos?category=Organic%20Farming')
        data = json.loads(response.data)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(data['success'])
        for v in data['videos']:
            self.assertEqual(v['category'], 'Organic Farming')

    def test_get_guides(self):
        response = self.app.get('/api/learning/guides')
        data = json.loads(response.data)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(data['success'])
        self.assertTrue(len(data['guides']) >= 2)

    def test_get_quiz(self):
        response = self.app.get('/api/learning/quiz?category=organic')
        data = json.loads(response.data)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(data['success'])
        self.assertIn('questions', data)
        # correct answers should be stripped off
        for q in data['questions']:
            self.assertNotIn('ans', q)

    def test_submit_quiz_pass(self):
        payload = {
            "category": "organic",
            "answers": {
                "1": 0,
                "2": 1,
                "3": 1
            }
        }
        response = self.app.post('/api/learning/quiz/submit', 
                                 data=json.dumps(payload),
                                 content_type='application/json')
        data = json.loads(response.data)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(data['success'])
        self.assertTrue(data['passed'])
        self.assertEqual(data['percentage'], 100)

    def test_submit_quiz_fail(self):
        payload = {
            "category": "organic",
            "answers": {
                "1": 3,
                "2": 3,
                "3": 3
            }
        }
        response = self.app.post('/api/learning/quiz/submit', 
                                 data=json.dumps(payload),
                                 content_type='application/json')
        data = json.loads(response.data)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(data['success'])
        self.assertFalse(data['passed'])

    def test_get_images(self):
        response = self.app.get('/api/learning/images')
        data = json.loads(response.data)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(data['success'])
        self.assertTrue(len(data['images']) >= 2)

    def test_get_downloads(self):
        response = self.app.get('/api/learning/downloads')
        data = json.loads(response.data)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(data['success'])
        self.assertTrue(len(data['downloads']) >= 3)

    def test_chat_assistant_fallback(self):
        payload = {"query": "Tell me how to grow wheat", "lang": "en"}
        response = self.app.post('/api/learning/chat', 
                                 data=json.dumps(payload),
                                 content_type='application/json')
        data = json.loads(response.data)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(data['success'])
        self.assertIn('response', data)

if __name__ == '__main__':
    unittest.main()
